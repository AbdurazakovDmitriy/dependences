package ru.rosbank.mobile_plugin.utils;

import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import ru.rosbank.automation.configuration.ApplicationContext;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;
import ru.rosbank.mobile_plugin.steps.MobileCommonSteps;
import ru.sbtqa.tag.pagefactory.environment.Environment;
import ru.sbtqa.tag.pagefactory.exceptions.WaitException;

@Slf4j
public class MobileAlert{

    private static MobileConfiguration PROPERTIES=MobileConfiguration.create();

    private Alert alert;

    private MobileCommonSteps steps() {
        return (MobileCommonSteps) ApplicationContext.getStepsImpl("CommonSteps");
    }

    public MobileAlert(int timeout) {
        if (!Environment.isDriverEmpty()) {
            this.alert = this.switchToAlert(timeout);
        }
    }

    public MobileAlert() {
        this(PROPERTIES.getTimeout());
    }

    /**
     * Переключает фокус на окно алерта
     * @param timeout время ожидания появления алерта
     * @return new Alert()
     */
    private Alert switchToAlert(int timeout) {
        long timeoutTime = System.currentTimeMillis() + (long)(timeout * 1000);

        while(timeoutTime > System.currentTimeMillis()) {
            try {
                return Environment.getDriverService().getDriver().switchTo().alert();
            } catch (Exception exception) {
                log.debug("Alert has not appeared yet", exception);
                try {
                    steps().sleep(1);
                } catch (InterruptedException e) {
                    log.info("Ожидание прервано", e);
                }
            }
        }

        throw new WaitException(String.format("Истекло время ожидания '%s' алерта", timeout));
    }

    /**
     * Закрывает окно алерта
     */
    public void dismiss() {
        this.alert.dismiss();
    }

    /**
     * Закрывает окно алерта
     */
    public void accept() {
        this.alert.accept();
    }

    /**
     * Возвращает текст алерта и закрывает его.
     *
     * @return текст алерта
     */
    public String getText(){
        String result = alert.getText();
        dismiss();
        return result;
    }

    public boolean checkValue(String text) {
        return text.equals(getText());
    }
}
