package ru.rosbank.mobile_plugin.utils;

import io.appium.java_client.MobileElement;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import ru.sbtqa.tag.pagefactory.utils.Wait;

@Slf4j
public class MobileWait {

    /**
     * Ждет наличие элемента в течение таймаута, указанного в свойстве {@code timeout} конфигурации.
     * При возникновении исключения возвращает false
     *
     * @param element объект элемента страницы
     * @return true, если доступен; false, если недоступен
     */
    public static boolean silentWaitElementIsClickable(WebElement element){
        boolean status;
        try {
            Wait.clickable(element, String.format("Элемент %s не кликабелен", element));
            status = true;
        } catch (Exception e){
            log.info("Елемент не стал доступен в течение таймаута", e);
            status = false;
        }
        return status;
    }

    /**
     * Ждет видимость элемента в течение таймаута, указанного в свойстве {@code timeout} конфигурации.
     * При возникновении исключения возвращает false
     *
     * @param element - объект элемента страницы
     * @return true - если видим; false - если невидим.
     */
    public static boolean silentWaitVisibility(WebElement element){
        boolean status;
        try {
            Wait.visibility(element, String.format("Элемент %s не отображается", element));
            status = true;
        } catch (TimeoutException e){
            log.info("Елемент не отобразился", e);
            status = false;
        }
        return status;
    }
}
