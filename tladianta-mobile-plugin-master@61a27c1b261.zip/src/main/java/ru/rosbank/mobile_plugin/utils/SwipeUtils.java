package ru.rosbank.mobile_plugin.utils;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import ru.sbtqa.tag.pagefactory.environment.Environment;
import ru.sbtqa.tag.pagefactory.exceptions.SwipeException;
import ru.sbtqa.tag.qautils.strategies.DirectionStrategy;
import ru.sbtqa.tag.qautils.strategies.MatchStrategy;

import java.util.List;
@Slf4j
public class SwipeUtils {
    private static final int DEFAULT_SWIPE_TIME = 3000;
    private static final int DEFAULT_SWIPE_DEPTH = 256;
    private static final double INDENT_BOTTOM = 0.8D;
    private static final double INDENT_TOP = 0.2D;
    private static final double INDENT_LEFT = 0.3D;
    private static final double INDENT_RIGHT = 0.7D;
    private static MobileDriver appiumDriver = Environment.getDriverService().getDriver();

    private SwipeUtils() {
    }

    public static void swipe(WebElement element, DirectionStrategy direction) throws SwipeException {
        swipe(element, direction, 3000);
    }

    public static void swipe(WebElement element, DirectionStrategy direction, int time) throws SwipeException {
        Dimension size = element.getSize();
        Point location = element.getLocation();
        swipe(location, size, direction, time);
    }

    public static void swipe(DirectionStrategy direction) throws SwipeException {
        swipe(direction, 3000);
    }

    public static void swipe(DirectionStrategy direction, int time) throws SwipeException {
        Dimension size = appiumDriver.manage().window().getSize();
        swipe(new Point(0, 0), size, direction, time);
    }

    private static void swipe(Point location, Dimension size, DirectionStrategy direction, int time) throws SwipeException {
        int startx;
        int endx;
        int starty;
        int endy;
        switch(direction) {
            case UP:
                startx = endx = size.width / 2;
                starty = (int)((double)size.height * 0.2D);
                endy = (int)((double)size.height * 0.8D);
                break;
            case DOWN:
                startx = endx = size.width / 2;
                starty = (int)((double)size.height * 0.8D);
                endy = (int)((double)size.height * 0.2D);
                break;
            case RIGHT:
                startx = (int)((double)size.width * 0.7D);
                endx = (int)((double)size.width * 0.3D);
                starty = endy = size.height / 2;
                break;
            case LEFT:
                startx = (int)((double)size.width * 0.3D);
                endx = (int)((double)size.width * 0.7D);
                starty = endy = size.height / 2;
                break;
            default:
                throw new SwipeException("Failed to swipe to direction " + direction);
        }

        int x = location.getX();
        int y = location.getY();
        log.debug("Swipe parameters: location {}, dimension {}, direction {}, time {}", new Object[]{location, size, direction, time});
        new TouchAction(appiumDriver).press(PointOption.point(x + startx, y + starty))
                .waitAction()
                .moveTo(PointOption.point(x + endx, y + endy))
                .release()
                .perform();
    }

    public static void swipeToText(DirectionStrategy direction, String text) throws SwipeException {
        swipeToText(direction, text, MatchStrategy.EXACT);
    }

    public static void swipeToText(DirectionStrategy direction, String text, MatchStrategy strategy) throws SwipeException {
        swipeToText(direction, text, strategy, 256);
    }

    public static void swipeToText(DirectionStrategy direction, String text, MatchStrategy strategy, int depth) throws SwipeException {
        for(int depthCounter = 0; depthCounter < depth; ++depthCounter) {
            String oldPageSource = appiumDriver.getPageSource();
            if (strategy == MatchStrategy.EXACT) {
                if (!appiumDriver.findElementsByXPath("//*[@text='" + text + "']").isEmpty()) {
                    return;
                }
            } else {
                List<WebElement> textViews = appiumDriver.findElementsByClassName("android.widget.TextView");
                if (!textViews.isEmpty()) {

                    for (WebElement textView : textViews) {
                        if (textView.getText().contains(text)) {
                            return;
                        }
                    }
                }
            }

            swipe(direction);
            if (appiumDriver.getPageSource().equals(oldPageSource)) {
                throw new SwipeException("Swiping limit is reached. Text not found");
            }
        }

        throw new SwipeException("Swiping depth is reached. Text not found");
    }

    public static void swipeToText(MatchStrategy strategy, String text) throws SwipeException {
        switch(strategy) {
            case EXACT:
                try {
                    appiumDriver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().text(\"" + text + "\").instance(0))"));
                    break;
                } catch (NoSuchElementException var3) {
                    throw new SwipeException("Swiping limit is reached. Text: " + text + " not found");
                }
            case CONTAINS:
                try {
                    appiumDriver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"" + text + "\").instance(0))"));
                    break;
                } catch (NoSuchElementException e) {
                    throw new SwipeException("Swiping limit is reached. Part text: " + text + " not found");
                }
            default:
                throw new SwipeException("Please use correct matching strategy. Available options: 'EXACT' or 'CONTAINS'.");
        }

    }
}

