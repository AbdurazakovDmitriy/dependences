package ru.rosbank.mobile_plugin.checks;

import io.appium.java_client.MobileElement;
import ru.rosbank.automation.allure.AllureHelper;
import ru.rosbank.automation.environment.*;
import ru.sbtqa.tag.pagefactory.utils.Wait;

public interface IMobileChecks extends IPageChecks {
    /**
     * Ждет видимости элемента в течение таймаута, указанного в свойстве {@code timeout} конфигурации
     * Затем сравнивает значение с ожидаемым, игнорируя регистр.
     *
     * @param element - объект элемента страницы
     * @param text - ожидаемое значение
     * @return - true, если значения совпадают; false, если не совпадают
     */
    default boolean checkEqualityIgnoreCase(MobileElement element, String text) {
        Wait.visibility(element, String.format("Элемент %s не отображается", element));
        String expectedText = element.getText();
        if (text.equalsIgnoreCase(expectedText)){
            AllureHelper.info("Элемент с текстом '%s' найден", new String[]{text});
            return true;
        }
        else {
            AllureHelper.info("Элемент с текстом '%s' не найден", new String[]{text});
            return false;
        }
    }
}
