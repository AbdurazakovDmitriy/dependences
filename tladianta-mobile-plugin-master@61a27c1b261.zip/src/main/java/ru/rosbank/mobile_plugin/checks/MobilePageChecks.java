package ru.rosbank.mobile_plugin.checks;

import org.openqa.selenium.WebElement;
import ru.rosbank.automation.allure.AllureHelper;
import ru.rosbank.mobile_plugin.elements.core.text.IHaveText;
import ru.sbtqa.tag.pagefactory.checks.PageChecks;
import ru.sbtqa.tag.pagefactory.utils.Wait;
import ru.sbtqa.tag.qautils.strategies.MatchStrategy;

public class MobilePageChecks implements IMobileChecks {
    @Override
    public final PageChecks getSource() {
        return this;
    }

    public boolean checkEquality(Object element, String text) {
        return this.checkEquality(element, text, MatchStrategy.EXACT);
    }

    public boolean checkEquality(Object element, String text, MatchStrategy matchStrategy) {
        String value = getElementValue(element);
        return matchStrategy == MatchStrategy.EXACT
                ? text.replaceAll("\\s+", " ").equals(value.replaceAll("\\s+", " "))
                : value.replaceAll("\\s+", " ").contains(text.replaceAll("\\s+", " "));
    }

    private String getElementValue(Object element) {
        if (element instanceof WebElement){
            return ((IHaveText<WebElement>) () -> (WebElement) element).getText();
        }
        if (element instanceof IHaveText){
            return ((IHaveText) element).getText();
        }
        throw new RuntimeException(String.format("Could not extract value from '%s'", element.getClass()));
    }

    public boolean checkEmptiness(Object element) {
        String value = this.getElementValue(element);
        return "".equals(value) || value.isEmpty();
    }

    public boolean checkEqualityIgnoreCase(IHaveText element, String text) {
        if (element instanceof WebElement) {
            Wait.visibility((WebElement) element, String.format("Элемент %s не отображается", element));
        }
        String expectedText = element.getText();
        if (text.equalsIgnoreCase(expectedText)){
            AllureHelper.info("Элемент с текстом '%s' найден", new String[]{text});
            return true;
        }
        else {
            AllureHelper.info("Элемент с текстом '%s' не найден", new String[]{text});
            return false;
        }
    }
}