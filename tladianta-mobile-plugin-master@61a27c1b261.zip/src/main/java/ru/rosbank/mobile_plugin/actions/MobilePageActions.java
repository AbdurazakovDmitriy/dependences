package ru.rosbank.mobile_plugin.actions;

import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import ru.rosbank.automation.environment.IPageActions;
import ru.rosbank.mobile_plugin.elements.core.ICheckBox;
import ru.rosbank.mobile_plugin.elements.core.IClickable;
import ru.rosbank.mobile_plugin.elements.core.ISelect;
import ru.rosbank.mobile_plugin.elements.core.text.IEditText;
import ru.sbtqa.tag.pagefactory.actions.PageActions;
import ru.sbtqa.tag.pagefactory.environment.Environment;

public class MobilePageActions implements IPageActions {
    public void fill(@NotNull Object object, @NotNull String text) {
        //если элемент сам определяет ввод текста - делегируем ему ввод текста и выходим
        if (object instanceof IEditText) {
            ((IEditText) object).setText(text);
            return;
        }
        if (!(object instanceof WebElement)){
            throw new UnsupportedOperationException("Невозможно выполнить ввод текста в элемент с классом '"+object.getClass()+"'");
        }
        WebElement element = (WebElement) object;
        //если элемент определяет клик - делегируем ему клик
        IClickable iClick = element instanceof IClickable ? (IClickable) element : (IClickable<WebElement>) () -> element;
        iClick.click();
        IEditText iEditText = () -> element;
        iEditText.setText(text);
    }

    public void click(Object element) {
        if (!(element instanceof IClickable) && !(element instanceof WebElement)){
            throw new UnsupportedOperationException(String.format("Type '%s' not supported", element.getClass()));
        }
        IClickable item = element instanceof IClickable ? (IClickable) element : (() -> element);
        item.click();
    }

    public void press(Object element, @NotNull String keyName) {
        if (element instanceof WebElement) {
            ((WebElement) element).click();
        }
        Keys key = Keys.valueOf(keyName.toUpperCase());
        Actions actions = new Actions((WebDriver) Environment.getDriverService().getDriver());
        actions.sendKeys(new CharSequence[]{key}).build().perform();
    }

    public void select(Object element, @NotNull String option) {
        ISelect select;
        if (!(element instanceof ISelect)) {
            if (element instanceof WebElement) {
                select = () -> element;
            } else {
                throw new UnsupportedOperationException(String.format("Type '%s' not supported", element.getClass()));
            }
        } else {
            select = (ISelect) element;
        }
        select.selectByValue(option);
    }

    public void setCheckbox(Object element, boolean state) {
        if (!(element instanceof ICheckBox) && !(element instanceof WebElement)){
            throw new UnsupportedOperationException(String.format("Type '%s' not supported", element.getClass()));
        }
        ICheckBox box = element instanceof ICheckBox ? (ICheckBox) element : (() -> (WebElement) element);
        box.check(state);
    }

    @Override
    public PageActions getSource() {
        return this;
    }
}
