package ru.rosbank.mobile_plugin.driver;

import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.remote.RemoteWebDriver;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;
import ru.sbtqa.tag.pagefactory.drivers.DriverService;

import java.util.concurrent.TimeUnit;

@Slf4j
public class MobileDriverService<T extends RemoteWebDriver> implements DriverService {

    private static final MobileConfiguration PROPERTIES = MobileConfiguration.create();
    private static final ThreadLocal<RemoteWebDriver> pDriver = new ThreadLocal<>();

    public MobileDriverService() {
    }

    /**
     * В зависимости от значения {@code appium.device.platform.name} в application.properties
     * возвращает AndroidDriver или IOSDriver
     */
    @Override
    public void mountDriver() {
        RemoteWebDriver driver = pDriver.get();
        if (driver != null) {
            log.debug("Драйвер не был корректно остановлен, выполняю попытку остановки драйвера");
            driver.quit();
        }
        //сразу удаляем драйвер, чтобы случайно не обратиться к нему
        pDriver.set(null);
        String platform = String.valueOf(PROPERTIES.getAppiumPlatformName());
        log.debug(String.format("creating driver for platform '%s'",platform));
        switch (platform.toLowerCase()) {
            case "ios":
                driver = new IOSDriverManager().createDriver();
                break;
            case "android":
                driver = new AndroidDriverManager().createDriver();
                break;
            default:
                throw new RuntimeException(String.format("unknown platform '%s'", platform));
        }
        if (driver == null) {
            throw new RuntimeException(String.format("Could not create driver for platform '%s'", platform));
        }
        log.debug("Драйвер успешно создан");
        driver.manage().timeouts().implicitlyWait(PROPERTIES.getTimeout(), TimeUnit.SECONDS);
        pDriver.set(driver);
    }

    /**
     * Закрывает драйвер
     */
    @Override
    public void demountDriver() {
        RemoteWebDriver driver = pDriver.get();
        if (driver != null) {
            try {
                log.debug("Попытка остановки драйвера");
                driver.quit();
            } finally {
                log.debug("Драйвер остановлен");
                pDriver.set(null);
            }
        }
    }

    /**
     * Возвращает мобильный драфйвер
     *
     * @return new AppiumDriver
     */
    @Override
    @SuppressWarnings("unchecked")
    public T getDriver() {
        T driver = (T) pDriver.get();
        if (driver != null) {
            return driver;
        }
        log.debug("Драйвер не был предварительно создан");
        mountDriver();
        return (T) pDriver.get();
    }

    /**
     * Метод используется в качестве проверки условия того, что mobileDriver == null
     *
     * @return null
     */
    @Override
    public boolean isDriverEmpty() {
        return pDriver.get() == null;
    }
}
