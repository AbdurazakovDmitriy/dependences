package ru.rosbank.mobile_plugin.driver;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.IOSMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;

import java.net.MalformedURLException;
import java.net.URL;
@Slf4j
public class IOSDriverManager extends DriverManager{
    private static final MobileConfiguration PROPERTIES = MobileConfiguration.create();

    /**
     * Метод определяет возможности для устроийств IOS и возвращает экземпляр IOSDriver
     * @return new IOSDriver
     */
    @Override
    protected AppiumDriver createDriver() {
        AppiumDriver driver = null;
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, PROPERTIES.getAppiumPlatformName());
        capabilities.setCapability(MobileCapabilityType.APP, PROPERTIES.getAppiumApp());
        capabilities.setCapability(MobileCapabilityType.APPIUM_VERSION, PROPERTIES.getAppiumVersion());
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, PROPERTIES.getAppiumDeviceName());
        capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, PROPERTIES.getAppiumPlatformVersion());
        capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, PROPERTIES.getAppiumBrowserName());
        capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, PROPERTIES.getAppiumAutomationName());
        capabilities.setCapability(MobileCapabilityType.UDID, PROPERTIES.getAppiumUdid());
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, PROPERTIES.getNewCommandTimeout());

        capabilities.setCapability(IOSMobileCapabilityType.AUTO_ACCEPT_ALERTS, PROPERTIES.getAppiumAlertsAutoAccept());

        capabilities.setCapability("bundleId", PROPERTIES.getAppiumBundleId());
        capabilities.setCapability("appPackage", PROPERTIES.getAppiumAppPackage());
        capabilities.setCapability("appActivity", PROPERTIES.getAppiumAppActivity());
        capabilities.setCapability("permissions", PROPERTIES.getAppiumPermissions());
        capabilities.setCapability("autoGrantPermissions", PROPERTIES.getAppiumAutoGrantPermissions());
        capabilities.setCapability("unicodeKeyboard", PROPERTIES.getAppiumKeyboardUnicode());
        capabilities.setCapability("resetKeyboard", PROPERTIES.getAppiumKeyboardReset());
        capabilities.setCapability("connectHardwareKeyboard", false);

        capabilities.setCapability("xcodeOrgId", PROPERTIES.getAppiumXcodeOrgId());
        capabilities.setCapability("xcodeSigningId", PROPERTIES.getAppiumXcodeSigningId());

        loadCustomCapabilities(capabilities, PROPERTIES, log);
        log.info("IOSDriver capabilities: \\n {}",capabilities);

        try {
            URL url = new URL(PROPERTIES.getAppiumUrl());
            driver = new IOSDriver(url, capabilities);
        } catch (MalformedURLException e) {
            log.info("Не удалоь создать IOSDriver",e);
        }

        return driver;
    }
}
