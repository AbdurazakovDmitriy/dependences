package ru.rosbank.mobile_plugin.driver;

import io.appium.java_client.AppiumDriver;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.slf4j.Logger;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Properties;

public abstract class DriverManager {
    protected abstract AppiumDriver createDriver();

    protected boolean loadCustomCapabilities(DesiredCapabilities capabilities, MobileConfiguration PROPERTIES, Logger LOG) {
        Properties properties = new Properties();
        String customCapability = PROPERTIES.getCustomCapabilities();
        if (!customCapability.isEmpty()) {
            String sFolder = System.getProperty("TagConfigFile", "config");
            File file = FileUtils.getFile("src/test/resources/" + sFolder,
                    customCapability);
            if (file.exists()) {
                try (InputStream is = new FileInputStream(file); Reader r = new InputStreamReader(is, StandardCharsets.UTF_8)) {
                    properties.load(r);
                }
                catch (IOException e) {
                    LOG.info("Не удалоь загрузить capability файл", e);
                    return false;
                }
            }

            for(Map.Entry entry : properties.entrySet()) {
                capabilities.setCapability(entry.getKey().toString(), entry.getValue().toString());
            }
            return true;
        }
        return false;
    }
}
