package ru.rosbank.mobile_plugin.driver;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.IOSMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.remote.DesiredCapabilities;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;

import java.net.MalformedURLException;
import java.net.URL;
@Slf4j
public class AndroidDriverManager extends DriverManager {
    private static final MobileConfiguration PROPERTIES = MobileConfiguration.create();
    private AppiumDriver driver;

    /**
     * Метод определяет возможности для устройств Андроид и возвращает экземпляр AndroidDriver
     *
     * @return new AndroidDriver
     */
    @Override
    protected AppiumDriver createDriver() {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, PROPERTIES.getAppiumPlatformName());
        capabilities.setCapability(MobileCapabilityType.APP, PROPERTIES.getAppiumApp());
        capabilities.setCapability(MobileCapabilityType.APPIUM_VERSION, PROPERTIES.getAppiumVersion());
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, PROPERTIES.getAppiumDeviceName());
        capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, PROPERTIES.getAppiumPlatformVersion());
        capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, PROPERTIES.getAppiumBrowserName());
        capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, PROPERTIES.getAppiumAutomationName());
        capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, PROPERTIES.getNewCommandTimeout());

        capabilities.setCapability(IOSMobileCapabilityType.AUTO_ACCEPT_ALERTS, PROPERTIES.getAppiumAlertsAutoAccept());

        capabilities.setCapability("appPackage", PROPERTIES.getAppiumAppPackage());
        capabilities.setCapability("appActivity", PROPERTIES.getAppiumAppActivity());
        capabilities.setCapability("permissions", PROPERTIES.getAppiumPermissions());
        capabilities.setCapability("autoGrantPermissions", PROPERTIES.getAppiumAutoGrantPermissions());
        capabilities.setCapability("unicodeKeyboard", PROPERTIES.getAppiumKeyboardUnicode());
        capabilities.setCapability("resetKeyboard", PROPERTIES.getAppiumKeyboardReset());
        capabilities.setCapability("connectHardwareKeyboard", false);
        capabilities.setCapability("avd", PROPERTIES.getAVD());
        capabilities.setCapability("avdLaunchTimeout", PROPERTIES.getAVDLaunchTimeout());
        capabilities.setCapability("avdReadyTimeout", PROPERTIES.getAVDReadyTimeout());
        capabilities.setCapability("androidDeviceReadyTimeout", PROPERTIES.getAndroidDeviceReadyTimeout());

        capabilities.setCapability("appWaitActivity", PROPERTIES.getAppWaitActivity());

        loadCustomCapabilities(capabilities, PROPERTIES, log);

        log.info("AndroidDriver capabilities: \\n {}", capabilities);

        try {
            URL url = new URL(PROPERTIES.getAppiumUrl());
            driver = new AndroidDriver(url, capabilities);
        } catch (MalformedURLException e) {
            log.info("Не удалоь создать AndroidDriver", e);
        }

        return driver;
    }
}
