package ru.rosbank.mobile_plugin.environment;

import ru.rosbank.automation.environment.IEnvironmentProvider;
import ru.rosbank.mobile_plugin.actions.MobilePageActions;
import ru.rosbank.mobile_plugin.checks.MobilePageChecks;
import ru.rosbank.mobile_plugin.find.MobileFindUtils;
import ru.rosbank.mobile_plugin.reflection.MobileReflection;

public interface IMobileEnvironment extends IEnvironmentProvider<MobileFindUtils,
                                                                MobilePageActions,
        MobilePageChecks,
                                                                MobileReflection> {
}
