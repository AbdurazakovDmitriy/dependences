package ru.rosbank.mobile_plugin.environment;


import ru.rosbank.mobile_plugin.environment.Mask;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface IMaskData {
    String inputFormat();
    String fieldFormat();
    Class<? extends Mask> mask() default Mask.class;
}
