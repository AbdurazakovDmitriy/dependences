package ru.rosbank.mobile_plugin.environment;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * класс позволяющий преобразовывать текст, в соотвествтии с маской
 * например: номер телефона при вводе вероятно будет выглядеть примерно так 4991231212
 * а его фактическое значение + 7 (499) 123 12 12
 * <p>
 * дефолтная реализация маски использует примитивный синтаксис, используя _:{number} - как описание количества принимаемых символов.
 * Поскольку синтаксис разработан для маск данных, предполагается, что последовательность групп совпадает
 * для записи маски мобильного телефона
 * маска поля: + 7 (_:3) _:2 _:2 _:2
 * маска ввода: _:3_:3_:2_:2
 */
public class Mask {

    private final String dataFormat;
    private final String fieldFormat;

    /**
     * @param dataFormat описание "тестового" формата данных
     * @param fieldFormat описание реального формата данных
     */
    public Mask(String dataFormat, String fieldFormat) {
        this.dataFormat = dataFormat;
        this.fieldFormat = fieldFormat;
    }

    protected String replace(String dataFormat, String fieldFormat, String data){
        StringBuilder builder = new StringBuilder();

        Matcher fieldMatcher = Pattern.compile("(.*?)_:(\\d+)").matcher(fieldFormat);
        Matcher dataMatcher = Pattern.compile("(.*?)_:(\\d+)").matcher(dataFormat);

        while (fieldMatcher.find() & dataMatcher.find()) {
            //добавляем все до первого плейсхолдера
            builder.append(fieldMatcher.group(1));
            String formatData = dataMatcher.group(1);
            String s = data.substring(formatData.length());
            String match = s.substring(0, Integer.parseInt(dataMatcher.group(2)));
            builder.append(match);
            data = s.substring(match.length());
        }
        builder.append(fieldFormat.replaceFirst(".*_:\\d+", ""));
        return builder.toString();
    }

    /**
     * конвертирует данные с помощью маски
     * @param data        конвертируемое значение
     * @return полученное значение
     */
    public String convert(String data) {
        return replace(dataFormat,fieldFormat,data);
    }

    /**
     * конвертирует данные с помощью маски
     * @param data        конвертируемое значение
     * @return полученное значение
     */
    public String restore(String data) {
        try {
            return replace(fieldFormat, dataFormat, data);
        } catch (StringIndexOutOfBoundsException e){
            throw new AssertionError(String.format("Element data was corrupted. data '%s' does not correspond [%s] -> [%s]", data, fieldFormat, dataFormat));
        }
    }
}
