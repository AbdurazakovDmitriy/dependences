package ru.rosbank.mobile_plugin.environment;

public enum PlatformName {
    IOS,ANDROID;
}
