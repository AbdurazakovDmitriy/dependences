package ru.rosbank.mobile_plugin.interception;

import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;
import org.apache.commons.beanutils.ConstructorUtils;
import ru.rosbank.mobile_plugin.reflection.MobileReflection;

import java.lang.reflect.Method;
import java.util.List;

/**
 * лист с двойным проксированием и оборачиванием
 */
public class ReferentListInterceptor implements MethodInterceptor {

    private final Class<?> classToMap;
    private final Class<?> targetClass;
    private final List source;

    /**
     * конструктор декорирующей прокси для листа
     *
     * @param classToMap  апиумный локатор элемента
     * @param targetClass целевой класс, в который будут оборачиваться элементы проксируемого листа. В этом классе должен быть конструктор, принимающий {@code classToMap}
     * @param interceptor проксируемый лист
     */
    public ReferentListInterceptor(Class<?> classToMap, Class<?> targetClass, List interceptor) {
        this.classToMap = classToMap;
        this.targetClass = targetClass;
        this.source = interceptor;
    }

    /**
     * проксирует обращение к листу и, если идет обращение к его элементам оборачивает их в targetClass
     *
     * @param o           объект листа (не используется, запросы перенаправляются в source)
     * @param method      используемый метод
     * @param objects     аргументы вызовы
     * @param methodProxy информация о методе
     * @return результат выполнения метода
     * @throws Throwable
     */
    @Override
    public Object intercept(Object o, Method method, Object[] objects, MethodProxy methodProxy) throws Throwable {
        Object result = method.invoke(source, objects);
        return classToMap.isInstance(result)
                ? ConstructorUtils.invokeConstructor(targetClass, new Object[]{result}, new Class[]{classToMap})
                : result;
    }
}
