package ru.rosbank.mobile_plugin.interception;

import io.appium.java_client.HasSessionDetails;
import io.appium.java_client.pagefactory.*;
import io.appium.java_client.pagefactory.bys.ContentMappedBy;
import io.appium.java_client.pagefactory.bys.ContentType;
import io.appium.java_client.pagefactory.bys.builder.AppiumByBuilder;
import io.appium.java_client.pagefactory.bys.builder.ByAll;
import io.appium.java_client.pagefactory.bys.builder.ByChained;
import io.appium.java_client.pagefactory.bys.builder.HowToUseSelectors;
import org.apache.commons.lang3.reflect.MethodUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.support.*;
import ru.rosbank.mobile_plugin.reflection.MobileReflection;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.function.ToIntFunction;

/**
 * класс ByBuilder
 */
public class ByBuilder extends AppiumByBuilder {

    private static final Class[] ANNOTATION_ARGUMENTS = new Class[0];
    private static final Object[] ANNOTATION_PARAMETERS = new Object[0];

    /**
     * конструктор билдера
     *
     * @param hasSessionDetails драйвера
     */
    protected ByBuilder(HasSessionDetails hasSessionDetails) {
        super(hasSessionDetails.getPlatformName(), hasSessionDetails.getAutomationName());
    }

    /**
     * строит общий by для поля
     *
     * @return комбинированный by
     */
    public By buildBy() {
        this.assertValidAnnotations();
        By defaultBy = this.buildDefaultBy();
        By mobileNativeBy = this.buildMobileNativeBy();
        String idOrName = ((Field) this.annotatedElementContainer.getAnnotated()).getName();
        if (defaultBy == null && mobileNativeBy == null) {
            defaultBy = new ByIdOrName(((Field) this.annotatedElementContainer.getAnnotated()).getName());
            mobileNativeBy = new By.ById(idOrName);
            return this.returnMappedBy(defaultBy, mobileNativeBy);
        } else if (defaultBy == null) {
            defaultBy = new ByIdOrName(((Field) this.annotatedElementContainer.getAnnotated()).getName());
            return this.returnMappedBy(defaultBy, mobileNativeBy);
        } else {
            return mobileNativeBy == null ? this.returnMappedBy(defaultBy, defaultBy) : this.returnMappedBy(defaultBy, mobileNativeBy);
        }
    }

    /**
     * создает платформо-зависимые
     *
     * @param byDefault   кросс-платформенный by
     * @param nativeAppBy нативный by
     * @return By
     */
    private By returnMappedBy(By byDefault, By nativeAppBy) {
        Map<ContentType, By> contentMap = new HashMap<>();
        contentMap.put(ContentType.HTML_OR_DEFAULT, byDefault);
        contentMap.put(ContentType.NATIVE_MOBILE_SPECIFIC, nativeAppBy);
        return new ContentMappedBy(contentMap);
    }

    /**
     * проверяет необходимость кэширования результата
     *
     * @return следует ли кэшировать
     */
    public boolean isLookupCached() {
        AnnotatedElement annotatedElement = this.annotatedElementContainer.getAnnotated();
        return annotatedElement.getAnnotation(CacheLookup.class) != null;
    }

    /**
     * проверяет что не были одновременно использованы аннотации уникальная/комбинированная/один из
     */
    protected void assertValidAnnotations() {
        AnnotatedElement annotatedElement = this.annotatedElementContainer.getAnnotated();
        FindBy findBy = annotatedElement.getAnnotation(FindBy.class);
        FindBys findBys = annotatedElement.getAnnotation(FindBys.class);
        checkDisallowedAnnotationPairs(findBy, findBys);
        FindAll findAll = annotatedElement.getAnnotation(FindAll.class);
        checkDisallowedAnnotationPairs(findBy, findAll);
        checkDisallowedAnnotationPairs(findBys, findAll);
    }

    /**
     * проверяет аннотации на совместимость
     *
     * @param a1 несовмеситимая аннотация 1
     * @param a2 несовместимая аннотация 2
     * @throws IllegalArgumentException
     */
    private void checkDisallowedAnnotationPairs(Annotation a1, Annotation a2) throws IllegalArgumentException {
        if (a1 != null && a2 != null) {
            throw new IllegalArgumentException("If you use a '@" + a1.getClass().getSimpleName() + "' annotation, " + "you must not also use a '@" + a2.getClass().getSimpleName() + "' annotation");
        }
    }

    /**
     * создает общий By локатор для поля
     *
     * @return кросс-платформенный By
     */
    protected By buildDefaultBy() {
        Field annotatedElement = (Field) this.annotatedElementContainer.getAnnotated();
        By defaultBy = null;
        FindBy findBy = annotatedElement.getAnnotation(FindBy.class);
        if (findBy != null) {
            defaultBy = new FindBy.FindByBuilder().buildIt(findBy, annotatedElement);
        }

        if (defaultBy == null) {
            FindBys findBys = annotatedElement.getAnnotation(FindBys.class);
            if (findBys != null) {
                defaultBy = new FindBys.FindByBuilder().buildIt(findBys, annotatedElement);
            }
        }

        if (defaultBy == null) {
            FindAll findAll = annotatedElement.getAnnotation(FindAll.class);
            if (findAll != null) {
                defaultBy = new FindAll.FindByBuilder().buildIt(findAll, annotatedElement);
            }
        }

        return defaultBy;
    }

    /**
     * определяет платформо-зависимые аннотации
     *
     * @return комбинированный by для платформы
     */
    protected By buildMobileNativeBy() {
        AnnotatedElement annotatedElement = this.annotatedElementContainer.getAnnotated();
        HowToUseLocators howToUseLocators = annotatedElement.getAnnotation(HowToUseLocators.class);
        Optional<HowToUseLocators> howToUseLocatorsOptional = Optional.ofNullable(howToUseLocators);
        if (isAndroid()) {
            return buildMobileBy(howToUseLocatorsOptional.map(HowToUseLocators::androidAutomation)
                    .orElse(null), this.getBys(AndroidFindBy.class, AndroidFindBys.class, AndroidFindAll.class));
        }
        if (isIOSXcuit()) {
            return buildMobileBy(howToUseLocatorsOptional.map(HowToUseLocators::iOSXCUITAutomation)
                    .orElse(null), this.getBys(iOSXCUITFindBy.class, iOSXCUITFindBys.class, iOSXCUITFindAll.class));
        }
        throw new RuntimeException(String.format("Platform '%s' not supported", platform));
    }

    /**
     * собирает все by для поля
     *
     * @param singleLocator  аннотация уникального локатора
     * @param chainedLocator аннотация локатора по цепочке
     * @param allLocator     аннотация локатора по принципу все
     * @return массив by
     */
    private By[] getBys(Class<? extends Annotation> singleLocator, Class<? extends Annotation> chainedLocator, Class<? extends Annotation> allLocator) {
        ToIntFunction<Annotation> function = t -> {
            try {
                return (int) MethodUtils.invokeMethod(t,"priority");
            } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                return -2;
            }
        };
        Comparator<Annotation> comparator = Comparator.comparingInt(function);

        AnnotatedElement annotatedElement = this.annotatedElementContainer.getAnnotated();
        List<Annotation> annotations = Arrays.asList(annotatedElement.getAnnotationsByType(singleLocator));
        annotations.addAll(Arrays.asList(annotatedElement.getAnnotationsByType(chainedLocator)));
        annotations.addAll(Arrays.asList(annotatedElement.getAnnotationsByType(allLocator)));
        annotations.sort(comparator);
        List<By> result = new ArrayList<>();
        for (Annotation a : annotations) {
            Class<?> annotationClass = a.annotationType();
            if (singleLocator.equals(annotationClass)) {
                result.add(createBy(new Annotation[]{a}, HowToUseSelectors.USE_ONE));
            } else {
                Annotation[] subLocators;
                try {
                    Method value = annotationClass.getMethod("value", ANNOTATION_ARGUMENTS);
                    subLocators = (Annotation[]) value.invoke(a, ANNOTATION_PARAMETERS);
                    Arrays.sort(subLocators, comparator);
                } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException ignored) {
                    throw new ClassCastException(String.format("The annotation '%s' has no convenient '%s' method which returns array of annotations", annotationClass.getName(), "value"));
                }
                HowToUseSelectors howToUseSelectors = chainedLocator.equals(annotationClass) ? HowToUseSelectors.BUILD_CHAINED : HowToUseSelectors.USE_ANY;
                result.add(createBy(subLocators, howToUseSelectors));
            }
        }

        return result.toArray(new By[0]);
    }

    /**
     * создает комбинированный вариант By
     *
     * @param locatorGroupStrategy тип комбинирования (один из или цепочка исполненя {@link LocatorGroupStrategy})
     * @param bys                  массив by-локаторов
     * @return
     */
    private static By buildMobileBy(LocatorGroupStrategy locatorGroupStrategy, By[] bys) {
        if (bys.length == 0) {
            return null;
        }
        return Optional.ofNullable(locatorGroupStrategy).orElse(LocatorGroupStrategy.CHAIN)
                .equals(LocatorGroupStrategy.ALL_POSSIBLE)
                ? new ByAll(bys)
                : new ByChained(bys);
    }
}
