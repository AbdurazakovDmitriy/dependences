package ru.rosbank.mobile_plugin.interception;

import io.appium.java_client.pagefactory.interceptors.InterceptorOfAListOfElements;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.pagefactory.ElementLocator;

import java.lang.reflect.Method;
import java.util.List;

public class ElementListInterceptor extends InterceptorOfAListOfElements {
    /**
     * конструктор прокси для {@link List<io.appium.java_client.MobileElement>}
     * @param locator апиумный локатор элемента
     */
    public ElementListInterceptor(ElementLocator locator) {
        super(locator);
    }

    /**
     * проксирует обращение к {@link List<io.appium.java_client.MobileElement>}
     * @param elements истинный лист элементов
     * @param method вызываемый метод
     * @param args параметры метода
     * @return результат выполнения метода
     * @throws Throwable ошибка, возникшая в процессе исполнения
     */
    protected Object getObject(List<WebElement> elements, Method method, Object[] args) throws Throwable {
        try {
            return method.invoke(elements, args);
        } catch (Throwable e) {
            throw ThrowableUtil.extractReadableException(e);
        }
    }
}