package ru.rosbank.mobile_plugin.interception;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.pagefactory.AppiumElementLocatorFactory;
import io.appium.java_client.pagefactory.utils.ProxyFactory;
import lombok.extern.slf4j.Slf4j;
import net.sf.cglib.proxy.MethodInterceptor;
import org.apache.commons.lang3.reflect.ConstructorUtils;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.pagefactory.ElementLocator;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import ru.rosbank.automation.environment.IContext;
import ru.rosbank.automation.environment.ITitledElement;
import ru.rosbank.automation.environment.IWrapElement;
import ru.rosbank.automation.utils.ReflectionUtils;
import ru.rosbank.mobile_plugin.environment.IMaskData;
import ru.rosbank.mobile_plugin.elements.TypeResolver;
import ru.rosbank.mobile_plugin.environment.PlatformName;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;
import ru.sbtqa.tag.pagefactory.annotations.ElementTitle;
import ru.sbtqa.tag.pagefactory.environment.Environment;

import java.lang.reflect.*;
import java.time.Duration;
import java.util.*;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;

@Slf4j
public class MobileDecorator {

    private final static MobileConfiguration PROPERTIES = MobileConfiguration.create();

    /**
     * набор проксей для поля. Каждый элемент сета - предикат, который должен проверять относится ли он к полю.
     * Если да, он должен выполнить проксирование
     */
    private final Set<BiPredicate<Field, IContext>> proxyProviders = new LinkedHashSet<>();

    /**
     * получае тип параметра листа
     *
     * @param field поле, содержащее лист
     * @return Тип листа
     */
    @Contract(pure = true)
    protected Class getListGenericClass(@NotNull Field field) {
        ParameterizedType parameterizedType = (ParameterizedType) field.getGenericType();
        return (Class) parameterizedType.getActualTypeArguments()[0];
    }

    /**
     * Проверяет является ли поле листом заданного типа
     *
     * @param genericType ожидаемый тип
     * @param field       поле
     * @return {@code true} если поле - лист, заданного типа
     */
    @Contract(pure = true)
    protected boolean isDecoratableList(@NotNull Class<?> genericType, @NotNull Field field) {
        if (List.class.isAssignableFrom(field.getType())) {
            return genericType.isAssignableFrom(getListGenericClass(field));
        }
        return false;
    }

    /**
     * Проверяет следует ли оборачивать поле
     *
     * @param field поле
     * @return {@code true} если поле необходимо обернуть
     */
    @Contract(pure = true)
    protected boolean shallWrapSingle(@NotNull Field field) {
        return IWrapElement.class.isAssignableFrom(field.getType());
    }

    /**
     * проверяет следует ли оборачивать элементы листа
     *
     * @param field поле, содержащее лист
     * @return {@code true} если элементы листа необходимо обернуть
     */
    @Contract(pure = true)
    protected boolean shallWrapMultiple(@NotNull Field field) {
        return isDecoratableList(IWrapElement.class, field);
    }

    /**
     * Проверяет следует ли проксировать поле (без оборачивания)
     *
     * @param field поле
     * @return {@code true} если поле следует проксировать
     */
    @Contract(pure = true)
    protected boolean shallDecorateSingle(@NotNull Field field) {
        return RemoteWebElement.class.isAssignableFrom(field.getType());
    }

    /**
     * проверяет следует ли проксировать элементы листа(без оборачивания)
     *
     * @param field поле, содержащее лист
     * @return {@code true} если элементы листа необходимо проксировать
     */
    @Contract(pure = true)
    protected boolean shallDecorateMultiple(@NotNull Field field) {
        return isDecoratableList(RemoteWebElement.class, field);
    }

    /**
     * создает прокси для поля
     *
     * @param enhancedClass ожидаемый класс
     * @param interceptor   перехватчик
     * @param <T>           тип результата
     * @return созданная прокси
     */
    @Contract(pure = true)
    @NotNull
    private <T> T buildProxy(@NotNull Class<T> enhancedClass, @NotNull MethodInterceptor interceptor) {
        return ProxyFactory.getEnhancedProxy(enhancedClass, interceptor);
    }

    @Contract(pure = true)
    @NotNull
    protected Class proxyForAbstract(@NotNull TypeResolver.TypeInfo typeInfo) {
        return Optional.ofNullable(TypeResolver.getImplementationForField(typeInfo))
                .orElseThrow(() -> new RuntimeException("Не было зарегестрировано имплементации для '" + typeInfo.getType().getCanonicalName() + "'"));
    }

    /**
     * создает прокси для обертки элемента {@link IWrapElement} {@link ElementInterceptor}
     *
     * @param field   поле
     * @param locator локатор элемента
     * @return созданная прокси
     */
    @NotNull
    protected Object proxyForWrappedSingle(@NotNull Field field, @NotNull ElementLocator locator) {
        Object wrapped = proxyForLocator(locator);
        Class<?> type = field.getType();
        if (type.isInterface() || Modifier.isAbstract(type.getModifiers())) {
            TypeResolver.TypeInfo typeInfo = new TypeResolver.TypeInfo(type, (WebElement) wrapped, field.getAnnotations());
            type = proxyForAbstract(typeInfo);
        }
        BiFunction<Constructor, Object[], ?> function = (con, args) -> {
            try {
                return con.newInstance(args);
            } catch (IllegalAccessException | InvocationTargetException | InstantiationException e) {
                return null;
            }
        };
        Constructor constructor = ConstructorUtils.getAccessibleConstructor(type, MobileElement.class);
        Object instance = function.apply(constructor, new Object[]{wrapped});
        if (instance == null) {
            throw new RuntimeException(String.format("Не удалось создать объект класса '%s'", type.getCanonicalName()));
        }
        if (instance instanceof ITitledElement) {
            ElementTitle title = field.getAnnotation(ElementTitle.class);
            if (title != null) {
                try {
                    ReflectionUtils.resetField("title", title.value(), instance);
                } catch (Exception any) {
                    log.debug("Не удалось загрузить имя '{}' для типа '{}'", title.value(), instance.getClass().getCanonicalName());
                }
            }
        }
        if (instance instanceof IMaskData) {
            IMaskData iMaskData = field.getAnnotation(IMaskData.class);
            if (iMaskData != null) {
                try {
                    constructor = ConstructorUtils.getAccessibleConstructor(iMaskData.mask(), String.class, String.class);
                    Object mask = function.apply(constructor, new Object[]{iMaskData.inputFormat(), iMaskData.fieldFormat()});
                    ReflectionUtils.resetField("mask", mask, instance);
                } catch (Exception any) {
                    log.debug("Не удалось загрузить маску '{},{},{}' для типа '{}'",
                            iMaskData.inputFormat(), iMaskData.fieldFormat(), iMaskData.mask().getCanonicalName(), instance.getClass().getCanonicalName());
                }
            }
        }
        return instance;
    }

    /**
     * создает прокси для обертки листа элементов {@link IWrapElement} {@link ReferentListInterceptor}
     *
     * @param field   поле
     * @param locator локатор листа элементов
     * @return созданная прокси
     */
    @NotNull
    protected Object proxyForWrappedMultiple(@NotNull Field field, @NotNull ElementLocator locator) {
        List list = proxyForListLocator(locator);
        return buildProxy(List.class, new ReferentListInterceptor(MobileElement.class, getListGenericClass(field), list));
    }

    /**
     * создает прокси для элемента {@link ElementInterceptor}
     *
     * @param locator локатор элемента
     * @return созданная прокси
     */
    @NotNull
    protected Object proxyForLocator(@NotNull ElementLocator locator) {
        Class elementClass = PROPERTIES.getPlatformBasedElements()
                ? PROPERTIES.getAppiumPlatformName() == PlatformName.IOS
                ? IOSElement.class
                : AndroidElement.class
                : MobileElement.class;
        return buildProxy(elementClass, new ElementInterceptor(locator, Environment.getDriverService().getDriver()));
    }

    /**
     * создает прокси для листа элементов {@link ElementListInterceptor}
     *
     * @param locator локатор листа элементов
     * @return созданная прокси
     */
    @NotNull
    protected List<MobileElement> proxyForListLocator(@NotNull ElementLocator locator) {
        return buildProxy(List.class, new ElementListInterceptor(locator));
    }

    /**
     * регистрирует обработчик поля
     *
     * @param shallDecorate условие декорирования
     * @param decorator     декоратор
     */
    protected void registerProvider(@NotNull Predicate<Field> shallDecorate, @NotNull Function<Field, ?> decorator) {
        addProxyProvider((field, page) -> {
            if (shallDecorate.test(field)) {
                Object handler = decorator.apply(field);
                field.setAccessible(true);
                try {
                    field.set(page, handler);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException();
                }
                return true;
            }
            return false;
        });
    }

    /**
     * загрузка дефолтных обработчиков.
     *
     * @param factory фабрика локаторов
     * @implNote порядок загрзки имеет значение. Если провайдер выполняет оборачивание - цикл обработки прекращается. Поэтому более частные случаи должны обрабатываться (и быть загруженными) до более общих
     */
    protected void initProxying(@NotNull ElementLocatorFactory factory) {
        registerProvider(this::shallWrapSingle, field -> proxyForWrappedSingle(field, factory.createLocator(field)));
        registerProvider(this::shallWrapMultiple, field -> proxyForWrappedMultiple(field, factory.createLocator(field)));
        registerProvider(this::shallDecorateSingle, field -> proxyForLocator(factory.createLocator(field)));
        registerProvider(this::shallDecorateMultiple, field -> proxyForListLocator(factory.createLocator(field)));
    }

    /**
     * конструктор поддерживающий передачу фабрики
     *
     * @param factory фабрика локаторов
     */
    protected MobileDecorator(ElementLocatorFactory factory) {
        initProxying(factory);
    }

    /**
     * выполняет проксирование полей объекта
     *
     * @param context проксируемый контекст (страница или блок)
     */
    public void decorate(IContext context) {
        Field[] fields = context.getClass().getDeclaredFields();
        for (Field field : fields) {
            for (BiPredicate<Field, IContext> proxyProvider : proxyProviders) {
                if (proxyProvider.test(field, context)) {
                    break;
                }
            }
        }
    }

    /**
     * дефолтный конструктор, использующий AppiumLocatorFactory
     * {@link MobileDecorator#MobileDecorator(ElementLocatorFactory)}
     *
     * @param searchContext контекст поиска
     */
    public MobileDecorator(SearchContext searchContext) {
        this(new AppiumElementLocatorFactory(searchContext, Duration.ofSeconds(3), new ByBuilder(Environment.getDriverService().getDriver())));
    }

    /**
     * добавляет прокси-провайдер
     *
     * @param proxyProvider обработчик поля проксируемого объекта
     */
    protected void addProxyProvider(BiPredicate<Field, IContext> proxyProvider) {
        proxyProviders.add(proxyProvider);
    }
}
