package ru.rosbank.mobile_plugin.interception;

import io.appium.java_client.pagefactory.interceptors.InterceptorOfASingleElement;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.pagefactory.ElementLocator;

import java.lang.reflect.Method;

public class ElementInterceptor extends InterceptorOfASingleElement {
    @Nullable
    private String $title = null;

    @Contract(pure = true)
    private boolean $hasTitle() {
        return $title == null;
    }

    @Contract(pure = true)
    private String $getTitle() {
        return $title;
    }

    private void $setTitle(@NotNull String title) {
        $title = title;
    }


    /**
     * конструктор прокси для MobileElement
     *
     * @param locator апиумный локатор элемента
     * @param driver  драйвер поиска
     */
    public ElementInterceptor(@NotNull ElementLocator locator, @NotNull WebDriver driver) {
        super(locator, driver);
    }

    /**
     * конструктор прокси для MobileElement
     *
     * @param locator апиумный локатор элемента
     * @param driver  драйвер поиска
     */
    public ElementInterceptor(@NotNull ElementLocator locator, @NotNull WebDriver driver, @Nullable String title) {
        this(locator, driver);
        this.$title=title;
    }

    /**
     * проксирует обращение к {@link WebElement}
     *
     * @param element истинный элемент
     * @param method  вызываемый метод
     * @param args    параметры метода
     * @return результат выполнения метода
     * @throws Throwable ошибка, возникшая в процессе исполнения
     */
    @Nullable
    protected Object getObject(WebElement element, @NotNull Method method, @NotNull Object[] args) throws Throwable {
        try {
            String methodName = method.getName();
            if (methodName.startsWith("\\$")) {
                switch (methodName) {
                    case "$hasTitle":
                        return $hasTitle();
                    case "$getTitle":
                        return $getTitle();
                    case "$setTitle":
                        $setTitle((String) args[0]);
                        return null;
                }
            }
            if (methodName.equals("getAttribute")) {
                switch ((String) args[0]) {
                    case "$->hasTitle":
                        return $hasTitle();
                    case "$->getTitle":
                        return $getTitle();
                }
            }
            return method.invoke(element, args);
        } catch (Throwable e) {
            throw ThrowableUtil.extractReadableException(e);
        }
    }
}

