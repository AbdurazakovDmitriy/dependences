package ru.rosbank.mobile_plugin.interception;

import java.lang.reflect.InvocationTargetException;

public class ThrowableUtil {
    private static final String INVALID_SELECTOR_PATTERN = "Invalid locator strategy:";

    ThrowableUtil() {
    }


    protected static Throwable extractReadableException(Throwable e) {
        if (e.getClass()==Throwable.class){
            return e;
        }
        return !RuntimeException.class.equals(e.getClass()) && !InvocationTargetException.class.equals(e.getClass()) ? e : extractReadableException(e.getCause());
    }
}