package ru.rosbank.mobile_plugin.elements.base;

import io.appium.java_client.MobileElement;
import org.openqa.selenium.NoSuchElementException;
import ru.rosbank.mobile_plugin.elements.MobileTypifiedElement;
import ru.rosbank.mobile_plugin.elements.core.ISelect;

public class Select extends MobileTypifiedElement implements ISelect {
    public Select(MobileElement element) {
        super(element);
    }

    public String getText() {
        try {
            return getSelectedOption().getText();
        } catch (NoSuchElementException e) {
            return "";
        }
    }
}
