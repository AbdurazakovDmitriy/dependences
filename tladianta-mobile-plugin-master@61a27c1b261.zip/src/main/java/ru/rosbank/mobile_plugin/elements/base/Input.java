package ru.rosbank.mobile_plugin.elements.base;

import io.appium.java_client.MobileElement;
import ru.rosbank.mobile_plugin.elements.MobileTypifiedElement;
import ru.rosbank.mobile_plugin.elements.core.text.IEditText;

public class Input extends MobileTypifiedElement implements IEditText {
    public Input(MobileElement element) {
        super(element);
    }
}
