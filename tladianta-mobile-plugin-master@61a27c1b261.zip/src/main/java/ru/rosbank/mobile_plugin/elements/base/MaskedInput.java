package ru.rosbank.mobile_plugin.elements.base;

import io.appium.java_client.MobileElement;
import lombok.Getter;
import ru.rosbank.mobile_plugin.elements.core.text.IEditMaskedText;
import ru.rosbank.mobile_plugin.environment.Mask;

public class MaskedInput extends Input implements IEditMaskedText {
    @Getter
    private Mask mask;

    public MaskedInput(MobileElement element) {
        super(element);
    }

    /**
     * обычно поля с маской автоматически форматируют данные под эту маску, поэтому этот метод вводит текст
     * в том виде, в котором он пришел как параметр
     * @param text
     */
    @Override
    public void setText(String text) {
        //super.setText(getMask().convert(text));
        super.setText(text);
    }
    /**
     * вытаскивает текст без маски (например 12/12/2012 ->12122012)
     */
    @Override
    public String getText() {
        return getMask().restore(super.getText());
    }
}
