package ru.rosbank.mobile_plugin.elements.core;

import org.openqa.selenium.WebElement;
import ru.rosbank.mobile_plugin.elements.core.text.IHaveText;

public interface ISelectableItem<T> extends IClickable<T>, IHaveText<T> {

    default boolean isSelected(){
        return ((WebElement)getWrappedElement()).isSelected();
    }

    default void select(){
        click();
    }
}
