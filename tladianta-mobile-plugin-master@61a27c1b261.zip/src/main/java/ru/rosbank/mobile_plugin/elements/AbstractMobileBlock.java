package ru.rosbank.mobile_plugin.elements;

import io.appium.java_client.MobileElement;
import ru.rosbank.automation.environment.IContext;
import ru.rosbank.mobile_plugin.interception.MobileDecorator;

public abstract class AbstractMobileBlock extends MobileTypifiedElement implements IContext {
    public AbstractMobileBlock(MobileElement element) {
        super(element);
        proxyContext();
    }

    /**
     * оборачивание элементов блока в прокси
     * для использования иного декоратора этот метод можно переопределить
     */
    protected void proxyContext(){
        new MobileDecorator(getWrappedElement()).decorate(this);
    }
}

