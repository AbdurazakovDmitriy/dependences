package ru.rosbank.mobile_plugin.elements.core;

import org.openqa.selenium.WebElement;
@FunctionalInterface
public interface ICheckBox<T> extends IClickable<T> {
    /**
     * включить чекбокс
     */
    default void check() {
        check(true);
    }

    /**
     * выключить чекбокс
     */
    default void uncheck() {
        check(false);
    }

    /**
     * установить значение в зависимости от состояния
     *
     * @param targetState {@code true} - включить {@code false} - выключить
     */
    default void check(boolean targetState) {
        if (targetState != getState()) {
            click();
        }
    }

    /**
     * получить текущее состояние
     *
     * @return {@code true} - если включен {@code false} - если выключен
     */
    default boolean getState() {
        return Boolean.parseBoolean(((WebElement)getWrappedElement()).getAttribute("checked"));
    }
}
