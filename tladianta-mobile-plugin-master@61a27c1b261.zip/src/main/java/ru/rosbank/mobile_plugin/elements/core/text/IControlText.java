package ru.rosbank.mobile_plugin.elements.core.text;

import org.junit.Assert;
import org.openqa.selenium.WebElement;

/**
 * интерфейс
 * @param <T>
 */
public interface IControlText<T> extends IEditText<T>{

    /**
     * Проверяет текст после ввода
     * @param text вводимый текст
     */
    default void assertText(String text){
        Assert.assertEquals(text,getText());
    }
    @Override
    default void setText(String text){
        WebElement element= (WebElement) getWrappedElement();
        element.sendKeys(text);
        assertText(text);
    }
}
