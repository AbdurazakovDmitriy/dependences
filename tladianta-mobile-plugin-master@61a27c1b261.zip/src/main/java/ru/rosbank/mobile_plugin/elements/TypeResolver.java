package ru.rosbank.mobile_plugin.elements;

import lombok.Getter;
import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.WebElement;
import ru.rosbank.automation.environment.IWrapElement;
import ru.rosbank.mobile_plugin.environment.PlatformName;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;

import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Predicate;

/**
 * Класс представляет собой регистр "конвертеров", позволяющих "отрендерить элемент" - обернуть его в обертку, зависимую от его состония
 * Предположим, что у вас есть некое текстовое поле, которое в IOS следует заполнить одним образом (например чистым текстом), а в Android другим
 * (с учетом маски). Вы можете зарегестрировать здесь некоторый резолвер, который будет автоматически, в зависимости от платформы возвращать
 * подходящее подходящий класс
 */
public class TypeResolver {
    @Getter
    public static final class TypeInfo {
        private final Class type;
        private final WebElement element;
        private final Annotation[] annotations;

        public TypeInfo(Class type, WebElement element, Annotation[] annotations) {
            this.type = type;
            this.element = element;
            this.annotations = annotations;
        }
    }

    private static final MobileConfiguration CONFIGURATION=MobileConfiguration.create();

    /**
     * список рендеров элементов
     */
    private static final ThreadLocal<Map<Predicate<TypeInfo>, Class<?>>> renderMap = ThreadLocal.withInitial(HashMap::new);

    /**
     * регистрация кондишна для автоматического рендера инрефейса или абстрактного класса
     * регистрируя условия следует помнить, что всегда применяется первое подходящее условие
     *
     * @param predicate           интерфейс или асбтрактный класс
     * @param implementationClass класс, реализизующий
     */
    public static <D extends IWrapElement, I extends D> void registerType(Predicate<TypeInfo> predicate, Class<I> implementationClass) {
        renderMap.get().put(predicate, implementationClass);
    }

    /**
     * создание рендера для конкретной платформы
     * @param platformName платформа
     * @param declarationClass интерфейс или абстрактный класс, для которых регистрируется реализация
     * @param implementationClass реализация интерфейса
     */
    public static <D extends IWrapElement, I extends D> void registerType(PlatformName platformName, @NotNull Class<D> declarationClass, Class<I> implementationClass) {
        renderMap.get().put(o -> o.getType() == declarationClass && CONFIGURATION.getAppiumPlatformName()==platformName,
                implementationClass);
    }

    /**
     * регистрация типа элемента как подлежащего рендеру по классу
     *
     * @param declarationClass    интерфейс или асбтрактный класс
     * @param implementationClass класс, реализизующий
     */
    public static <D extends IWrapElement, I extends D> void registerType(@NotNull Class<D> declarationClass, Class<I> implementationClass) {
        renderMap.get().put(o -> o.getType() == declarationClass, implementationClass);
    }

    /**
     * регистрация типа элемента как подлежащего рендеру
     *
     * @param declarationClass    интерфейс или асбтрактный класс
     * @param implementationClass полное имя класса реализуещего данный функционал
     */
    public static void registerType(Class declarationClass, String implementationClass) {
        try {
            registerType(declarationClass, (Class<IWrapElement>) Class.forName(implementationClass));
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Class was not loaded", e);
        } catch (ClassCastException e) {
            throw new RuntimeException("Class to render must extend RenderableElement", e);
        }
    }

    public static Class getImplementationForField(TypeInfo typeInfo) {
        return renderMap.get().entrySet().stream()
                .filter(o->o.getKey().test(typeInfo)).map(Map.Entry::getValue)
                .findFirst()
                .orElse(null);
    }
}
