package ru.rosbank.mobile_plugin.elements.base;

import io.appium.java_client.MobileElement;
import ru.rosbank.mobile_plugin.elements.core.text.IControlText;

public class ControlledInput extends Input implements IControlText {
    public ControlledInput(MobileElement element) {
        super(element);
    }
}
