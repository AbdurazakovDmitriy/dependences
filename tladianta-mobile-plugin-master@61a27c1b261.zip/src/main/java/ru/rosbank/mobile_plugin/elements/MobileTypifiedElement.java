package ru.rosbank.mobile_plugin.elements;

import io.appium.java_client.MobileElement;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Coordinates;
import org.openqa.selenium.remote.FileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.Response;
import ru.rosbank.automation.environment.ITitledElement;
import ru.rosbank.automation.environment.IWrapElement;
import ru.rosbank.automation.utils.ReflectionUtils;
import ru.rosbank.mobile_plugin.elements.core.IClickable;
import ru.sbtqa.tag.pagefactory.utils.Wait;

import java.util.List;
import java.util.Map;
import java.util.Objects;

public abstract class MobileTypifiedElement<T extends MobileElement> extends MobileElement implements ITitledElement, IClickable<T> {
    private T element;

    public MobileTypifiedElement(T element) {
        this.element = element;
    }

    @Override
    public T getWrappedElement() {
        return element;
    }

    @Override
    public Point getCenter() {
        return getWrappedElement().getCenter();
    }

    @Override
    public List findElements(By by) {
        return getWrappedElement().findElements(by);
    }

    @Override
    public String getTitle() {
        String title = getWrappedElement().getAttribute("$->getTitle");
        return title != null ? title : "undefined";
    }

    @Override
    public List findElements(String by, String using) {
        return getWrappedElement().findElements(by, using);
    }

    @Override
    public List findElementsById(String id) {
        return getWrappedElement().findElementsById(id);
    }

    @Override
    public List findElementsByLinkText(String using) {
        return getWrappedElement().findElementsByLinkText(using);
    }

    @Override
    public List findElementsByPartialLinkText(String using) {
        return getWrappedElement().findElementsByPartialLinkText(using);
    }

    @Override
    public List findElementsByTagName(String using) {
        return getWrappedElement().findElementsByTagName(using);
    }

    @Override
    public List findElementsByName(String using) {
        return getWrappedElement().findElementsByName(using);
    }

    @Override
    public List findElementsByClassName(String using) {
        return getWrappedElement().findElementsByClassName(using);
    }

    @Override
    public List findElementsByCssSelector(String using) {
        return getWrappedElement().findElementsByCssSelector(using);
    }

    @Override
    public List findElementsByXPath(String using) {
        return getWrappedElement().findElementsByXPath(using);
    }

    @Override
    public List findElementsByAccessibilityId(String using) {
        return getWrappedElement().findElementsByAccessibilityId(using);
    }

    @Override
    public void setValue(String value) {
        getWrappedElement().setValue(value);
    }

    @Override
    public Response execute(String driverCommand, Map<String, ?> parameters) {
        return getWrappedElement().execute(driverCommand, parameters);
    }

    @Override
    public Response execute(String command) {
        return getWrappedElement().execute(command);
    }

    @Override
    public MobileElement findElement(By by) {
        return getWrappedElement().findElement(by);
    }

    @Override
    public MobileElement findElement(String by, String using) {
        return getWrappedElement().findElement(by, using);
    }

    @Override
    public MobileElement findElementById(String id) {
        return getWrappedElement().findElementById(id);
    }

    @Override
    public MobileElement findElementByLinkText(String using) throws WebDriverException {
        return getWrappedElement().findElementByLinkText(using);
    }

    @Override
    public MobileElement findElementByPartialLinkText(String using) throws WebDriverException {
        return getWrappedElement().findElementByPartialLinkText(using);
    }

    @Override
    public MobileElement findElementByTagName(String using) {
        return getWrappedElement().findElementByTagName(using);
    }

    @Override
    public MobileElement findElementByName(String using) {
        return getWrappedElement().findElementByName(using);
    }

    @Override
    public MobileElement findElementByClassName(String using) {
        return getWrappedElement().findElementByClassName(using);
    }

    @Override
    public MobileElement findElementByCssSelector(String using) throws WebDriverException {
        return getWrappedElement().findElementByCssSelector(using);
    }

    @Override
    public MobileElement findElementByXPath(String using) {
        return getWrappedElement().findElementByXPath(using);
    }

    @Override
    public void submit() throws WebDriverException {
        getWrappedElement().submit();
    }

    @Override
    public String getCssValue(String propertyName) throws WebDriverException {
        return getWrappedElement().getCssValue(propertyName);
    }

    @Override
    public MobileElement findElementByAccessibilityId(String using) {
        return null;
    }

    @Override
    protected void setFoundBy(SearchContext foundFrom, String locator, String term) {
        ReflectionUtils.resetField("foundBy", String.format("[%s] -> %s: %s", foundFrom, locator, term), getWrappedElement());
    }

    @Override
    public void setParent(RemoteWebDriver parent) {
        getWrappedElement().setParent(parent);
    }

    @Override
    public String getId() {
        return getWrappedElement().getId();
    }

    @Override
    public void setId(String id) {
        getWrappedElement().setId(id);
    }

    @Override
    public void setFileDetector(FileDetector detector) {
        getWrappedElement().setFileDetector(detector);
    }

    @Override
    public void click() {
        getWrappedElement().click();
    }

    @Override
    public void sendKeys(CharSequence... keysToSend) {
        getWrappedElement().sendKeys(keysToSend);
    }

    @Override
    public void clear() {
        getWrappedElement().clear();
    }

    @Override
    public String getTagName() {
        return getWrappedElement().getTagName();
    }

    @Override
    public String getAttribute(String name) {
        return getWrappedElement().getAttribute(name);
    }

    @Override
    public boolean isSelected() {
        return getWrappedElement().isSelected();
    }

    @Override
    public boolean isEnabled() {
        return getWrappedElement().isEnabled();
    }

    @Override
    public String getText() {
        return getWrappedElement().getText();
    }

    @Override
    public boolean equals(Object obj) {
        return obj.getClass() == this.getClass()
                && Objects.equals(this.getWrappedElement(), ((IWrapElement) obj).getWrappedElement());
    }

    @Override
    public int hashCode() {
        return getWrappedElement().hashCode();
    }

    @Override
    public WebDriver getWrappedDriver() {
        return getWrappedElement().getWrappedDriver();
    }

    @Override
    public boolean isDisplayed() {
        return getWrappedElement().isDisplayed();
    }

    @Override
    public Point getLocation() {
        return getWrappedElement().getLocation();
    }

    @Override
    public Dimension getSize() {
        return getWrappedElement().getSize();
    }

    @Override
    public Rectangle getRect() {
        return getWrappedElement().getRect();
    }

    @Override
    public Coordinates getCoordinates() {
        return getWrappedElement().getCoordinates();
    }

    @Override
    public <X> X getScreenshotAs(OutputType<X> outputType) throws WebDriverException {
        return getWrappedElement().getScreenshotAs(outputType);
    }

    @Override
    public String toString() {
        return getWrappedElement().toString();
    }

    @Override
    public Map<String, Object> toJson() {
        return getWrappedElement().toJson();
    }
}
