package ru.rosbank.mobile_plugin.elements.core.text;

/**
 * интерфейс для определения текстовых полей с маской
 * @see ru.rosbank.mobile_plugin.environment.Mask
 */
public interface IEditMaskedText<T> extends IEditText<T>, IHaveMask {

}
