package ru.rosbank.mobile_plugin.elements.core;

import org.openqa.selenium.WebElement;
import ru.rosbank.automation.environment.IWrapElement;
import ru.sbtqa.tag.pagefactory.utils.Wait;

public interface IClickable<T> extends IWrapElement<T> {
    /**
     * метод не будет использоваться при наследовании черезе MobileTypifiedElement, однако при реализации через интерфейс IWrapElement именно эта реализация будет использоваться по умолчанию
     */
    default void click(){
        WebElement element=(WebElement) getWrappedElement();
        Wait.clickable(element,"Элемент не активен");
        element.click();
    }
}
