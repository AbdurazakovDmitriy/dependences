package ru.rosbank.mobile_plugin.elements.core.text;

import org.openqa.selenium.WebElement;
import ru.rosbank.automation.environment.IWrapElement;

public interface IHaveText<T> extends IWrapElement<T> {
    default String getText(){
        return ((WebElement) getWrappedElement()).getText();
    }
}
