package ru.rosbank.mobile_plugin.elements.core.text;

import ru.rosbank.mobile_plugin.environment.Mask;

/**
 * интерфейс, описывающий элементы, использующие маску
 * Важно! этот интерфейс не имеет явных операций с WebElement и не может быть автоматически определен
 * {@link IEditMaskedText}
 */
public interface IHaveMask {
    default Mask getMask(){
        throw new RuntimeException("Mask was not provided");
    }
}
