package ru.rosbank.mobile_plugin.elements.base;

import io.appium.java_client.MobileElement;
import ru.rosbank.mobile_plugin.elements.core.text.IControlText;

public class ControlledMaskedInput extends MaskedInput implements IControlText {
    public ControlledMaskedInput(MobileElement element) {
        super(element);
    }

    /**
     * обычно поля с маской автоматически форматируют данные под эту маску, поэтому этот метод вводит текст
     * в том виде, в котором он пришел как параметр
     * @param text
     */
    @Override
    public void setText(String text){
        getWrappedElement().sendKeys(text);
        assertText(text);
    }
}
