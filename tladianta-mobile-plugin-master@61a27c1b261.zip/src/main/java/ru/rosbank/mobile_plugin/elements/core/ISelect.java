package ru.rosbank.mobile_plugin.elements.core;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import ru.rosbank.mobile_plugin.elements.core.text.IHaveText;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public interface ISelect<T> extends IHaveText<T> {

    /**
     * @return All options belonging to this select tag
     */
    default List<ISelectableItem> getOptions() {
        return ((WebElement) getWrappedElement()).findElements(By.xpath("./*")).stream().map(o -> (ISelectableItem) () -> o).collect(Collectors.toList());
    }

    default String getText() {
        try {
            return getSelectedOption().getText();
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * @return All selected options belonging to this select tag
     */

    default List<ISelectableItem> getAllSelectedOptions() {
        return getOptions().stream().filter(ISelectableItem::isSelected).collect(Collectors.toList());
    }

    /**
     * @return The selected option.
     * @throws NoSuchElementException If no option is selected
     */
    default ISelectableItem getSelectedOption() {
        return getOptions().stream().filter(ISelectableItem::isSelected).findFirst()
                .orElseThrow(() -> new NoSuchElementException("No options are selected"));
    }

    /**
     * Select the option at the given index.
     *
     * @param index The option at this index will be selected
     * @throws NoSuchElementException If no matching option elements are found
     */
    default void selectByIndex(int index) {
        List<ISelectableItem> list = getOptions();
        int size = list.size();
        if (index > size) {
            throw new NoSuchElementException(String.format("Can't select option '%d'. There were only '%d' options", index, size));
        }
        list.get(index).select();
    }

    /**
     * Selects first option with the corresponding text
     *
     * @param value The value to match against
     * @throws NoSuchElementException If no matching option elements are found
     */
    default void selectByValue(String value) {
        getOptions().stream().filter(o -> Objects.equals(o.getText(), value)).findFirst()
                .orElseThrow(() -> new NoSuchElementException(String.format("Can't select option '%s'. No such option was found", value)))
                .select();
    }

    /**
     * Снимает выделение с заданного айтема. Дефолтно реализация не поддерживается, поскольку большинство комбо-боксов не поддерживает такую операцию
     * определение этой операции лежит на имплементаторе
     *
     * @param value The value to match against
     * @throws NoSuchElementException        If no matching option elements are found
     * @throws UnsupportedOperationException If the SELECT does not support multiple selections
     */
    default void deselectByValue(String value) throws NoSuchElementException, UnsupportedOperationException {
        throw new UnsupportedOperationException("This type of select does not support deselecting");
    }

    /**
     * Снимает выделение с айтема по индексу. Дефолтно реализация не поддерживается, поскольку большинство комбо-боксов не поддерживает такую операцию
     * определение этой операции лежит на имплементаторе
     *
     * @param index The option at this index will be deselected
     * @throws NoSuchElementException        If no matching option elements are found
     * @throws UnsupportedOperationException If the SELECT does not support multiple selections
     */
    default void deselectByIndex(int index) {
        throw new UnsupportedOperationException("This type of select does not support deselecting");
    }
}
