package ru.rosbank.mobile_plugin.elements.core.text;

import org.openqa.selenium.WebElement;
import ru.rosbank.mobile_plugin.elements.core.IClickable;

public interface IEditText<T> extends IHaveText<T>, IClickable<T> {
    default void setText(String text) {
        ((WebElement) getWrappedElement()).sendKeys(text);
    }

    default void clear() {
        ((WebElement) getWrappedElement()).clear();
    }
}
