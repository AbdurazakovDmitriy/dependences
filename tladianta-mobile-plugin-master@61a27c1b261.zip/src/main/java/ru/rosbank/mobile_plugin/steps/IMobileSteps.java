package ru.rosbank.mobile_plugin.steps;

import ru.rosbank.automation.transformer.DirectionCondition;
import ru.rosbank.automation.transformer.SearchCondition;
import ru.sbtqa.tag.pagefactory.exceptions.PageException;
import ru.sbtqa.tag.pagefactory.exceptions.SwipeException;

public interface IMobileSteps {

    /**
     * Свайпает до тех пор пока не станет видим ожидаемый текст
     *
     * @param condition направление свайпа
     * @param text ожидаемый текст
     * @throws SwipeException текст не найден или достигнут край контента (свайпать не куда больше)
     */
    IMobileSteps swipeToTextByDirection(DirectionCondition condition, String text) throws SwipeException;

    /**
     * Свайпает до тех пор пока не станет видим ожидаемый текст (для Android)
     *
     * @param condition стратегия сравнения текста
     * @param text ожидаемый текст
     * @throws SwipeException текст не найден
     */
    IMobileSteps swipeToTextByMatch(SearchCondition condition, String text) throws SwipeException;

    /**
     * Имитация нажатия(тап) на центр элемента (для Android)
     *
     * @param elementTitle имя элемента страницы
     */
    IMobileSteps press(String elementTitle) throws PageException;

    /**
     * Имитация нажатия(тап) на центр элемента (для iOS)
     *
     * @param elementTitle имя элемента страницы
     */
    IMobileSteps tap(String elementTitle) throws PageException;
}
