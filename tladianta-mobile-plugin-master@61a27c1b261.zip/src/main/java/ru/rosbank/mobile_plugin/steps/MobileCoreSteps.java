package ru.rosbank.mobile_plugin.steps;

import io.appium.java_client.AppiumDriver;
import io.cucumber.datatable.DataTable;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import ru.rosbank.automation.steps.ActionSteps;
import ru.rosbank.automation.steps.ICoreSteps;
import ru.rosbank.automation.transformer.NegationCondition;
import ru.rosbank.mobile_plugin.elements.core.text.IHaveText;
import ru.rosbank.mobile_plugin.environment.IMobileEnvironment;
import ru.rosbank.mobile_plugin.helper.IExtractElements;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;
import ru.rosbank.mobile_plugin.utils.MobileAlert;
import ru.sbtqa.tag.pagefactory.Page;
import ru.sbtqa.tag.pagefactory.PageManager;
import ru.sbtqa.tag.pagefactory.context.PageContext;
import ru.sbtqa.tag.pagefactory.environment.Environment;
import ru.sbtqa.tag.pagefactory.exceptions.FragmentException;
import ru.sbtqa.tag.pagefactory.exceptions.PageException;
import ru.sbtqa.tag.pagefactory.exceptions.PageInitializationException;
import ru.sbtqa.tag.pagefactory.exceptions.WaitException;
import ru.sbtqa.tag.pagefactory.junit.CoreStepsImpl;
import ru.sbtqa.tag.pagefactory.transformer.ContainCondition;
import ru.sbtqa.tag.pagefactory.utils.DiffUtils;
import ru.sbtqa.tag.pagefactory.utils.Wait;
import ru.sbtqa.tag.qautils.errors.AutotestError;

import static java.lang.String.format;

@Slf4j
public class MobileCoreSteps implements ICoreSteps, ActionSteps, IExtractElements, IMobileEnvironment {
    private final static ThreadLocal<MobileCoreSteps> instanceHolder = ThreadLocal.withInitial(MobileCoreSteps::new);

    public static MobileCoreSteps getInstance() {
        return instanceHolder.get();
    }

    private static final MobileConfiguration PROPERTIES = MobileConfiguration.create();

    /**
     * Выполняет действие в блоке с параметрами.
     *
     * @param block  имя блока или путь до него
     * @param action заголовок действия, которое нужно выполнить
     * @param param  параметры для метода экшена
     * @return текущий объект
     * @throws NoSuchMethodException если метод не найден в указанном блоке
     */
    @Override
    public MobileCoreSteps actionInBlock(String block, String action, Object... param) throws NoSuchMethodException {
        reflection().executeMethodByTitleInBlock(block, action, param);
        return this;
    }

    @Override
    public MobileCoreSteps action(String action, Object... params) throws NoSuchMethodException {
        reflection().executeMethodByTitle(PageContext.getCurrentPage(), action, params);
        return this;
    }

    @Override
    public MobileCoreSteps clearField(String elementTitle) throws WaitException, PageException {
        queryTextEdit(elementTitle).clear();
        return this;
    }

    @Override
    public ICoreSteps openPage(String title, DataTable... dataTable) throws PageInitializationException {
        if (dataTable.length > 0) {
            PageManager.getPage(title, dataTable[0].asList(String.class).toArray());
        } else {
            PageManager.getPage(title);
        }
        return this;
    }

    @Override
    public <E extends Page> E openPage(Class<E> pageClass) throws PageInitializationException {
        return PageManager.getPage(pageClass);
    }

    @Override
    public ICoreSteps fill(String elementTitle, String text) throws PageException {
        Object element = queryElement(elementTitle);
        Environment.getPageActions().fill(element, text);
        return this;
    }

    @Override
    public ICoreSteps click(String elementTitle) throws PageException {
        Object element = queryElement(elementTitle);
        Environment.getPageActions().click(element);
        return this;
    }

    @Override
    public ICoreSteps pressKey(String keyName) {
        AppiumDriver driver = Environment.getDriverService().getDriver();
        driver.getKeyboard().pressKey(keyName);
        return this;
    }

    @Override
    public ICoreSteps pressKey(String keyName, String elementTitle) throws PageException {
        click(elementTitle);
        AppiumDriver driver = Environment.getDriverService().getDriver();
        driver.getKeyboard().pressKey(keyName);
        return this;
    }

    @Override
    public ICoreSteps select(String elementTitle, String option) throws PageException {
        Object element = queryElement(elementTitle);
        Environment.getPageActions().select(element, option);
        return this;
    }

    @Override
    public ICoreSteps setCheckBox(String elementTitle) throws PageException {
        Object element = queryElement(elementTitle);
        Environment.getPageActions().setCheckbox(element, true);
        return this;
    }

    @Override
    public MobileCoreSteps checkValueIsEqual(String elementTitle, String text) throws PageException {
        IHaveText element = queryTextElement(elementTitle);
        if (!Environment.getPageChecks().checkEquality(element, text)) {
            throw new AutotestError("'" + elementTitle + "' value is not equal with '" + text + "'\n" + DiffUtils.diff(text, element.getText()));
        }
        return this;
    }

    @Override
    public MobileCoreSteps checkValueContains(String elementTitle, String text) throws PageException {
        IHaveText element = queryTextElement(elementTitle);
        if (!element.getText().contains(text)) {
            throw new AutotestError("'" + elementTitle + "' value doesn't contain '" + text + "'");
        }
        return this;
    }

    @Override
    public MobileCoreSteps checkValueNotContains(String elementTitle, String text) throws PageException {
        IHaveText element = queryTextElement(elementTitle);
        if (element.getText().contains(text)) {
            throw new AutotestError("'" + elementTitle + "' value unexpectedly contains '" + text + "'");
        }
        return this;
    }

    @Override
    public MobileCoreSteps checkValueIsNotEqual(String elementTitle, String text) throws PageException {
        IHaveText element = queryTextElement(elementTitle);
        if (Environment.getPageChecks().checkEquality(element, text)) {
            throw new AutotestError("'" + elementTitle + "' value is not equal with '" + text + "'\n" + DiffUtils.diff(text, element.getText()));
        }
        return this;
    }

    @Override
    public ICoreSteps checkNotEmpty(String elementTitle) throws PageException {
        IHaveText text = queryTextElement(elementTitle);
        Assert.assertNotEquals(String.format("Текст элемента '%s' неожиданно пустой", elementTitle), text.getText(), "");
        return this;
    }

    @Override
    public ICoreSteps checkEmpty(String elementTitle) throws PageException {
        IHaveText text = queryTextElement(elementTitle);
        Assert.assertEquals(String.format("Текст элемента '%s' неожиданно не пустой", elementTitle), text.getText(), "");
        return this;
    }

    @SneakyThrows
    @Override
    public MobileCoreSteps isElementFocused(String element) {
        Assert.assertEquals("Элемент '" + element + "' не является активным", extractElement(element).getAttribute("focused"), "true");
        return this;
    }

    @Override
    public ICoreSteps userInsertsFragment(String fragmentName) throws FragmentException {
        throw new FragmentException("The fragment-needed step must be replaced, but this did not happened");
    }

    @Override
    public ICoreSteps appearElement(String elementName) throws PageException {
        appearElement(PROPERTIES.getTimeout(), elementName);
        return this;
    }

    @Override
    public MobileCoreSteps appearElement(int timeout, String elementName) throws PageException {
        WebElement element = extractElement(elementName);
        String message = String.format("The element '%s' has not appeared from the page within '%s' seconds.", elementName, timeout);
        Wait.visibility(element, message, timeout);
        return this;
    }

    @Override
    public ICoreSteps waitInvisibility(String elementName) throws PageException {
        waitInvisibility(PROPERTIES.getTimeout(), elementName);
        return this;
    }

    @Override
    public MobileCoreSteps waitInvisibility(int timeout, String elementName) throws PageException {
        WebElement element = extractElement(elementName);
        String message = format("The element '%s' has not disappeared from the page within '%s' seconds.", elementName, timeout);
        Wait.invisibility(element, message, timeout);
        return this;
    }

    @Override
    public ICoreSteps waitChangeAttribute(String attribute, String elementName, String attributeValue) throws PageException {
        waitChangeAttribute(PROPERTIES.getTimeout(), attribute, elementName, attributeValue);
        return this;
    }

    public MobileCoreSteps waitChangeAttribute(int timeout, String attribute, String elementName, String attributeValue) throws PageException {
        WebElement element = extractElement(elementName);
        String message = format("Attribute '%s' of the element '%s' is not equal to '%s' within "
                + "'%s' seconds. The attribute value: %s", attribute, elementName, attributeValue, timeout, element.getAttribute(attribute));
        Wait.changeAttribute(element, attribute, attributeValue, message, timeout);
        return this;
    }

    @Override
    public ICoreSteps waitAttributeContains(String attribute, String elementName, NegationCondition condition, String partAttributeValue) throws PageException {
        waitAttributeContains(PROPERTIES.getTimeout(), attribute, elementName, condition, partAttributeValue);
        return this;
    }

    @Override
    public ICoreSteps waitAttributeContains(int timeout, String attribute, String elementName, NegationCondition condition, String partAttributeValue) throws PageException {
        WebElement element = extractElement(elementName);
        String message = format("After waiting, attribute '%s' of the element '%s' is " + (condition.isPositive() ? "not " : "")
                + "contains value '%s'. Attribute value: %s", attribute, elementName, partAttributeValue, element.getAttribute(attribute));

        if (condition.isPositive()) {
            Wait.attributeContains(element, attribute, partAttributeValue, message, timeout);
        } else {
            Wait.attributeNotContains(element, attribute, partAttributeValue, message, timeout);
        }
        return this;
    }

    @Override
    public ICoreSteps waitElementContainsText(String elementName, NegationCondition condition, String text) throws PageException {
        waitElementContainsText(PROPERTIES.getTimeout(), elementName, condition, text);
        return this;
    }

    @Override
    public ICoreSteps waitElementContainsText(int timeout, String elementName, NegationCondition condition, String text) throws PageException {
        WebElement element = extractElement(elementName);
        String message = format("After waiting, text of the element '%s' is " + (condition.isPositive() ? "not " : "")
                + "contains value '%s'. Text of the element: %s", elementName, text, element.getText());

        if (condition.isPositive()) {
            Wait.textContains(element, text, message, timeout);
        } else {
            Wait.textNotContains(element, text, message, timeout);
        }
        return this;
    }

    @Override
    public ICoreSteps waitClickability(String elementName) throws PageException {
        return waitClickability(PROPERTIES.getTimeout(), elementName);
    }

    public MobileCoreSteps waitAttributeContains(int timeout, String attribute, String elementName, ContainCondition condition, String partAttributeValue) throws PageException {
        WebElement element = extractElement(elementName);
        String message = format("After waiting, attribute '%s' of the element '%s' is " + (condition.isPositive() ? "not " : "")
                + "contains value '%s'. Attribute value: %s", attribute, elementName, partAttributeValue, element.getAttribute(attribute));

        if (condition.isPositive()) {
            Wait.attributeContains(element, attribute, partAttributeValue, message, timeout);
        } else {
            Wait.attributeNotContains(element, attribute, partAttributeValue, message, timeout);
        }
        return this;
    }

    public MobileCoreSteps waitElementContainsText(int timeout, String elementName, ContainCondition condition, String text) throws PageException {
        IHaveText<WebElement> element = queryTextElement(elementName);
        String message = format("After waiting, text of the element '%s' is " + (condition.isPositive() ? "not " : "")
                + "contains value '%s'. Text of the element: %s", elementName, text, element.getText());

        if (condition.isPositive()) {
            Wait.textContains(element.getWrappedElement(), text, message, timeout);
        } else {
            Wait.textNotContains(element.getWrappedElement(), text, message, timeout);
        }
        return this;
    }

    @Override
    public MobileCoreSteps waitClickability(int timeout, String elementName) throws PageException {
        WebElement element = extractElement(elementName);
        String message = String.format("The element '%s' didn't become clickable within %s seconds", elementName, timeout);
        Wait.clickable(element, message, timeout);
        return this;
    }

    @Override
    public ICoreSteps acceptAlert(String text) throws WaitException {
        MobileAlert alert = new MobileAlert();
        if (alert.checkValue(text)) {
            alert.accept();
        } else {
            log.error("Alert with text {} wasn't found", text);
        }
        return this;
    }

    @Override
    public ICoreSteps dismissAlert(String text) throws WaitException {
        MobileAlert alert = new MobileAlert();
        if (alert.checkValue(text)) {
            alert.dismiss();
        } else {
            log.error("Alert with text {} wasn't found", text);
        }
        return this;
    }

    @Override
    public CoreStepsImpl getSource() {
        throw new RuntimeException("This must not happen all methods must be overrided");
    }
}
