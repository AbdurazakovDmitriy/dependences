package ru.rosbank.mobile_plugin.steps;

import ru.rosbank.automation.configuration.ApplicationContext;
import ru.rosbank.automation.configuration.ConfigurationManager;
import ru.rosbank.mobile_plugin.actions.MobilePageActions;
import ru.rosbank.mobile_plugin.checks.MobilePageChecks;
import ru.rosbank.mobile_plugin.driver.MobileDriverService;
import ru.rosbank.mobile_plugin.find.MobileFindUtils;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;
import ru.rosbank.mobile_plugin.reflection.MobileReflection;
import ru.sbtqa.tag.pagefactory.environment.Environment;

import java.util.function.Supplier;

public class MobileSetupSteps {
    private static final ThreadLocal<MobileDriverService> storage = ThreadLocal.withInitial(MobileDriverService::new);

    private MobileSetupSteps() {
    }

    public static MobileDriverService getDriverService(){
        return storage.get();
    }

    /**
     * регистрация классов для обновления, в случае если конфигурация будет перезагружена
     */
    public static void registerClassForReset() {
        Supplier<MobileConfiguration> valueSupplier = MobileConfiguration::create;
        ConfigurationManager.registerClassForReset("ru.rosbank.mobile_plugin.driver.AndroidDriverManager", ConfigurationManager.PROPERTIES, valueSupplier);
        ConfigurationManager.registerClassForReset("ru.rosbank.mobile_plugin.driver.IOSDriverManager", ConfigurationManager.PROPERTIES, valueSupplier);
        ConfigurationManager.registerClassForReset("ru.rosbank.mobile_plugin.driver.MobileDriverService", ConfigurationManager.PROPERTIES, valueSupplier);
        ConfigurationManager.registerClassForReset("ru.rosbank.mobile_plugin.helper.MobileHelper", ConfigurationManager.PROPERTIES, valueSupplier);
        ConfigurationManager.registerClassForReset("ru.rosbank.mobile_plugin.interception.MobileDecorator", ConfigurationManager.PROPERTIES, valueSupplier);
        ConfigurationManager.registerClassForReset("ru.rosbank.mobile_plugin.screen.MobileVideoRecorder", ConfigurationManager.PROPERTIES, valueSupplier);
        ConfigurationManager.registerClassForReset("ru.rosbank.mobile_plugin.screen.MobileVideoUtils", ConfigurationManager.PROPERTIES, valueSupplier);
        ConfigurationManager.registerClassForReset("ru.rosbank.mobile_plugin.stepdefs.MobileSetupStepDefs", ConfigurationManager.PROPERTIES, valueSupplier);
        ConfigurationManager.registerClassForReset("ru.rosbank.mobile_plugin.steps.MobileCommonSteps", ConfigurationManager.PROPERTIES, valueSupplier);
        ConfigurationManager.registerClassForReset("ru.rosbank.mobile_plugin.steps.MobileCoreSteps", ConfigurationManager.PROPERTIES, valueSupplier);
        ConfigurationManager.registerClassForReset("ru.rosbank.mobile_plugin.utils.MobileAlert", ConfigurationManager.PROPERTIES, valueSupplier);
    }

    /**
     * загрузка окружения
     */
    public static void initEnvironment() {
        Environment.setReflection(new MobileReflection());
        Environment.setFindUtils(new MobileFindUtils());
        Environment.setPageActions(new MobilePageActions());
        Environment.setPageChecks(new MobilePageChecks());
    }


    /**
     * загрузка степов для страницы
     * может быть переопределена
     */
    public static void uploadSteps() {
        ApplicationContext.setStepsImpl("MobileSteps", MobileSteps.getInstance());
        ApplicationContext.setStepsImpl("CoreStepsImpl", MobileCoreSteps.getInstance());
        ApplicationContext.setStepsImpl("CommonSteps", MobileCommonSteps.getInstance());
    }
}
