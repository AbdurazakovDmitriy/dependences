package ru.rosbank.mobile_plugin.steps;

import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebElement;
import ru.rosbank.automation.transformer.DirectionCondition;
import ru.rosbank.automation.transformer.SearchCondition;
import ru.rosbank.mobile_plugin.helper.IExtractElements;
import ru.rosbank.mobile_plugin.utils.SwipeUtils;
import ru.sbtqa.tag.pagefactory.context.PageContext;
import ru.sbtqa.tag.pagefactory.environment.Environment;
import ru.sbtqa.tag.pagefactory.exceptions.PageException;
import ru.sbtqa.tag.pagefactory.exceptions.SwipeException;
import ru.sbtqa.tag.pagefactory.transformer.SearchStrategy;
import ru.sbtqa.tag.qautils.strategies.DirectionStrategy;
import ru.sbtqa.tag.qautils.strategies.MatchStrategy;

import java.time.Duration;


public class MobileSteps implements IMobileSteps, IExtractElements {

    private static final ThreadLocal<IMobileSteps> instanceHolder =ThreadLocal.withInitial(MobileSteps::new);

    public static IMobileSteps getInstance() {
        return instanceHolder.get();
    }

    protected MobileSteps swipeToTextByDirection(@NotNull String direction, String text) throws SwipeException {
        SwipeUtils.swipeToText(DirectionStrategy.valueOf(direction.toUpperCase()), text);
        return this;
    }

    protected MobileSteps swipeToTextByMatch(String strategy, String text) throws SwipeException {
        SwipeUtils.swipeToText(MatchStrategy.valueOf(strategy), text);
        return this;
    }

    @Override
    public MobileSteps swipeToTextByDirection(DirectionCondition condition, String text) throws SwipeException {
        return swipeToTextByDirection(condition.getValue().toString(), text);
    }

    @Override
    public MobileSteps swipeToTextByMatch(SearchCondition condition, String text) throws SwipeException {
        String strategy = condition.getValue() == SearchStrategy.CONTAINS ? "CONTAINS" : "EXACT";
        return swipeToTextByMatch(strategy,text);
    }

    @Override
    public MobileSteps press(String elementTitle) throws PageException {
        WebElement element = extractElement(elementTitle);
        Rectangle rect = element.getRect();
        int centerX = rect.getX() + rect.getWidth() / 2;
        int centerY = rect.getY() + rect.getHeight() / 2;
        TouchAction touchAction = new TouchAction(Environment.getDriverService().getDriver());
        touchAction.tap(PointOption.point(centerX, centerY)).perform();
        return this;
    }

    @Override
    public MobileSteps tap(String elementTitle) throws PageException {
        new TouchAction(Environment.getDriverService().getDriver())
                .longPress(LongPressOptions.longPressOptions()
                        .withDuration(Duration.ofMillis(100L))
                        .withElement(ElementOption.element(Environment.getFindUtils().getElementByTitle(PageContext.getCurrentPage(), elementTitle))))
                .release()
                .perform();
        return this;
    }
}
