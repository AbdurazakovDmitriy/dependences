package ru.rosbank.mobile_plugin.steps;

import io.appium.java_client.MobileDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import io.cucumber.datatable.DataTable;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import ru.rosbank.automation.configuration.ApplicationContext;
import ru.rosbank.automation.steps.CommonSteps;
import ru.rosbank.automation.transformer.NegationCondition;
import ru.rosbank.mobile_plugin.elements.core.text.IHaveText;
import ru.rosbank.mobile_plugin.environment.IMobileEnvironment;
import ru.rosbank.mobile_plugin.helper.IExtractElements;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;
import ru.rosbank.mobile_plugin.utils.MobileAlert;
import ru.rosbank.mobile_plugin.utils.MobileWait;
import ru.sbtqa.tag.datajack.Stash;
import ru.sbtqa.tag.pagefactory.environment.Environment;
import ru.sbtqa.tag.pagefactory.exceptions.PageException;
import ru.sbtqa.tag.pagefactory.utils.Wait;

import java.time.Duration;
import java.util.List;
import java.util.Map;

@Slf4j
public class MobileCommonSteps extends CommonSteps implements IMobileEnvironment, IExtractElements {

    private static final MobileConfiguration PROPERTIES = MobileConfiguration.create();

    private static final ThreadLocal<MobileCommonSteps> instanceHolder = ThreadLocal.withInitial(MobileCommonSteps::new);

    public static MobileCommonSteps getInstance() {
        return instanceHolder.get();
    }

    protected MobileCoreSteps coreSteps() {
        return (MobileCoreSteps) ApplicationContext.getStepsImpl("CoreStepsImpl");
    }

    /**
     * Сохраняет текст из алерта в онтекст сценария (Stash)
     *
     * @param variable наименование переменной в Stash
     * @return текущий объект
     */
    public MobileCommonSteps putAlertTextToStash(String variable) {
        String alertText = new MobileAlert(PROPERTIES.getTimeout()).getText();
        Stash.put(variable, alertText);
        log.info("В переменную \"{}\" сохранено значение \"{}\"", variable, alertText);

        return this;
    }

    /**
     * Заполняет поле значением переменной из Stash
     *
     * @param elementName имя элемента
     * @param variable    наименование переменной в Stash
     * @return текущий объект
     */
    public MobileCommonSteps sendTextFromStashToField(String elementName, String variable) throws PageException {
        String text = Stash.getValue(variable);
        coreSteps().fill(elementName, text);

        return this;
    }

    /**
     * Заполняет поля данными из таблицы
     *
     * @param dataTable параметр-таблица вида:
     *                  <pre>|Имя элемента|новое значение элемента|</pre>
     *                  <pre>|Имя элемента|новое значение элемента|</pre>
     *                  в качестве параметра может выступать значение переменной, сохраненной в Stash
     * @return текущий объект
     */
    @Override
    public MobileCommonSteps fillFields(DataTable dataTable) throws PageException {
        for (List<Object> row : dataTable.asLists(String.class)) {
            coreSteps().fill(String.valueOf(row.get(0)), String.valueOf(row.get(1)));
        }
        return this;
    }

    /**
     * Проверяет доступность/недоступность элемента
     *
     * @param elementName имя элемента - чекбокса
     *                    <p>Поддерживает путь к элементу ({@code ->})</p>
     * @param negation    POSITIVE - доступен, NEGATIVE - не доступен
     * @return текущий объект
     */
    @Override
    public MobileCommonSteps checkElementAvailability(String elementName, NegationCondition negation) throws PageException {
        WebElement element = extractElement(elementName);
        boolean result = MobileWait.silentWaitElementIsClickable(element);

        if (negation.isPositive()) {
            Assert.assertFalse("Элемент доступен", result);
        } else {
            Assert.assertTrue("Элемент не доступен", result);
        }

        return this;
    }

    /**
     * Проверяет видимость/невидимость элемента
     *
     * @param elementName имя элемента - чекбокса
     *                    <p>Поддерживает путь к элементу ({@code ->})</p>
     * @param negation    POSITIVE - виден, NEGATIVE - не виден
     * @return текущий объект
     * @throws PageException ошибка чтения свойства элемента
     */
    @Override
    public MobileCommonSteps checkElementVisibility(String elementName, NegationCondition negation) throws PageException {
        WebElement element = extractElement(elementName);
        boolean result = MobileWait.silentWaitVisibility(element);

        if ((negation.isPositive())) {
            Assert.assertFalse("Элемент доступен", result);
        } else {
            Assert.assertTrue("Элемент не доступен", result);
        }

        return this;
    }

    /**
     * Очищает все поля по именам из списка
     *
     * @param elementTitles список имен элементов
     *                      <p>Поддерживает путь к элементу ({@code ->})</p>
     * @return текущий объект
     */
    @SneakyThrows
    @Override
    public MobileCommonSteps clearFields(List<String> elementTitles) {
        for (String elementTitle : elementTitles) {
            queryTextEdit(elementTitle).clear();
        }
        return this;
    }

    /**
     * Сохраняет значение элемента в контекст Stash под именем
     *
     * @param elementName  имя элемента
     *                     <p>Поддерживает путь к элементу ({@code ->})</p>
     * @param variableName мя переменной
     * @return текущий объект
     * @throws PageException ошибка чтения значения поля
     */
    @Override
    public MobileCommonSteps saveElementValueInStash(String elementName, String variableName) throws PageException {
        String elementValue = queryTextElement(elementName).getText();
        Stash.put(variableName, elementValue);
        log.info("В переменную \"{}\" сохранено значение \"{}\"", variableName, elementValue);
        return this;
    }

    /**
     * Проверяет, что элементы с текстом существуют
     *
     * @param dataTable |наименование элемента|искомый текст|
     * @return текущий объект
     */
    @SneakyThrows
    public MobileCommonSteps checkElementsWithTexts(DataTable dataTable) {
        Map<String, String> table = dataTable.asMap(String.class, String.class);
        for (Map.Entry<String, String> entry : table.entrySet()) {
            IHaveText textElement = queryTextEdit(entry.getKey());
            if (textElement instanceof WebElement) {
                Wait.visibility((WebElement) textElement, String.format("Элемент '%s' не отображается", entry.getKey()));
            }
            boolean result = pageChecks().checkEquality(textElement, entry.getValue());
            Assert.assertTrue(String.format("Element '%s' with text '%s' not found", entry.getKey(), entry.getValue()), result);
        }
        return this;
    }

    /**
     * Проверяет, что элемент с текстом существует
     *
     * @param elementName  - имя элемента на странице
     * @param expectedText - ожидаемый текст
     * @return текущий объект
     */
    @SneakyThrows
    public MobileCommonSteps elementWithTextExists(String elementName, String expectedText) {
        IHaveText textElement = queryTextElement(elementName);
        boolean result = pageChecks().checkEqualityIgnoreCase(textElement, expectedText);
        Assert.assertTrue(String.format("Element %s with text '%s' not found", elementName, expectedText), result);
        return this;
    }

    /**
     * Вертикальный swipe
     *
     * @param startHeightPercentage процент от высоты экрана - начальная координата Y
     * @param endHeightPercentage   процент от высоты экрана - конечная координата Y
     * @param widthPercentage       процент от ширины экрана = координата X
     * @return текущий объект
     */
    //TODO - проверить как работает
    public MobileCommonSteps verticalSwipeByPercentages(double startHeightPercentage, double endHeightPercentage, double widthPercentage) {
        MobileDriver driver = Environment.getDriverService().getDriver();
        Dimension windowSize = driver.manage().window().getSize();
        int x = (int) (windowSize.width * widthPercentage);
        int startY = (int) (windowSize.height * startHeightPercentage);
        int endY = (int) (windowSize.height * endHeightPercentage);

        new TouchAction(driver)
                .press(PointOption.point(x, startY))
                .waitAction(WaitOptions.waitOptions(Duration.ofMillis(800)))
                .moveTo(PointOption.point(x, endY))
                .release().perform();
        return this;
    }

    /**
     * swipe от элемента к элементу
     *
     * @param startElementName имя стартового элемента
     * @param endElementName   имя конечного элемента
     * @return текущий объект
     */
    //TODO - проверить как работает
    public MobileCommonSteps scrollToElement(String startElementName, String endElementName) {
        WebElement startElement = findUtils().find(startElementName);
        WebElement endElement = findUtils().find(endElementName);

        MobileDriver driver = Environment.getDriverService().getDriver();
        int startX = startElement.getLocation().getX() + (startElement.getSize().getWidth() / 2);
        int startY = startElement.getLocation().getY() + (startElement.getSize().getHeight() / 2);

        int endX = endElement.getLocation().getX() + (endElement.getSize().getWidth() / 2);
        int endY = endElement.getLocation().getY() + (endElement.getSize().getHeight() / 2);

        new TouchAction(driver)
                .press(PointOption.point(startX, startY))
                .waitAction(WaitOptions.waitOptions(Duration.ofMillis(800)))
                .moveTo(PointOption.point(endX, endY))
                .release().perform();

        return this;
    }

    @Override
    public MobileCommonSteps checkElementsVisibility(NegationCondition negationCondition, List<String> elementNames) throws PageException {
        for (String elementName : elementNames) {
            WebElement element = extractElement(elementName);
            boolean result = element.isDisplayed();
            if (negationCondition.isPositive()) {
                Assert.assertFalse(String.format("Element %s found", elementName), result);
            } else {
                Assert.assertTrue(String.format("Element %s not found", elementName), result);
            }
        }
        return this;
    }

    @Override
    public CommonSteps checkElementsAvailability(NegationCondition condition, List<String> elementNames) throws PageException {
        for (String elementName : elementNames) {
            WebElement element = extractElement(elementName);
            boolean result = element.isEnabled();
            if (condition.isPositive()) {
                Assert.assertTrue(String.format("Element %s not enabled", elementName), result);
            } else {
                Assert.assertFalse(String.format("Element %s enabled", elementName), result);
            }
        }
        return this;
    }
}
