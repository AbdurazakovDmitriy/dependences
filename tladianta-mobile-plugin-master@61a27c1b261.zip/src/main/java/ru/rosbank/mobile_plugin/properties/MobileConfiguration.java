package ru.rosbank.mobile_plugin.properties;

import ru.rosbank.automation.configuration.CommonConfiguration;
import ru.rosbank.mobile_plugin.environment.PlatformName;
import ru.sbtqa.tag.pagefactory.properties.Configuration;

public interface MobileConfiguration extends CommonConfiguration {

    /**
     * @return разделитель для тестовых данных
     */
    @Key("data.arrayDelimiter")
    @DefaultValue("::")
    String getDataArrayDelimiter();

    /**
     * @return наименование виртуального устройства AVD
     */
    @Key("appium.avd")
    @DefaultValue("")
    String getAVD();

    /**
     * @return таймаут запуска виртуального устройства (millisec)
     */
    @Key("appium.avdLaunchTimeout")
    @DefaultValue("900000")
    Long getAVDLaunchTimeout();

    /**
     * @return ожидание готовности виртуального устройства (millisec)
     */
    @Key("appium.avdReadyTimeout")
    @DefaultValue("900000")
    Long getAVDReadyTimeout();

    /**
     * @return процессы windows, которые нужно завершить перед стартом тестового сценария
     */
    @Key("appium.task.to.kill")
    @DefaultValue("")
    String getTaskToKill();

    /**
     * @return Тайм-аут в секундах, используемый для ожидания готовности устройства после загрузки
     */
    @Key("appium.androidDeviceReadyTimeout")
    @DefaultValue("90")
    Long getAndroidDeviceReadyTimeout();

    /**
     * @return Используется для автоматической настройки работы Appium XCUITest
     * с реальными устройствами IOS.
     */
    @Key("appium.xcodeOrgId")
    @DefaultValue("")
    String getAppiumXcodeOrgId();

    /**
     * @return Используется для ожидания загрузки приложения
     */
    @Key("appium.appWaitActivity")
    @DefaultValue("")
    String getAppWaitActivity();

    /**
     * @return Используется для загрузки параметров одним файлом, произвольными ключами
     */
    @Key("appium.custom.capabilities")
    @DefaultValue("")
    String getCustomCapabilities();

    /**
     * @return В паре с xcodeOrgId параметр используется для автоматической настройки
     * работы Appium XCUITest с реальными устройствами IOS.
     */
    @Key("appium.xcodeSigningId")
    @DefaultValue("")
    String getAppiumXcodeSigningId();

    /**
     * @return В паре с xcodeOrgId параметр используется для автоматической настройки
     * работы Appium XCUITest с реальными устройствами IOS.
     */
    @Key("platform.based.elements")
    @DefaultValue("true")
    Boolean getPlatformBasedElements();

    /**
     * @return В паре с xcodeOrgId параметр используется для автоматической настройки
     * работы Appium XCUITest с реальными устройствами IOS.
     */
    @Key("appium.device.platform.name")
    PlatformName getAppiumPlatformName();

    @Key("appium.url")
    @DefaultValue("")
    String getAppiumUrl();

    @Key("appium.version")
    @DefaultValue("")
    String getAppiumVersion();

    @Key("appium.app")
    @DefaultValue("")
    String getAppiumApp();

    @Key("appium.app.package")
    @DefaultValue("")
    String getAppiumAppPackage();

    @Key("appium.app.activity")
    @DefaultValue("")
    String getAppiumAppActivity();

    @Key("appium.device.orientation")
    @DefaultValue("portrait")
    String getAppiumDeviceOrientation();

    @Key("appium.device.name")
    @DefaultValue("")
    String getAppiumDeviceName();

    @Key("appium.device.platform.version")
    @DefaultValue("")
    String getAppiumPlatformVersion();

    @Key("appium.browser.name")
    @DefaultValue("")
    String getAppiumBrowserName();

    @Key("appium.fullReset")
    @DefaultValue("")
    String getAppiumFullReset();

    @Key("appium.noReset")
    @DefaultValue("")
    String getAppiumNoReset();

    @Key("appium.permissions")
    String getAppiumPermissions();

    @Key("appium.automation.name")
    @DefaultValue("")
    String getAppiumAutomationName();

    @Key("appium.permissions.autogrant")
    @DefaultValue("")
    String getAppiumAutoGrantPermissions();

    @Key("appium.keyboard.unicode")
    @DefaultValue("")
    String getAppiumKeyboardUnicode();

    @Key("appium.keyboard.reset")
    @DefaultValue("")
    String getAppiumKeyboardReset();

    @Key("appium.udid")
    @DefaultValue("")
    String getAppiumUdid();

    @Key("appium.bundleid")
    @DefaultValue("")
    String getAppiumBundleId();

    @Key("appium.alerts.autoaccept")
    @DefaultValue("")
    String getAppiumAlertsAutoAccept();

    @Key("appium.timeout")
    @DefaultValue("60")
    String getNewCommandTimeout();

    @Key("appium.video.enabled")
    @DefaultValue("false")
    boolean getAppiumVideoEnabled();

    @Key("appium.video.folder")
    @DefaultValue("target")
    String getAppiumVideoFolder();

    @Key("appium.video.name")
    @DefaultValue("mobiletest")
    String getAppiumVideoName();

    @Key("appium.video.extension")
    @DefaultValue("mp4")
    String getAppiumVideoExtension();

    @Key("appium.video.type")
    @DefaultValue("h264")
    String getAppiumVideoType();

    @Key("appium.video.scale")
    @DefaultValue("1920:1080")
    String getAppiumVideoScale();

    @Key("appium.video.timeLimit")
    @DefaultValue("180")
    long getAppiumTimeLimit();

    @Key("appium.video.quality")
    @DefaultValue("MEDIUM")
    String getAppiumVideoQuality();



    static MobileConfiguration create() {
        return Configuration.init(MobileConfiguration.class);
    }


}
