package ru.rosbank.mobile_plugin.helper;

import org.openqa.selenium.WebElement;
import ru.rosbank.automation.environment.IWrapElement;
import ru.rosbank.mobile_plugin.elements.core.IClickable;
import ru.rosbank.mobile_plugin.elements.core.text.IEditText;
import ru.rosbank.mobile_plugin.elements.core.text.IHaveText;
import ru.sbtqa.tag.pagefactory.Page;
import ru.sbtqa.tag.pagefactory.context.PageContext;
import ru.sbtqa.tag.pagefactory.environment.Environment;
import ru.sbtqa.tag.pagefactory.exceptions.PageException;

public interface IExtractElements {
    default Object queryElement(String elementTitle) throws PageException {
        Page currentPage = PageContext.getCurrentPage();
        if (currentPage == null) {
            throw new PageException("Current page is undefined. Please execute \"open page\" step first");
        }
        return Environment.getFindUtils().getElementByTitle(PageContext.getCurrentPage(), elementTitle);
    }

    default IHaveText queryTextElement(String title) throws PageException {
        Object o= queryElement(title);
        if (o instanceof IHaveText){
            return (IHaveText) o;
        } else if (o instanceof WebElement){
            return ()->o;
        }
        throw new PageException(String.format("Элемент '%s' не может быть интерпретирован как текст", title));
    }

    default IEditText queryTextEdit(String title) throws PageException {
        Object o= queryElement(title);
        if (o instanceof IEditText){
            return (IEditText) o;
        } else if (o instanceof WebElement){
            return ()->o;
        }
        throw new PageException(String.format("Элемент '%s' не может быть интерпретирован как текст", title));
    }

    default IClickable queryClickable(String title) throws PageException {
        Object o= queryElement(title);
        if (o instanceof IClickable){
            return (IClickable) o;
        } else if (o instanceof WebElement){
            return ()->o;
        }
        throw new PageException(String.format("Элемент '%s' не может быть интерпретирован как кликабельный элемент", title));
    }

    default WebElement extractElement(String title) throws PageException {
        Object o= queryElement(title);
        while(o instanceof IWrapElement){
            o=((IWrapElement) o).getWrappedElement();
        }
        if (o instanceof WebElement){
            return (WebElement) o;
        }
        throw new PageException(String.format("Не удалось извлечь элемент '%s'", title));
    }
}
