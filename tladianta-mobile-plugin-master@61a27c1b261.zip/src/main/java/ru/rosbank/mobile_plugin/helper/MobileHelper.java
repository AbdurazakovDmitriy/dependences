package ru.rosbank.mobile_plugin.helper;

import io.appium.java_client.android.AndroidDriver;
import lombok.extern.slf4j.Slf4j;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;
import ru.sbtqa.tag.pagefactory.environment.Environment;

import java.io.IOException;

@Slf4j
public class MobileHelper {

    private static final MobileConfiguration PROPERTIES = MobileConfiguration.create();

    /**
     * убивает процесс эмулятора
     */
    public void killEmulator() {
        String cmd = String.format("taskkill /IM %s", PROPERTIES.getTasksToKill());
        try {
            Runtime.getRuntime().exec(cmd);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * проверка, что приложение запущено и currentActivity совпадает с ожидаемой
     * только для Андроид-приложения
     */
    public boolean isAppLaunched() {
        String currentActivity = ((AndroidDriver) Environment.getDriverService().getDriver()).currentActivity();
        log.info(String.format("currentActivity = %s", currentActivity));
        log.info("Проверяю, что приложение запущено");
        return currentActivity.equals(PROPERTIES.getAppiumAppActivity());
    }

}
