package ru.rosbank.mobile_plugin.reflection;

import org.apache.commons.lang3.reflect.MethodUtils;
import ru.rosbank.automation.environment.IReflection;
import ru.rosbank.automation.exceptions.ElementSearchError;
import ru.rosbank.mobile_plugin.elements.AbstractMobileBlock;
import ru.rosbank.mobile_plugin.find.MobileFindUtils;
import ru.sbtqa.tag.pagefactory.environment.Environment;
import ru.sbtqa.tag.pagefactory.reflection.DefaultReflection;
import java.lang.reflect.Method;
import java.util.Arrays;

public class MobileReflection implements IReflection {

    private static final DefaultReflection source = new DefaultReflection();

    @Override
    public final DefaultReflection getSource() {
        return source;
    }

    @Override
    public void executeMethodByTitleInBlock(String blockPath, String actionTitle, Object... parameters) {
        try {
            AbstractMobileBlock block = (AbstractMobileBlock) ((MobileFindUtils) Environment.getFindUtils()).find(blockPath, AbstractMobileBlock.class);
            executeMethodByTitle(block, actionTitle, parameters);
        } catch (ElementSearchError | NoSuchMethodException ex) {
            throw new ElementSearchError(String.format("Block not found by path '%s'", blockPath), ex);
        } catch (ClassCastException e){
            throw new ElementSearchError(String.format("Элемент '%s' не является блоком", blockPath));
        }
    }

    //temp
    public Object newInstance(Class clazz, Class[] classes, Object[] args){
        try {
            return clazz.getDeclaredConstructor(classes).newInstance(args);
        } catch (Exception e){
            throw new RuntimeException(e);
        }
    }
}
