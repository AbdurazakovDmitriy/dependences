package ru.rosbank.mobile_plugin.screen;

import io.appium.java_client.android.AndroidStartScreenRecordingOptions;
import io.appium.java_client.ios.IOSStartScreenRecordingOptions;
import io.appium.java_client.screenrecording.BaseStartScreenRecordingOptions;
import io.appium.java_client.screenrecording.CanRecordScreen;
import lombok.extern.slf4j.Slf4j;
import ru.rosbank.mobile_plugin.driver.IOSDriverManager;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;
import ru.sbtqa.tag.pagefactory.environment.Environment;
import ru.sbtqa.tag.pagefactory.utils.PathUtils;

import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

import static java.lang.String.format;

@Slf4j
public class MobileVideoRecorder {
    private static final MobileConfiguration PROPERTIES = MobileConfiguration.create();
    private static final String VIDEO_FILENAME_TEMPLATE = PROPERTIES.getAppiumVideoName() + "%s." + PROPERTIES.getAppiumVideoExtension();

    protected String videoFileName;
    protected boolean isRecording = false;

    public MobileVideoRecorder() {
        videoFileName = format(VIDEO_FILENAME_TEMPLATE, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")));
    }

    public void startRecord() {
        if (Environment.isDriverEmpty()) {
            log.error("Can't start video recording because driver is null");
            return;
        }

        BaseStartScreenRecordingOptions startOptions;
        CanRecordScreen driver = Environment.getDriverService().getDriver();

        if(driver instanceof IOSDriverManager) {
            startOptions = new IOSStartScreenRecordingOptions()
                    .withVideoType(PROPERTIES.getAppiumVideoType())
                    .withVideoScale(PROPERTIES.getAppiumVideoScale())
                    .withVideoQuality(IOSStartScreenRecordingOptions.VideoQuality.HIGH);
        }
        else {
            startOptions = new AndroidStartScreenRecordingOptions();
        }

        driver.startRecordingScreen(startOptions);
        isRecording = true;
    }

    public byte[] stopRecord() {
        if (Environment.isDriverEmpty()) {
            log.error("Can't stop and save video because driver is null");
            return null;
        }

        // get Base64 encoded video content
        String encodedString = ((CanRecordScreen) Environment.getDriverService().getDriver()).stopRecordingScreen();

        // convert to byte array
        byte[] decodedBytes = Base64.getDecoder().decode(encodedString.getBytes());

        // save to file
        String path = PathUtils.unite(PROPERTIES.getAppiumVideoFolder(), videoFileName);
        path = PathUtils.unite(System.getProperty("user.dir"), path);
        try (FileOutputStream out = new FileOutputStream(path)) {
            out.write(decodedBytes);
            log.info("Video saved to {} successfully", path);
        } catch (IOException e) {
            log.error("An error occurred while saving the video to file", e);
        }

        isRecording = false;
        return decodedBytes;
    }

    public String getVideoFileName() {
        return videoFileName;
    }

    public boolean isRecording() {
        return isRecording;
    }
}
