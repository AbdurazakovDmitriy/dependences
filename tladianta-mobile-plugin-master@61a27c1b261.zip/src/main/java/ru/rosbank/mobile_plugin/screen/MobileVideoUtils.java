package ru.rosbank.mobile_plugin.screen;

import ru.rosbank.automation.utils.screen.VideoUtils;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;

public class MobileVideoUtils extends VideoUtils {
    private static final MobileConfiguration PROPERTIES = MobileConfiguration.create();
    private MobileVideoRecorder mobileVideoRecorder;
    private static final String name = "Mobile";

    public static void create() {
        instances.putIfAbsent(name, new MobileVideoUtils());
    }

    @Override
    protected void start() {
        if (PROPERTIES.getAppiumVideoEnabled()) {
            mobileVideoRecorder = new MobileVideoRecorder();
            mobileVideoRecorder.startRecord();
        }

    }

    @Override
    protected void stop() {
        if(PROPERTIES.getAppiumVideoEnabled() && mobileVideoRecorder.isRecording()) {
            bytes = mobileVideoRecorder.stopRecord();
        }
    }
}
