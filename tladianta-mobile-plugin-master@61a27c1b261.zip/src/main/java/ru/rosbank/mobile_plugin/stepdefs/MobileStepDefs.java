package ru.rosbank.mobile_plugin.stepdefs;

import cucumber.api.java.ru.И;
import cucumber.api.java.ru.Когда;
import ru.rosbank.automation.configuration.ApplicationContext;
import ru.rosbank.automation.transformer.DirectionCondition;
import ru.rosbank.automation.transformer.SearchCondition;
import ru.rosbank.mobile_plugin.steps.IMobileSteps;
import ru.sbtqa.tag.pagefactory.exceptions.PageException;
import ru.sbtqa.tag.pagefactory.exceptions.SwipeException;

public class MobileStepDefs {

    private IMobileSteps steps() {
        return (IMobileSteps) ApplicationContext.getStepsImpl("MobileSteps");
    }

    @Когда("^(?:пользователь |он )?свайпает (вниз|вверх|влево|вправо) до текста \"([^\"]*)\"$")
    @И("^(?:я )?свайпаю (вниз|вверх|влево|вправо) до текста \"([^\"]*)\"$")
    public void swipeToTextByDirection(DirectionCondition condition, String text) throws SwipeException {
        steps().swipeToTextByDirection(condition, text);
    }

    @Когда("^(?:пользователь |он )?свайпает (по частичному совпадению с | )?(?:текстом|до текста) \"([^\"]*)\"$")
    @И("^(?:я )?свайпаю (по частичному совпадению с | )?(?:текстом|до текста) \"([^\"]*)\"$")
    public void swipeToTextByMatch(SearchCondition condition, String text) throws SwipeException {
        steps().swipeToTextByMatch(condition, text);
    }

    @Когда("^(?:пользователь |он )?нажимает на \"([^\"]*)\"$")
    @И("^(?:я )?нажимаю на \"([^\"]*)\"$")
    public void pressOn(String elementTitle) throws PageException {
        steps().press(elementTitle);
    }

    @Когда("^(?:пользователь |он )?тапает по \"([^\"]*)\"$")
    @И("^(?:я )?тапаю по \"([^\"]*)\"$")
    public void tapOn(String elementTitle) throws PageException {
        steps().tap(elementTitle);
    }

}
