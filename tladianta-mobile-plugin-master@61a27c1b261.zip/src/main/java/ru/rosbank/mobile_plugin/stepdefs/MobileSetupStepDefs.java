package ru.rosbank.mobile_plugin.stepdefs;

import cucumber.api.java.Before;
import ru.rosbank.automation.configuration.ApplicationManager;
import ru.rosbank.mobile_plugin.driver.MobileDriverService;
import ru.rosbank.mobile_plugin.environment.PlatformName;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;
import ru.rosbank.mobile_plugin.screen.MobileVideoUtils;
import ru.rosbank.mobile_plugin.steps.MobileSetupSteps;
import ru.sbtqa.tag.datajack.Stash;
import ru.sbtqa.tag.pagefactory.PageManager;
import ru.sbtqa.tag.pagefactory.environment.Environment;

import java.io.IOException;

import static ru.rosbank.automation.utils.SshUtils.executeCommand;

public class MobileSetupStepDefs {
    private static final MobileConfiguration PROPERTIES = MobileConfiguration.create();

    /**
     * Инициализация мобильного контекста
     */
    @Before(order = 2)
    public static void initMobile() {
        MobileSetupSteps.registerClassForReset();
        ApplicationManager.addResetAction("mobile", PageManager::cachePages);
        ApplicationManager.addResetAction("mobile", MobileSetupSteps::initEnvironment);
        ApplicationManager.addResetAction("mobile", MobileSetupSteps::uploadSteps);
        ApplicationManager.addResetAction("mobile", () -> {
            if (Environment.isDriverEmpty() || !(Environment.getDriverService() instanceof MobileDriverService)) {
                Environment.setDriverService(MobileSetupSteps.getDriverService());
            }
        });
    }

    @Before(order = 11000)
    public void preSetUp() {
        final String hostName = "appium";
        final String firstStartFlag = "FIRST_START_FLAG";

        try {
            if(!Stash.asMap().containsKey(firstStartFlag)) {
                if(PROPERTIES.getAppiumPlatformName().equals(PlatformName.IOS)) {
                    executeCommand(hostName, "defaults write com.apple.iphonesimulator ConnectHardwareKeyboard -bool no");
                }
                Stash.put(firstStartFlag, firstStartFlag);
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Before
    public void setUpVideoRecorder() {
        MobileVideoUtils.create();
    }
}
