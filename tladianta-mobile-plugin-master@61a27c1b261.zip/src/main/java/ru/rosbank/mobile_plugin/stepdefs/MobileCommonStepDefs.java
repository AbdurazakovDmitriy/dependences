package ru.rosbank.mobile_plugin.stepdefs;

import cucumber.api.java.ru.И;
import cucumber.api.java.ru.Когда;
import io.cucumber.datatable.DataTable;
import ru.rosbank.automation.configuration.ApplicationContext;
import ru.rosbank.mobile_plugin.steps.MobileCommonSteps;
import ru.sbtqa.tag.pagefactory.exceptions.PageException;

public class MobileCommonStepDefs {

    private MobileCommonSteps commonSteps(){
        return (MobileCommonSteps) ApplicationContext.getStepsImpl("CommonSteps");
    }

    @Когда("^(?:пользователь |он )?запоминает текст из алерта в переменную \"([^\"]*)\"$")
    @И("^(?:я )?запоминаю текст из алерта в переменную \"([^\"]*)\"$")
    public void putAlertTextToStash(String name){
        commonSteps().putAlertTextToStash(name);
    }

    @Когда("^(?:пользователь |он )?заполняет поле \"([^\"]*)\" значением переменной \"([^\"]*)\"$")
    @И("^(?:я )?заполняю поле \"([^\"]*)\" значением переменной \"([^\"]*)\"$")
    public void sendTextFromStashToField(String fieldName, String value) throws PageException {
        commonSteps().sendTextFromStashToField(fieldName, value);
    }

    @Когда("^(?:пользователь |он )?ожидает элементы, содержащие(?: текст):?$")
    @И("^(?:я )?ожидаю элементы, содержащие(?: текст):?$")
    public void checkElementsWithText(DataTable dataTable) {
        commonSteps().checkElementsWithTexts(dataTable);
    }

    @Когда("^(?:пользователь |он )?проверяет, что элемент \"([^\"]*)\" с текстом \"([^\"]*)\" существует$")
    @И("^(?:я )?проверяю, что элемент \"([^\"]*)\" с текстом \"([^\"]*)\" существует$")
    public void elementWithTextExists(String elementName, String expectedText){
        commonSteps().elementWithTextExists(elementName, expectedText);
    }

    @Когда("^(?:пользователь |он )?скроллирует от элемента \"([^\"]*)\" к элементу \"([^\"]*)\"$")
    @И("^(?:я )?скроллирую от элемента \"([^\"]*)\" к элементу \"([^\"]*)\"$")
    public void scrollToElement(String elementName1, String elementName2){
        commonSteps().scrollToElement(elementName1, elementName2);
    }
}
