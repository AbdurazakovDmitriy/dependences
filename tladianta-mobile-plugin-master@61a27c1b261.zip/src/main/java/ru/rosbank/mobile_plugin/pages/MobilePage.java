package ru.rosbank.mobile_plugin.pages;

import io.appium.java_client.MobileDriver;
import ru.rosbank.mobile_plugin.elements.TypeResolver;
import ru.rosbank.automation.environment.Page;
import ru.rosbank.mobile_plugin.interception.MobileDecorator;
import ru.rosbank.mobile_plugin.environment.IMobileEnvironment;
import ru.sbtqa.tag.pagefactory.environment.Environment;

/**
 * Общий предок для всех страниц
 */
public abstract class MobilePage extends Page implements IMobileEnvironment {
    /**
     * конструктор мобильной страницы
     */
    protected MobilePage() {

    }

    protected void initContext() {

        //MobileSetupSteps.initMobile();
    }

    /**
     * инициадизация контекста страниц и проксирование страницы
     */
    protected void initPage() {
        initLocalImplementations();
        proxyPage();
    }

    protected final void initSteps() {

    }

    protected final void initEnvironment() {

    }

    /**
     * переопредели этот метод, чтобы определить имплементации для интерфейсов и абстрактных классов
     * например {@code MobileBaseElement.register(MobileButton.class,IButton.class)}
     * подробнее {@link TypeResolver#registerType(Class, Class)}
     */
    protected void initLocalImplementations() {
    }

    /**
     * оборачивание страниц пейджи в прокси
     * для использования иного декоратора этот метод можно переопределить
     */
    protected void proxyPage() {
        MobileDriver driver = Environment.getDriverService().getDriver();
        new MobileDecorator(driver).decorate(this);
    }

}
