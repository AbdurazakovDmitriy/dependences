package ru.rosbank.mobile_plugin.find;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import ru.rosbank.automation.environment.IContext;
import ru.rosbank.automation.environment.IWrapElement;
import ru.rosbank.automation.exceptions.ElementSearchError;
import ru.rosbank.automation.exceptions.IncorrectElementTypeError;
import ru.rosbank.mobile_plugin.elements.MobileTypifiedElement;
import ru.sbtqa.tag.pagefactory.Page;
import ru.sbtqa.tag.pagefactory.annotations.ElementTitle;
import ru.sbtqa.tag.pagefactory.context.PageContext;
import ru.sbtqa.tag.pagefactory.environment.Environment;
import ru.sbtqa.tag.pagefactory.exceptions.ElementDescriptionException;
import ru.sbtqa.tag.pagefactory.find.FindUtils;
import ru.sbtqa.tag.pagefactory.utils.Wait;
import ru.sbtqa.tag.qautils.errors.AutotestError;
import ru.sbtqa.tag.qautils.reflect.FieldUtilsExt;

import java.lang.reflect.Field;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

class RemoteFindUtils extends FindUtils {

    public RemoteFindUtils() {
    }

    public <T> T getElementByTitle(Page page, String title) {
        return (T) find((IContext) page, title, false);
    }

    public <T extends RemoteWebElement> T find(String name) {
        return this.find(name, true);
    }

    public <T extends RemoteWebElement> T find(String name, boolean wait) {
        return this.find((IContext) PageContext.getCurrentPage(), name, wait);
    }

    public <T extends RemoteWebElement, E extends IContext> T find(E context, String name, boolean wait) {
        return (T) findAndWaitForElement(context, name, wait).getLocatedEntity();
    }

    private <T> SearchInfo<T> findAndWaitForElement(IContext context, String name, boolean wait) {
        try {
            SearchInfo<T> info = this.getPageElementByPath(context, name, wait);
            if (!info.isPresent()) {
                throw new IllegalStateException(String.format("Element not found '%s' on page", name));
            }
            if (wait) {
                if (info.checkType(WebElement.class)) {
                    Wait.visibility((WebElement) info.getLocatedEntity(), "The page does not display the element " + this.formErrorMessage(info));
                } else if (info.checkType(IWrapElement.class)) {
                    Wait.visibility(((IWrapElement<WebElement>) info.getLocatedEntity()).getWrappedElement(), "The page does not display the element " + this.formErrorMessage(info));
                } else if (!info.checkType(List.class)) {
                    throw new ElementSearchError("Element with type '" + info.getLocatedEntity().getClass() + "' can not be found");
                }
            }
            return info;
        } catch (ElementDescriptionException e) {
            throw new ElementSearchError(e);
        }
    }

    private <T> SearchInfo<T> getPageElementByPath(Object context, String path, boolean wait) throws ElementDescriptionException {
        Map<String, Field> map = FieldUtilsExt.getDeclaredFieldsWithInheritance(context.getClass()).stream().filter(o -> o.isAnnotationPresent(ElementTitle.class))
                .collect(Collectors.toMap(o -> o.getAnnotation(ElementTitle.class).value(), Function.identity()));
        if (map.containsKey(path)) {
            return new SearchInfo<>(Environment.getReflection().getElementByField(context, map.get(path)), path, wait);
        }
        String[] titles = path.split("->");
        if (titles.length == 0) {
            return new SearchInfo<>(null, path, wait);
        }
        String title = titles[0].trim();
        T result;
        if (map.containsKey(title)) {
            result = Environment.getReflection().getElementByField(context, map.get(title));
        } else if (context instanceof List) {
            try {
                result = (T) ((List) context).get(Integer.parseInt(title));
            } catch (IndexOutOfBoundsException ignored) {
                throw new ElementDescriptionException("В листе нет элемента с индексом");
            } catch (NumberFormatException ignored) {
                throw new ElementDescriptionException(String.format("В элементе нет поля '%s', так же оно не может быть интерпретировано как индекс коллекции", title));
            }
        } else {
            throw new ElementDescriptionException("На странице нет элемента '" + title + "'");
        }
        if (titles.length > 1) {
            if (result instanceof IContext || result instanceof List) {
                return getPageElementByPath(result, path.replaceFirst(".*?->\\s*", ""), wait);
            } else {
                throw new ElementDescriptionException("Класс '" + result.getClass() + "' не является контекстом (Страницей или блоком)");
            }
        }
        return new SearchInfo<>(result, path, wait);
    }

    public <T extends RemoteWebElement> List<T> findList(String name) {
        return this.findList((IContext) PageContext.getCurrentPage(), name);
    }

    public <T extends RemoteWebElement, E extends IContext> List<T> findList(E context, String name) {
        try {
            SearchInfo result = findAndWaitForElement(context, name, false);
            if (!result.isPresent()) {
                throw new ElementSearchError("Element list not found");
            }
            if (!(result.getLocatedEntity() instanceof List)) {
                throw new IncorrectElementTypeError(String.format("The element was found, but it is not a list. The search was performed along the way: %s", name));
            }
            return (List<T>) result.getLocatedEntity();
        } catch (ElementSearchError e) {
            return new ArrayList<>();
        }
    }

    private Object getElementByField(IContext element, Field field) throws ElementDescriptionException {
        return Environment.getReflection().getElementByField(element, field);
    }


    protected String formErrorMessage(SearchInfo element) {
        StringBuilder errorMessage = new StringBuilder();
        String currentElementName = "\"" + element.getCurrentName() + "\"";
        if (element.getPaths().size() > 1) {
            if (currentElementName.chars().allMatch(Character::isDigit)) {
                String prevElement = element.getPaths().get(element.getCurrentPosition() - 1).toString();
                String elementOfListNotFound = String.format("with number '%s' not found in list: %s", currentElementName, prevElement);
                errorMessage.append(elementOfListNotFound);
            } else {
                errorMessage.append(currentElementName);
            }

            errorMessage.append(". The search was performed by path: ").append(element.getFullPath());
        } else {
            errorMessage.append(currentElementName);
        }

        return errorMessage.toString();
    }

    public <T extends RemoteWebElement> T find(String name, Class<T> type) {
        return this.find(name, type, true);
    }

    public <T extends RemoteWebElement> T find(String name, Class<T> type, boolean wait) {
        T element = this.find(name, wait);
        Class elementType = element.getClass();
        if (element instanceof MobileTypifiedElement && type.isAssignableFrom(elementType)) {
            return element;
        }
        throw new IncorrectElementTypeError(String.format("Found component named '%s', but his type does not meet the required. Expected: %s. Found: %s", name, type.getName(), elementType.getName()));
    }

    public <T extends RemoteWebElement> T find(String name, List<Class> clazz) {
        return this.find(name, clazz, true);
    }

    public <T extends RemoteWebElement> T find(String name, List<Class> clazz, boolean wait) {
        T element = this.find(name, wait);
        if (!clazz.contains(element.getClass())) {
            throw new AutotestError(String.format("Uncorrected element type. Element: %s. Valid types: %s", name, clazz.toString()));
        } else {
            return element;
        }
    }
}
