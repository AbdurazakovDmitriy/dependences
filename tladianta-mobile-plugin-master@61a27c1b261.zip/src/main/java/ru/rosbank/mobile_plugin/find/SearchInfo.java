package ru.rosbank.mobile_plugin.find;

import lombok.Getter;
import lombok.Setter;

import java.util.Arrays;
import java.util.List;
@Getter
public class SearchInfo<T> {
    private T locatedEntity;
    @Setter
    private int currentPosition = 0;
    private final List<String> paths;
    private final String fullPath;
    private final boolean waitAppear;
    private boolean isPresent = true;

    public SearchInfo(T locatedEntity, String fullPath, boolean waitAppear) {
        this.locatedEntity = locatedEntity;
        this.fullPath = fullPath;
        this.paths = Arrays.asList(fullPath.split("->"));
        this.waitAppear = waitAppear;
    }

    public void setLocatedEntity(T locatedEntity) {
        this.isPresent = locatedEntity != null;
        this.locatedEntity = locatedEntity;
    }

    public boolean checkType(Class clazz){
        return clazz.isInstance(locatedEntity);
    }

    public String getCurrentName() {
        return this.paths.get(this.currentPosition);
    }
}
