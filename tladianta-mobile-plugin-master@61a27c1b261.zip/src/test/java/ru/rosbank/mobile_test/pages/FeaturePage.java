package ru.rosbank.mobile_test.pages;

import org.openqa.selenium.support.FindBy;
import ru.rosbank.mobile_plugin.elements.core.text.IEditText;
import ru.rosbank.mobile_plugin.environment.IMaskData;
import ru.rosbank.mobile_plugin.pages.MobilePage;
import ru.rosbank.mobile_test.impls.InputImpl;
import ru.sbtqa.tag.pagefactory.annotations.ElementTitle;
import ru.sbtqa.tag.pagefactory.annotations.PageEntry;

@PageEntry(title = "Страница нестандартных элементов")
public class FeaturePage extends MobilePage {
    @ElementTitle("Поле c маской")
    @FindBy(xpath = "//date")
    @IMaskData(inputFormat = "_:2_:2_:4", fieldFormat = "_:2/_:2/_:4")
    private InputImpl dateEdit;

    @ElementTitle("Поле c динамической реализацией")
    @FindBy(xpath = "//dynamic-field")
    @IMaskData(inputFormat = "_:2_:2_:4", fieldFormat = "_:2/_:2/_:4")
    private IEditText dynamicEdit;
}
