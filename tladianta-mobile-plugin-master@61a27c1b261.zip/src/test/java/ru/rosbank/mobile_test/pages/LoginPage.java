package ru.rosbank.mobile_test.pages;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.support.FindBy;
import ru.rosbank.mobile_plugin.pages.MobilePage;
import ru.rosbank.mobile_test.impls.*;
import ru.sbtqa.tag.pagefactory.annotations.ElementTitle;
import ru.sbtqa.tag.pagefactory.annotations.PageEntry;

import java.util.List;

@PageEntry(title = "Страница логина")
public class LoginPage extends MobilePage {
    public LoginPage() {
    }

    @ElementTitle("Кнопка")
    @AndroidFindBy(xpath = "//button")
    @iOSXCUITFindBy(xpath = "//button")
    private ButtonImpl button;

    @ElementTitle("Поля")
    @AndroidFindBy(xpath = "//input")
    @iOSXCUITFindBy(xpath = "//input")
    private List<InputImpl> edits;

    @ElementTitle("Кнопки")
    @FindBy(xpath = "//button")
    private List<MobileElement> buttons;

    @ElementTitle("Поле")
    @FindBy(xpath = "//input")
    private InputImpl edit;

    @ElementTitle("Переключатель")
    @FindBy(xpath = "//check-box")
    private CheckBoxImpl checkBox;

    @ElementTitle("Табулятор")
    @FindBy(xpath = "//combo-box")
    private SelectImpl comboBox;


    @ElementTitle("Блок")
    @FindBy(xpath = "//block")
    private MobileBlock block;
}
