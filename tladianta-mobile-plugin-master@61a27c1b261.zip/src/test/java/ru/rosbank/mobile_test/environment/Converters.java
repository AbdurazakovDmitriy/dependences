package ru.rosbank.mobile_test.environment;

import io.appium.java_client.MobileElement;
import org.openqa.selenium.WebElement;
import ru.rosbank.at.exceptions.InnerAssertionException;
import ru.rosbank.at.exceptions.InnerException;
import ru.rosbank.at.helpers.TypeConverters;
import ru.rosbank.mobile_plugin.elements.core.text.IHaveText;
import ru.rosbank.mobile_test.driver.ElementProvider;
import ru.rosbank.mobile_test.generators.TickingFuture;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * класс доступа к конвертерам позволяющим сложные проверки
 */
public class Converters {
    public static class XpathToIdConverter implements TypeConverters.IConvertFromString<String> {
        private final static Pattern GLOBAL_CONDITIONS_EXTRACTOR = Pattern.compile("\\$\\{(.*?)\\}/");
        private final static Pattern DYNAMIC_PROPERTY_EXTRACTOR = Pattern.compile("\\w+=`(.*)`");
        private final static Pattern DYNAMIC_CONDITION_EXTRACTOR = Pattern.compile("(.+)\\{(.+)\\}");
        private final static Pattern STATIC_PROPERTY_EXTRACTOR = Pattern.compile("\\s*@(\\w+)\\s*=\\s*'(.*)\\s*'");

        private String executeDefinePart(String value) {
            Matcher matcher = GLOBAL_CONDITIONS_EXTRACTOR.matcher(value);
            if (matcher.find()) {
                String definition = matcher.group(1);
                String[] properties = definition.split(",");
                for (int i = 0; i < properties.length; i++) {
                    Matcher propertyMatcher = DYNAMIC_PROPERTY_EXTRACTOR.matcher(properties[i]);
                    while (propertyMatcher.find()) {
                        String dynamicProperty = propertyMatcher.group(1);
                        if (dynamicProperty.matches("//.*")) {
                            properties[i] = properties[i].replaceFirst("`//.*?`", String.format("'%s'", ElementProvider.getInstance().provide(dynamicProperty).get().getAttribute("test-id")));
                        }
                    }
                }
                definition = String.join(",", properties);
                value = matcher.replaceFirst(String.format("\\$\\{%s\\}/", definition));
            }
            return value;
        }

        @Override
        public String convert(String value) {
            try {
                value = executeDefinePart(value);
                Matcher matcher = DYNAMIC_CONDITION_EXTRACTOR.matcher(value);
                if (matcher.matches()) {
                    List<WebElement> elements = ElementProvider.getInstance().provideMany(matcher.group(1)).stream().map(TickingFuture::get).collect(Collectors.toList());
                    if (elements.size() == 0) {
                        throw new IndexOutOfBoundsException();
                    }
                    String[] properties = matcher.group(2).split(",");
                    Predicate<WebElement> predicate = (o) -> true;
                    for (String property : properties) {
                        Matcher propertyMatcher = STATIC_PROPERTY_EXTRACTOR.matcher(property);
                        if (propertyMatcher.matches()) {
                            predicate = predicate.and(o -> o.getAttribute(propertyMatcher.group(1)).equals(propertyMatcher.group(2)));
                        } else throw new InnerException("could not extract properties");
                    }
                    return elements.stream().filter(predicate).findFirst().orElseThrow(RuntimeException::new).getAttribute("test-id");
                }
                return ElementProvider.getInstance().provide(value).get().getAttribute("test-id");
            } catch (Exception e) {
                throw new InnerException("Element was not found", e);
            }
        }
    }

    private static final Pattern PREDICATE = Pattern.compile("\\[([a-zA-Z\\-*]*?)\\s*(:\\s*(.*))?\\]");
    private static final Pattern PROPERTY = Pattern.compile("([a-zA-Z]*)\\s*=\\s*'(.*)'");

    private synchronized static Predicate<TickingFuture> buildPredicate(String path) {
        Matcher matcher = PREDICATE.matcher(path);
        if (!matcher.matches()) {
            throw new InnerException("Bad predicate");
        }
        String group = matcher.group(1);
        Predicate<TickingFuture> predicate = o -> o.force().getTagName().equals(group);
        String fullDefinition = matcher.group(3);
        if (fullDefinition != null) {
            String[] definitions = fullDefinition.split(",");
            for (String definition : definitions) {
                Matcher definitionMatcher = PROPERTY.matcher(definition);
                if (!definitionMatcher.matches()) {
                    throw new InnerException("Bad predicate");
                }
                predicate = predicate.and(o -> o.force().getAttribute(definitionMatcher.group(1)).equals(definitionMatcher.group(2)));
            }
        }
        return predicate;
    }

    public static class PredicateToIdConverter implements TypeConverters.IConvertFromString {
        @Override
        public String convert(String path) {
            String[] pId = new String[1];
            ElementProvider.getInstance().modify(buildPredicate(path), o -> pId[0] = o.force().getAttribute("test-id"));
            return pId[0];
        }
    }

    public static class PredicateToElementConverter implements TypeConverters.IConvertFromString {
        @Override
        public MobileElement convert(String path) {
            MobileElement[] pId = new MobileElement[1];
            ElementProvider.getInstance().modify(buildPredicate(path), o -> pId[0] = (MobileElement) o.force());
            return pId[0];
        }
    }

    public static class ElementListExtractor extends TypeConverters.None implements TypeConverters.ICheckValue<String> {
        @Override
        public boolean check(Object actual, String name) {
            if (actual == null) {
                throw new InnerAssertionException("Null can not be applied here");
            }
            List<IHaveText> elementList;
            try {
                elementList = (List<IHaveText>) actual;
            } catch (ClassCastException e) {
                throw new InnerAssertionException("Неверный тип результата: " + actual.getClass());
            }
            Optional<IHaveText> text = elementList.stream()
                    .filter(o -> o.getText().equals(name))
                    .findFirst();
            if (text.isPresent()) {
                elementList.remove(text.get());
                return true;
            }
            return false;
        }
    }
}
