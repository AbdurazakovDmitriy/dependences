package ru.rosbank.mobile_test.environment.generate;

import ru.rosbank.at.annotations.IPhase;
import ru.rosbank.at.helpers.PhaseProcessor;
import ru.rosbank.at.helpers.ReflectionBuilder;
import ru.rosbank.at.helpers.TypeConverters;
import ru.sbtqa.tag.datajack.Stash;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@IPhase(value = "generate", processingClass = IStoreValues.StoreValueProcessor.class)
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface IStoreValues {
    IStoreValue[] value();
    class StoreValueProcessor implements PhaseProcessor<IStoreValue> {
        @Override
        public void process(IStoreValue iStoreValue) {
            TypeConverters.IConvertFromString converter= (TypeConverters.IConvertFromString) ReflectionBuilder.join(iStoreValue.convertedBy()).build();
            Stash.put(iStoreValue.key(), converter.convert(iStoreValue.value()));
        }
    }
}
