package ru.rosbank.mobile_test.environment.generate;

import org.jetbrains.annotations.NotNull;
import ru.rosbank.at.annotations.IPhase;
import ru.rosbank.mobile_test.generators.ElementManager;

import java.lang.annotation.*;

@IPhase(value = "generate", processingClass = IGenerateElementsMany.GenerateElementsProcessor.class)
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Repeatable(value = IGenerateElementsMany.class)
public @interface IGenerateElement {

    /**
     * Строковый ключ по которому элемент прикрепляется к провайдеру в конечном итоге
     * может быть пустым только при условии непустого type
     * @return ключ
     */
    @NotNull
    String locator() default "";

    /**
     * @return Текст элемента
     */
    @NotNull
    String text() default "";

    /**
     * @return свойства элемента
     */
    @NotNull
    ElementManager.Condition[] conditions() default {ElementManager.Condition.VISIBLE, ElementManager.Condition.ENABLED};

    ElementManager.Type type() default ElementManager.Type.NONE;
}
