package ru.rosbank.mobile_test.environment.package_generate;

import org.openqa.selenium.WebDriver;
import ru.rosbank.at.annotations.IPhase;
import ru.rosbank.at.helpers.PhaseProcessor;
import ru.rosbank.mobile_plugin.steps.MobileSetupSteps;
import ru.rosbank.mobile_test.driver.DriverLoader;
import ru.rosbank.mobile_test.driver.DummyDriverService;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.PACKAGE)
@IPhase(value = "package-generate", processingClass = IStabDriver.StabDriverProcessor.class,priority = 1)
public @interface IStabDriver {

    Class<? extends WebDriver> value();

    class StabDriverProcessor implements PhaseProcessor<IStabDriver> {
        @Override
        public void process(IStabDriver iStabDriver) {
            DriverLoader.getInstance().loadService(DummyDriverService.class);
            DriverLoader.getInstance().loadWebDriver(iStabDriver.value());
            DriverLoader.loadPluginBasedDriver(MobileSetupSteps.class);
        }
    }
}
