package ru.rosbank.mobile_test.environment.generate;

import org.jetbrains.annotations.NotNull;
import ru.rosbank.at.annotations.IPhase;
import ru.rosbank.at.helpers.PhaseProcessor;
import ru.rosbank.mobile_test.generators.ElementManager;

import java.lang.annotation.*;

@IPhase(value = "generate", processingClass = IGenerateElementsMany.GenerateElementsProcessor.class)
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface IGenerateElementsMany {
    IGenerateElement[] value();

    class GenerateElementsProcessor implements PhaseProcessor {
        @Override
        public void process(@NotNull Annotation annotation) {
            if (annotation.annotationType() == IGenerateElement.class) {
                IGenerateElement result = (IGenerateElement) annotation;
                ElementManager.getInstance().register(result.type(), result.locator(), result.text(), result.conditions());
            } else if (annotation.annotationType() == IGenerateElementsMany.class) {
                IGenerateElementsMany results = (IGenerateElementsMany) annotation;
                for (IGenerateElement result : results.value()) {
                    ElementManager.getInstance().register(result.type(), result.locator(), result.text(), result.conditions());
                }
            }
        }
    }
}
