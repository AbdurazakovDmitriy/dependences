package ru.rosbank.mobile_test.environment.class_generate;

import ru.rosbank.at.annotations.IPhase;
import ru.rosbank.at.helpers.PhaseProcessor;
import ru.sbtqa.tag.pagefactory.PageManager;
import ru.sbtqa.tag.pagefactory.context.PageContext;
import ru.sbtqa.tag.pagefactory.exceptions.PageInitializationException;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@IPhase(value = "class-generate", processingClass = IInitPages.InitPagesProcessor.class)
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface IInitPages {
    String value() default "Страница логина";
    IRegisterImplementationsMany implementations() default @IRegisterImplementationsMany({});

    class InitPagesProcessor implements PhaseProcessor<IInitPages> {
        @Override
        public void process(IInitPages iInitPages) {
            try {
                new IRegisterImplementationsMany.RegisterElementsImplementationProcessor().process(iInitPages.implementations());
                PageContext.clearPageContext();
                PageManager.cachePages();
                PageManager.getPage(iInitPages.value());
            } catch (PageInitializationException e) {
                process(iInitPages, e);
            }
        }
    }
}
