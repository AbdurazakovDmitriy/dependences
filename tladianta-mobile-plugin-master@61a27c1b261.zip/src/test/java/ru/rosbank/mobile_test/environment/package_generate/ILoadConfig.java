package ru.rosbank.mobile_test.environment.package_generate;

import cucumber.api.java.Before;
import org.aeonbits.owner.util.Collections;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.junit.After;
import ru.rosbank.at.annotations.IPhase;
import ru.rosbank.at.exceptions.InnerException;
import ru.rosbank.at.helpers.PhaseProcessor;
import ru.rosbank.at.helpers.ReflectionBuilder;
import ru.rosbank.automation.configuration.ApplicationContext;
import ru.rosbank.automation.configuration.ApplicationManager;
import ru.rosbank.automation.configuration.ConfigurationManager;
import ru.rosbank.automation.stepdefs.SetupStepDefs;
import ru.rosbank.automation.steps.CommonSetupSteps;
import ru.rosbank.mobile_plugin.stepdefs.MobileSetupStepDefs;
import ru.rosbank.mobile_plugin.steps.MobileSetupSteps;
import ru.rosbank.mobile_test.helpers.PropertyBuilder;
import ru.sbtqa.tag.datajack.Stash;
import ru.sbtqa.tag.pagefactory.PageManager;

import java.lang.annotation.*;
import java.lang.reflect.Method;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.PACKAGE, ElementType.TYPE, ElementType.METHOD})
@IPhase(value = "package-generate", processingClass = ILoadConfig.LoadConfigProcessor.class, priority = 0)
public @interface ILoadConfig {
    String value();

    boolean initContext() default false;

    boolean auto() default false;

    String[] excludeCommonBefore() default {"setUpVideo"};

    String[] excludePluginBefore() default {};

    String[] excludeCommonAfter() default {"tearDown"};

    String[] excludePluginAfter() default {};

    class LoadConfigProcessor implements PhaseProcessor<ILoadConfig> {

        private SetupStepDefs common;
        private MobileSetupStepDefs plugin;
        @NotNull
        private static final Map<Method, Double> commonBeforeMethods;
        @NotNull
        private static final Map<Method, Double> pluginBeforeMethods;
        @NotNull
        private static final Map<Method, Double> commonAfterMethods;
        @NotNull
        private static final Map<Method, Double> pluginAfterMethods;

        private static String currentContext="undefined";

        private static Map<Method, Double> parseCucumberAnnotations(Method[] methods, Class<? extends Annotation> annotationClass, double correction) {
            return Arrays.stream(methods)
                    .filter(o -> o.isAnnotationPresent(annotationClass))
                    .collect(Collectors.toMap(Function.identity(),
                            o -> correction + (Integer) ReflectionBuilder.join(annotationClass)
                                    .joinTarget(o.getAnnotation(annotationClass)).withMethod("order").get()));
        }


        static {
            Method[] commonMethods = SetupStepDefs.class.getDeclaredMethods();
            Method[] pluginMethods = MobileSetupStepDefs.class.getDeclaredMethods();
            commonBeforeMethods = parseCucumberAnnotations(commonMethods, Before.class, 0.1);
            pluginBeforeMethods = parseCucumberAnnotations(pluginMethods, Before.class, 0.2);
            commonAfterMethods = parseCucumberAnnotations(commonMethods, cucumber.api.java.After.class, 0.1);
            pluginAfterMethods = parseCucumberAnnotations(pluginMethods, cucumber.api.java.After.class, 0.2);
        }

        @Nullable
        private Set<String> excludeCommonAfter;
        @Nullable
        private Set<String> excludePluginAfter;

        Function<Method, Runnable> buildRun(Object target) {
            return o -> () -> {
                try {
                    o.invoke(target);
                } catch (Exception e) {
                    throw new InnerException("Не удалось выполнить конфигурацию", e);
                }
            };
        }


        void runCucumberAnnotations(Map<Method, Double> map1, Map<Method, Double> map2, Set<String> excludeCommon, Set<String> excludePlugin) {
            Stream<Runnable> commonStream = map1.entrySet().stream().filter(o -> !excludeCommon.contains(o.getKey().getName()))
                    .sorted(Comparator.comparingDouble(Map.Entry::getValue)).map(o -> buildRun(common).apply(o.getKey()));
            Stream<Runnable> pluginStream = map2.entrySet().stream().filter(o -> !excludePlugin.contains(o.getKey().getName()))
                    .sorted(Comparator.comparingDouble(Map.Entry::getValue)).map(o -> buildRun(plugin).apply(o.getKey()));
            Stream.concat(commonStream, pluginStream)
                    .forEach(Runnable::run);
        }

        void init(Set<String> excludeCommon, Set<String> excludePlugin) {
            common = new SetupStepDefs();
            plugin = new MobileSetupStepDefs();
            runCucumberAnnotations(commonBeforeMethods, pluginBeforeMethods, excludeCommon, excludePlugin);
        }

        @After
        public void close() {
            if (excludeCommonAfter != null && excludePluginAfter != null) {
                runCucumberAnnotations(commonAfterMethods, pluginAfterMethods, excludeCommonAfter, excludePluginAfter);
            }
        }

        @Override
        public void process(ILoadConfig iLoadConfig) {
            if (!currentContext.equals(iLoadConfig.value())) {
                PropertyBuilder.getInstance().loadConfig(iLoadConfig.value());
                ApplicationContext.getAppProperties().clear();
                ApplicationManager.initApplicationsProperties();
                ConfigurationManager.resetConfigurationInClasses();
                currentContext=iLoadConfig.value();
            }
            if (iLoadConfig.initContext()) {
                if (iLoadConfig.auto()) {
                    init(Collections.set(iLoadConfig.excludeCommonBefore()), Collections.set(iLoadConfig.excludePluginBefore()));
                    this.excludePluginAfter = Collections.set(iLoadConfig.excludeCommonAfter());
                    this.excludeCommonAfter = Collections.set(iLoadConfig.excludePluginAfter());
//                    ApplicationManager.resetApplicationContext("mobile-test");
                }
                else {
                    ApplicationManager.initApplicationsProperties();
                    Stash.clear();
                    ReflectionBuilder.join(CommonSetupSteps.class).force().withMethod("registerClassForReset");
                    PageManager.cachePages();
                    MobileSetupSteps.initEnvironment();
                    MobileSetupSteps.uploadSteps();
                    MobileSetupSteps.registerClassForReset();
                    ApplicationManager.initDefaultContext();
//                    ApplicationManager.resetApplicationContext("mobile-test");
                }
            }
        }
    }
}
