package ru.rosbank.mobile_test.environment.class_generate;

import ru.rosbank.at.annotations.IPhase;
import ru.rosbank.automation.environment.IWrapElement;

import java.lang.annotation.*;

@IPhase(value = "generate", processingClass = IRegisterImplementationsMany.RegisterElementsImplementationProcessor.class)
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Repeatable(value = IRegisterImplementationsMany.class)
public @interface IRegisterImplementation {
    Class<? extends IWrapElement> declarationClass();
    Class<? extends IWrapElement> implementationClass();
}
