package ru.rosbank.mobile_test.environment.class_generate;

import org.jetbrains.annotations.NotNull;
import ru.rosbank.at.annotations.IPhase;
import ru.rosbank.at.helpers.PhaseProcessor;
import ru.rosbank.mobile_plugin.elements.TypeResolver;

import java.lang.annotation.*;

@IPhase(value = "generate", processingClass = IRegisterImplementationsMany.RegisterElementsImplementationProcessor.class)
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface IRegisterImplementationsMany {
    IRegisterImplementation[] value();

    class RegisterElementsImplementationProcessor implements PhaseProcessor {
        @Override
        public void process(@NotNull Annotation annotation) {
            if (annotation.annotationType() == IRegisterImplementation.class) {
                IRegisterImplementation result = (IRegisterImplementation) annotation;
                TypeResolver.registerType(result.declarationClass(),(Class)result.implementationClass());
            } else if (annotation.annotationType() == IRegisterImplementationsMany.class) {
                IRegisterImplementationsMany results = (IRegisterImplementationsMany) annotation;
                for (IRegisterImplementation result : results.value()) {
                    TypeResolver.registerType(result.declarationClass(),(Class)result.implementationClass());
                }
            }
        }
    }

}
