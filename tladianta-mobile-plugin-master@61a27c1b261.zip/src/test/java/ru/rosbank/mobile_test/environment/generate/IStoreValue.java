package ru.rosbank.mobile_test.environment.generate;

import ru.rosbank.at.annotations.IPhase;
import ru.rosbank.at.helpers.TypeConverters;

import java.lang.annotation.*;

@IPhase(value = "generate", processingClass = IStoreValues.StoreValueProcessor.class)
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Repeatable(value = IStoreValues.class)
public @interface IStoreValue {
    String key();
    String value();
    Class<? extends TypeConverters.IConvertFromString> convertedBy() default TypeConverters.None.class;
}
