package ru.rosbank.mobile_test;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import ru.sbtqa.tag.pagefactory.Tag;

//@RunWith(Cucumber.class)
@CucumberOptions(monochrome = true, plugin = {"pretty"},
        glue = {"ru.rosbank.automation.stepdefs",
                "ru.rosbank.mobile_plugin.stepdefs"
                },
        features = {"src/test/resources/features"})
public class MobileTest extends Tag {
}