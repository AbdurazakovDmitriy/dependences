package ru.rosbank.mobile_test.helpers;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import ru.rosbank.at.exceptions.InnerException;
import ru.rosbank.at.helpers.ReflectionBuilder;
import ru.rosbank.automation.configuration.ApplicationContext;
import ru.rosbank.automation.configuration.ApplicationManager;
import ru.rosbank.automation.utils.FileUtils;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.function.Function;

public class PropertyBuilder {
    static class PropertyHolder{
        @JsonProperty("description")
        String description;
        @JsonProperty("properties")
        Map<String,Map<Object,Object>> values;
    }

    @Contract(pure = true)
    private PropertyBuilder(){

    }

    private static final PropertyBuilder instance=new PropertyBuilder();

    @Contract(pure = true)
    public static PropertyBuilder getInstance(){
        return instance;
    }

    private void buildProperties(@NotNull PropertyHolder holder) throws IOException {
        String path=this.getClass().getClassLoader().getResources("").nextElement().getPath();
        Function<String,File> resourceToFile=(p)-> new File(String.format("%s/%s",path.replaceAll("%20", " "),p));
        holder.values.keySet().stream().map(o->String.format("config/app/%s.properties", o)
                .replace("app/$",""))
                .map(resourceToFile)
                .forEach(o->{o.delete();
                    try {
                        o.createNewFile();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
        holder.values.forEach((key,value)-> FileUtils.writePropertiesToResource((String.format("config/app/%s.properties", key))
                .replace("app/$",""),value));
    }

    /**
     * загружает свойства из джексона в ресурсы проекта
     * @param fileName имя джейсон файла в папке конфигов
     */
    public void loadFromFile(@NotNull String fileName){
        ObjectMapper mapper=new ObjectMapper();
        try {
            PropertyHolder holder=mapper.readValue(this.getClass().getClassLoader()
                    .getResource(String.format("configs/%s.json", fileName)), PropertyHolder.class);
            System.out.println(String.format("Загружен '%s'",holder.description));
            buildProperties(holder);
        } catch (IOException e) {
            throw new InnerException(e);
        }
    }

    /**
     * Загружает конфигурацию из указанного модулям
     * @param propsBind имя файла содержащего свойства (без расширения)
     * @return имя приложения
     */
    public void loadConfig(String propsBind) {
        Map map= (Map) ReflectionBuilder.join(ApplicationContext.class)
                .withField("appProperties")
                .andThen(ThreadLocal.class)
                .withMethod("get")
                .get();
        map.clear();
        PropertyBuilder.getInstance().loadFromFile(propsBind);
        //String appName= MobileConfiguration.create().getAppName();
        //if (appName!=null) {
        //    ApplicationManager.resetApplicationContext(appName);
        //}
        //return appName;
    }
}
