package ru.rosbank.mobile_test.helpers;

import org.junit.After;
import ru.rosbank.at.data.TestData;
import ru.rosbank.at.helpers.FastUnit;
import ru.rosbank.at.results.TestResults;
import ru.rosbank.automation.transformer.NegationCondition;
import ru.rosbank.mobile_test.driver.ElementProvider;

public abstract class MobileUnitTest implements FastUnit {

    protected static final NegationCondition POSITIVE = new NegationCondition("contain");
    protected static final NegationCondition NEGATIVE = new NegationCondition("not");

    @After
    public void teardown() {
        TestResults.getInstance().clean();
        ElementProvider.getInstance().cleanCache();
        TestData.getInstance().cleanCache();
    }
}
