package ru.rosbank.mobile_test.driver;

import io.appium.java_client.MobileDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.bys.ContentMappedBy;
import io.appium.java_client.pagefactory.bys.ContentType;
import io.appium.java_client.pagefactory.bys.builder.ByChained;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.html5.Location;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.remote.Response;
import ru.rosbank.at.helpers.ReflectionBuilder;
import ru.rosbank.at.results.TestResults;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;
import ru.rosbank.mobile_test.generators.TickingFuture;

import java.util.*;
import java.util.stream.Collectors;

public class PseudoDriver extends RemoteWebDriver implements MobileDriver<MobileElement> {

    String url = "";

    @Override
    public void get(String url) {
        TestResults.getInstance().push("current-url", url);
        this.url = url;
    }

    @Override
    public String getCurrentUrl() {
        return null;
    }

    @Override
    public String getTitle() {
        return null;
    }

    public PseudoDriver() {

    }

    @Override
    public String getAutomationName() {
        return MobileConfiguration.create().getAppiumAutomationName();
    }

    @Override
    public String getPlatformName() {
        return MobileConfiguration.create().getAppiumPlatformName().toString();
    }

    @Override
    protected void startSession(Capabilities capabilities) {

    }

    private By cleanBy(By by){
        if (by instanceof ContentMappedBy){
            By innerBy= (By) ReflectionBuilder.join(by.getClass())
                    .joinTarget(by)
                    .force()
                    .withField("map")
                    .andThen()
                    .withMethod("get",Object.class)
                    .call(ContentType.NATIVE_MOBILE_SPECIFIC);
            if (innerBy instanceof ByChained) {
                By[] bys = (By[]) ReflectionBuilder.join(ByChained.class)
                        .joinTarget(innerBy)
                        .withField("bys")
                        .force()
                        .get();
                by = bys[0];
            }
        }
        if (by instanceof By.ByTagName) {
            by = By.xpath("//" + parseTagName(by));
        }
        return by;
    }

    @Override
    public List findElements(By by) {
        by=cleanBy(by);
        List<WebElement> result = ElementProvider.getInstance().provideMany(parseXpath(by))
                .stream()
                .map(TickingFuture::get)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        result.forEach(o -> ((RemoteWebElement) o).setParent(this));
        return result;
    }

    private String parseXpath(By by) {
        return by.toString().replace("By.xpath: ", "");
    }

    private String parseTagName(By by) {
        return by.toString().replace("By.tagName: ", "");
    }

    @Override
    public MobileElement findElement(By by) {
        by=cleanBy(by);
        String xpath = by.toString().replace("By.xpath: ", "");
        WebElement result = Optional.ofNullable(ElementProvider.getInstance().provide(xpath))
                .orElseThrow(() -> new org.openqa.selenium.NoSuchElementException(String.format("Элемент с xpath '%s' не зарегистрирован", xpath)))
                .get();
        result = Optional.ofNullable(result).orElseThrow(() -> new NoSuchElementException(String.format("Элемент с xpath '%s' еще не появился", xpath)));
        ((RemoteWebElement) result).setParent(this);
        return (MobileElement) result;
    }


    @Override
    public String getPageSource() {
        return null;
    }

    @Override
    public void close() {

    }

    @Override
    public void quit() {

    }

    @Override
    public Set<String> getWindowHandles() {
        return null;
    }

    @Override
    public String getWindowHandle() {
        return null;
    }

    @Override
    public TargetLocator switchTo() {
        return null;
    }

    @Override
    public Navigation navigate() {
        return null;
    }

    @Override
    public Options manage() {
        return null;
    }

    @Override
    public DummyMobileElement findElementByClassName(String s) {
        return null;
    }

    @Override
    public List findElementsByClassName(String s) {
        return null;
    }

    @Override
    public DummyMobileElement findElementByCssSelector(String s) {
        return null;
    }

    @Override
    public List findElementsByCssSelector(String s) {
        return null;
    }

    @Override
    public DummyMobileElement findElementById(String s) {
        return null;
    }

    @Override
    public List findElementsById(String s) {
        return null;
    }

    @Override
    public DummyMobileElement findElementByLinkText(String s) {
        return null;
    }

    @Override
    public List findElementsByLinkText(String s) {
        return null;
    }

    @Override
    public DummyMobileElement findElementByPartialLinkText(String s) {
        return null;
    }

    @Override
    public List findElementsByPartialLinkText(String s) {
        return null;
    }

    @Override
    public DummyMobileElement findElementByName(String s) {
        return null;
    }

    @Override
    public List findElementsByName(String s) {
        return null;
    }

    @Override
    public DummyMobileElement findElementByTagName(String s) {
        return null;
    }

    @Override
    public List findElementsByTagName(String s) {
        return null;
    }

    @Override
    public DummyMobileElement findElementByXPath(String s) {
        return null;
    }

    @Override
    public List findElementsByXPath(String s) {
        return null;
    }

    @Override
    public Response execute(String s) {
        return null;
    }

    @Override
    public DummyMobileElement findElement(String s, String s1) {
        return null;
    }

    @Override
    public List findElements(String s, String s1) {
        return null;
    }

    @Override
    public WebDriver context(String s) {
        return null;
    }

    @Override
    public Set<String> getContextHandles() {
        return null;
    }

    @Override
    public String getContext() {
        return null;
    }

    @Override
    public void rotate(ScreenOrientation screenOrientation) {

    }

    @Override
    public ScreenOrientation getOrientation() {
        return null;
    }

    @Override
    public void rotate(DeviceRotation deviceRotation) {

    }

    @Override
    public DeviceRotation rotation() {
        return null;
    }

    @Override
    public Location location() {
        return null;
    }

    @Override
    public void setLocation(Location location) {

    }

    public Response execute(String driverCommand, Map<String, ?> parameters) {
        return new Response();
    }

    @Override
    public Map<String, Object> getSessionDetails() {
        return new HashMap<>();
    }
}
