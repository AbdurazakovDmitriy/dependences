package ru.rosbank.mobile_test.driver;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import ru.rosbank.at.virtual.AbstractElementHolder;
import ru.rosbank.mobile_test.generators.TickingFuture;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class ElementProvider extends AbstractElementHolder<TickingFuture> {

    /**
     * Экземпляр класса ElementProvider
     */
    private final static ThreadLocal<ElementProvider> PROVIDER = ThreadLocal.withInitial(ElementProvider::new);

    public static ElementProvider getInstance() {
        return PROVIDER.get();
    }

    @NotNull
    @Override
    protected Stream<TickingFuture> queryProcess(@NotNull String locator) {
        return Optional.ofNullable(forLocator(locator)).orElse(new ArrayList<>()).stream();
    }

    @NotNull
    @Override
    @Contract("_,_ -> param1")
    protected String pushProcess(@NotNull String locator, @NotNull TickingFuture remoteWebElement) {
        return locator;
    }
}
