package ru.rosbank.mobile_test.driver;

import org.openqa.selenium.remote.RemoteWebDriver;
import ru.rosbank.mobile_plugin.driver.MobileDriverService;

import java.util.UUID;

public class DummyDriverService extends MobileDriverService<RemoteWebDriver> {
    private RemoteWebDriver driver;
    private String uuid;

    public DummyDriverService() {
        this.uuid=UUID.randomUUID().toString();
    }

    @Override
    public RemoteWebDriver getDriver() {
        return driver;
    }

    public String getDeviceUDID() {
        return uuid;
    }

    @Override
    public void mountDriver() {

    }

    @Override
    public void demountDriver() {

    }

    @Override
    public boolean isDriverEmpty() {
        return driver == null;
    }
}
