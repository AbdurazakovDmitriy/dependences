package ru.rosbank.mobile_test.driver;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.WebDriver;
import ru.rosbank.at.exceptions.InnerException;
import ru.rosbank.at.helpers.ReflectionBuilder;
import ru.sbtqa.tag.pagefactory.drivers.DriverService;
import ru.sbtqa.tag.pagefactory.environment.Environment;

/**
 * Класс закгрузчик, позволяет подменить инстансы драйвера и сервиса
 */
public class DriverLoader {
    /**
     * Экземпляр загрузчика
     */
    @NotNull
    private static final DriverLoader loader = new DriverLoader();

    @Contract(pure = true)
    protected DriverLoader() {

    }

    /**
     * Метод предоставляет экземпляр загрузчика
     */
    @Contract(pure = true)
    public static DriverLoader getInstance() {
        return loader;
    }

    /**
     * Метод загружает сервис драйвера
     */
    public void loadService(@NotNull String className) {
        try {
            loadService((Class<? extends DriverService>) Class.forName(className));
        } catch (ClassNotFoundException e) {
            throw new InnerException(String.format("Не существует такого сервиса %s", className));
        } catch (ClassCastException e) {
            throw new InnerException("Переданный класс не является сервисом");
        }
    }

    /**
     * Метод загружает сервис драйвера
     */
    public void loadService(@NotNull Class<? extends DriverService> clazz) {
        DriverService service;
        try {
            service = clazz.newInstance();
        } catch (IllegalAccessException e) {
            throw new InnerException("В предоставленном классе DriverService должен существовать публичный конструктор");
        } catch (InstantiationException e) {
            throw new InnerException("В предоставленном классе DriverService должен существовать пустой конструктор");
        }
        ReflectionBuilder.join(Environment.class).withField("driverService")
                .andThen(ThreadLocal.class)
                .withMethod("set", Object.class)
                .call(service);
    }

    /**
     * Метод загружает драйвер
     */
    public void loadWebDriver(@NotNull Class<? extends WebDriver> clazz) {
        WebDriver driver;
        try {
            driver = clazz.newInstance();
        } catch (IllegalAccessException e) {
            throw new InnerException("В предоставленном классе Driver должен существовать публичный конструктор");
        } catch (InstantiationException e) {
            throw new InnerException("В предоставленном классе Driver должен существовать пустой конструктор");
        }
        DriverService service = Environment.getDriverService();
        ReflectionBuilder.join(service.getClass()).joinTarget(service)
                .withField(WebDriver.class)
                .set(driver);
    }

    /**
     * Метод загружает сервис в хранилище драйвера
     */
    public static void loadPluginBasedDriver(Class clazz) {
        ReflectionBuilder.join(clazz)
                .withField("storage")
                .andThen(ThreadLocal.class)
                .withMethod("set", Object.class)
                .call(Environment.getDriverService());
    }
}
