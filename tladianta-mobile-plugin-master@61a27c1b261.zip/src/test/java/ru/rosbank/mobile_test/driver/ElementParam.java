package ru.rosbank.mobile_test.driver;

import ru.rosbank.at.exceptions.InnerException;

import java.util.Arrays;

public enum ElementParam {
    TEXT("text"),
    VISIBLE("visible"),
    ENABLED("enabled"),
    TEST_ID("test-id"),
    SELECTED("selected"),
    IS_OPENED("is-opened"),
    VISIBLE_TIME("visible-time"),
    INVISIBLE_TIME("invisible-time"),
    TAG_NAME("tagName"),
    MOBILE_CLASS("class"),
    CHECKED("checked");
    private final String attributeName;

    ElementParam(String attributeName) {
        this.attributeName = attributeName;
    }

    public static ElementParam fromAttributeName(String attributeName) {
        return Arrays.stream(ElementParam.values()).filter(o -> o.attributeName.equals(attributeName))
                .findFirst()
                .orElseThrow(InnerException::new);
    }

    public String getAttributeName() {
        return attributeName;
    }
}
