package ru.rosbank.mobile_test.driver;

import io.appium.java_client.MobileElement;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Coordinates;
import org.openqa.selenium.remote.RemoteWebDriver;
import ru.rosbank.at.results.TestResults;
import ru.sbtqa.tag.pagefactory.environment.Environment;

import java.util.*;

public class DummyMobileElement extends MobileElement implements WebElement {

    public String uuid;

    private Map<ElementParam, Object> elementParams = new HashMap<>();

    @Override
    public void click() {
        TestResults.getInstance().push("#click",uuid);
    }

    @Override
    public void submit() {
        TestResults.getInstance().push("#submit",uuid);
    }

    @Override
    public void sendKeys(CharSequence... charSequences) {
        TestResults.getInstance().push("#sendKeys", uuid);
        TestResults.getInstance().push("#sendKeys/value/", String.join("",charSequences));
        String text = (String) elementParams.get(ElementParam.TEXT);
        for (CharSequence charSequence : charSequences) {
            text = text.concat(charSequence.toString());
        }
        elementParams.put(ElementParam.TEXT, text);
    }

    @Override
    public void clear() {
        TestResults.getInstance().push("#clear", uuid);
        elementParams.put(ElementParam.TEXT, "");
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), uuid);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        try {
            return uuid.equals(((MobileElement)o).getAttribute("test-id"));
        } catch (Exception e){
            return false;
        }
    }

    @Override
    public String getTagName() {
        return  getAttribute("tagName");
    }

    @Override
    public String getAttribute(String s) {
        Object o = elementParams.get(ElementParam.fromAttributeName(s));
        return o == null ? null : o.toString();
    }

    public void setAttribute(String key, Object value) {
        elementParams.put(ElementParam.fromAttributeName(key), value);
    }

    @Override
    public boolean isSelected() {
        ru.rosbank.at.results.TestResults.getInstance().push("#isSelected", this.uuid);
        return (boolean) this.elementParams.getOrDefault(ElementParam.SELECTED, false);
    }

    @Override
    public boolean isEnabled() {
        TestResults.getInstance().push("#isEnabled");
        return (boolean) this.elementParams.get(ElementParam.ENABLED);
    }

    @Override
    public String getText() {
        TestResults.getInstance().push("#getText");
        return (String) elementParams.get(ElementParam.TEXT);
    }

    public DummyMobileElement() {
        super();
        this.uuid = UUID.randomUUID().toString();
        this.id=uuid;
        this.elementParams.put(ElementParam.TEST_ID, uuid);
        this.parent= Environment.getDriverService().getDriver();
    }

    public DummyMobileElement(RemoteWebDriver driver) {
        this();
        this.parent = driver;
    }

    public DummyMobileElement(Map<ElementParam, Object> elementParams) {
        this();
        this.elementParams.putAll(elementParams);
    }

    public void putParams(Map<ElementParam, Object> elementParams) {
        this.elementParams.putAll(elementParams);
    }

    private String parseXpath(By by) {
        return by.toString().replace("By.xpath: ", "");
    }

    @Override
    public List findElements(By by) {
        return parent.findElements(by);
    }

    @Override
    public MobileElement findElement(By by) {
        return (MobileElement) parent.findElement(by);
    }

    @Override
    public boolean isDisplayed() {
        TestResults.getInstance().push("#isDisplayed",uuid);
        return (boolean) this.elementParams.get(ElementParam.VISIBLE);
    }

    @Override
    public Point getLocation() {
        return null;
    }

    @Override
    public Coordinates getCoordinates() {
        return null;
    }

    @Override
    public Dimension getSize() {
        return null;
    }

    @Override
    public Rectangle getRect() {
        TestResults.getInstance().push("#getRect",uuid);
        return new Rectangle(10, 10, 10, 10);
    }

    @Override
    public String getCssValue(String s) {
        return null;
    }

    @Override
    public <X> X getScreenshotAs(OutputType<X> outputType) throws WebDriverException {
        return null;
    }

    public String toString() {
        return uuid;
    }

    @Override
    public Point getCenter() {
        return super.getCenter();
    }

    @Override
    public List findElements(String by, String using) {
        return null;
    }

    @Override
    public List findElementsById(String id) {
        return super.findElementsById(id);
    }

    @Override
    public List findElementsByLinkText(String using) {
        return super.findElementsByLinkText(using);
    }

    @Override
    public List findElementsByPartialLinkText(String using) {
        return super.findElementsByPartialLinkText(using);
    }

    @Override
    public List findElementsByTagName(String using) {
        return super.findElementsByTagName(using);
    }

    @Override
    public List findElementsByName(String using) {
        return super.findElementsByName(using);
    }

    @Override
    public List findElementsByClassName(String using) {
        return super.findElementsByClassName(using);
    }

    @Override
    public List findElementsByCssSelector(String using) {
        return super.findElementsByCssSelector(using);
    }

    @Override
    public List findElementsByXPath(String using) {
        return super.findElementsByXPath(using);
    }

    @Override
    public List findElementsByAccessibilityId(String using) {
        return super.findElementsByAccessibilityId(using);
    }
}
