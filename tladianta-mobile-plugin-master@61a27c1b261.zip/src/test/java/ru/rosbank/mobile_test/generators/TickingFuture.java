package ru.rosbank.mobile_test.generators;

import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.remote.RemoteWebElement;
import ru.rosbank.at.exceptions.InnerException;
import ru.rosbank.mobile_test.driver.DummyMobileElement;

import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

/**
 * Класс реализующий ожидания элемента
 */
public class TickingFuture implements Future<RemoteWebElement> {
    /**
     * тип ожидания
     */
    public enum Type {
        VISIBLE, ENABLED, EXISTS
    }

    private DummyMobileElement element;
    private Supplier<RemoteWebElement> supplier;
    private int ticks;

    /**
     * конструктор ожидания
     * @param type тип ожидания
     * @param element элемент
     * @param ticks количество обращений для срабатывания ожидания
     * @param side тип перехода ожидаемого состояния
     */
    TickingFuture(Type type, RemoteWebElement element, int ticks, boolean side) {
        this.element = (DummyMobileElement) element;
        String attributeName;
        switch (type) {
            case ENABLED:
                attributeName = "enabled";
                break;
            case VISIBLE:
                attributeName = "visible";
                break;
            case EXISTS:
                attributeName = null;
                break;
            default:
                throw new InnerException("Unknown future type");
        }
        if (attributeName != null) {
            supplier = () -> {
                if (isDone()) {
                    this.element.setAttribute(attributeName, side);
                }
                return this.element;
            };
        } else {
            supplier = () -> isDone()
                    ? side ? element : null
                    : side ? null : element;
        }
        this.ticks = ticks;

    }

    /**
     * конструктор пустого ожидания
     */
    private TickingFuture() {
        supplier = () -> null;
    }

    /**
     * статический конструктор пустого ожидания
     * @return пустое ожидание
     */
    public static TickingFuture empty() {
        return new TickingFuture();
    }

    /**
     * принудительное извлечения элемента
     * @return элемент ожидания
     */
    public RemoteWebElement force() {
        return element;
    }

    /**
     * не используется
     */
    @Override
    public boolean cancel(boolean mayInterruptIfRunning) {
        return false;
    }

    /**
     * не используется
     */
    @Override
    public boolean isCancelled() {
        return false;
    }

    /**
     * проверка срабатывания события ожидания
     * @return сработало ли ожидание
     */
    @Override
    public boolean isDone() {
        if (ticks != 0) {
            ticks--;
            return false;
        }
        return true;
    }

    /**
     * извлечение элемента с учетом ожидания
     * @return элемент с учетом состояния
     */
    @Override
    public RemoteWebElement get() {
        return supplier.get();
    }

    /**
     * ожидание срабатывания события в течении заданного периода
     * @param timeout "таймаут" в секундах, который будет конвертирован в количество тиков (1 тик=1 секунде)
     * @param unit параметр времени
     * @return элемент с учетом состояния
     */
    @Override
    public RemoteWebElement get(long timeout, @NotNull TimeUnit unit) {
        long ticks = unit.toMillis(timeout) / 1000;
        for (long l = 0; l < ticks - 1; l++) {
            isDone();
        }
        return get();
    }
}