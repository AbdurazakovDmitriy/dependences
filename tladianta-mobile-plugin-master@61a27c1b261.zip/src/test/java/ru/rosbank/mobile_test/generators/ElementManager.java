package ru.rosbank.mobile_test.generators;

import org.aeonbits.owner.util.Collections;
import org.jetbrains.annotations.NotNull;
import ru.rosbank.at.exceptions.InnerException;
import ru.rosbank.at.virtual.AbstractElementManager;
import ru.rosbank.mobile_test.driver.DummyMobileElement;
import ru.rosbank.mobile_test.driver.ElementParam;
import ru.rosbank.mobile_test.driver.ElementProvider;
import ru.rosbank.mobile_test.utils.AdvancedXpathBuilder;

import java.util.*;
import java.util.function.BiFunction;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class ElementManager extends AbstractElementManager<ElementManager.Type, ElementManager.Condition> {
    public enum Condition {
        VISIBLE, ENABLED, INVISIBLE, DISABLED, SELECTED, NOT_SELECTED, IS_OPENED, IS_CLOSED, CHECKED, UNCHECKED,
        DISAPPEAR_FAST, APPEAR_FAST, DISABLE_FAST, ENABLE_FAST, VISIBLE_FAST, INVISIBLE_FAST
    }

    public enum Type {
        COMBO_BOX, TAB_CONTROL, NONE, LIST, RADIO_GROUP, CHECK_BOX, BUTTON, INPUT, PANEL, BLOCK;
    }

    private final static Pattern tagPattern = Pattern.compile(".*/([^\\[]*)(\\[.*\\])?");


    private static ElementManager instance = new ElementManager();

    public static ElementManager getInstance() {
        return instance;
    }

    private ElementManager() {
        super(Condition.VISIBLE, Condition.ENABLED);
    }

    public String register(String xpath, String text) {
        return register(xpath, text, Condition.ENABLED, Condition.VISIBLE);
    }

    @ElementRegister(type = Type.RADIO_GROUP)
    public void registerRadioGroup(String xpath, String text, Condition... conditions) {
        String id = register(xpath, text, conditions);
        if (Arrays.stream(conditions).noneMatch(Condition.NOT_SELECTED::equals)) {
            registerSubElement(id, "selected element", "radio-button", Condition.SELECTED, Condition.VISIBLE, Condition.ENABLED);
        }
        registerSubElement(id, "not selected element", "radio-button", Condition.NOT_SELECTED, Condition.VISIBLE, Condition.ENABLED);
        registerSubElement(id, "invisible not selected element", "radio-button", Condition.NOT_SELECTED, Condition.INVISIBLE, Condition.ENABLED);
        registerSubElement(id, "disabled not selected element", "radio-button", Condition.NOT_SELECTED, Condition.VISIBLE, Condition.DISABLED);

    }

    private void putParam(Map<ElementParam, Object> map, Condition positive, Condition negative, ElementParam paramName, Set<Condition> source) {
        if (source.contains(positive)) {
            map.put(paramName, true);
        }
        if (source.contains(negative)) {
            map.put(paramName, false);
        }
    }

    private TickingFuture buildFuture(DummyMobileElement element, Condition condition) {
        BiFunction<TickingFuture.Type, Boolean, TickingFuture> function = (type, side) ->
                new TickingFuture(type, element, 3, side);
        switch (condition) {
            case APPEAR_FAST:
                return function.apply(TickingFuture.Type.EXISTS, true);
            case DISAPPEAR_FAST:
                return function.apply(TickingFuture.Type.EXISTS, false);
            case VISIBLE_FAST:
                return function.apply(TickingFuture.Type.VISIBLE, true);
            case INVISIBLE_FAST:
                return function.apply(TickingFuture.Type.VISIBLE, false);
            case ENABLE_FAST:
                return function.apply(TickingFuture.Type.ENABLED, true);
            case DISABLE_FAST:
                return function.apply(TickingFuture.Type.ENABLED, false);
        }
        throw new InnerException("Unknown fast type");
    }

    private String buildElement(Map<ElementParam, Object> map, Set<Condition> source, String xpath) {
        source = source.stream().filter(o -> o.name().toLowerCase().contains("fast")).collect(Collectors.toSet());
        if (source.size() > 1) {
            throw new InnerException("Невозможно использование более одного условия связанного со временем");
        }
        Matcher matcher = tagPattern.matcher(xpath);
        if (matcher.find()) {
            map.put(ElementParam.TAG_NAME, matcher.group(1));
            map.put(ElementParam.MOBILE_CLASS, matcher.group(1));
        }
        DummyMobileElement element = new DummyMobileElement(map);

        Optional<Condition> condition = source.stream().findFirst();
        TickingFuture future = condition.isPresent()
                ? buildFuture(element, condition.get())
                : new TickingFuture(TickingFuture.Type.EXISTS, element, 0, true);
        ElementProvider.getInstance().push(xpath, future);
        return element.getAttribute("test-id");
    }


    public String register(String xpath, String text, Condition... conditions) {
        Map<ElementParam, Object> map = new HashMap<>();
        Set<Condition> setConditions = Collections.set(conditions);
        putParam(map, Condition.VISIBLE, Condition.INVISIBLE, ElementParam.VISIBLE, setConditions);
        putParam(map, Condition.ENABLED, Condition.DISABLED, ElementParam.ENABLED, setConditions);
        putParam(map, Condition.SELECTED, Condition.NOT_SELECTED, ElementParam.SELECTED, setConditions);
        putParam(map, Condition.IS_OPENED, Condition.IS_CLOSED, ElementParam.IS_OPENED, setConditions);
        putParam(map, Condition.CHECKED, Condition.UNCHECKED, ElementParam.CHECKED, setConditions);
        map.put(ElementParam.TEXT, text);
        return buildElement(map, setConditions, xpath);
    }

    @Override
    protected String autoTextForType(Type type) {
        return type == Type.NONE ? "" : type.name().toLowerCase().replaceAll("_", "");
    }

    @Override
    protected String autoLocatorForType(Type type) {
        if (type == Type.NONE) {
            throw new InnerException("Неизвестный тип элемента");
        }
        return "//" + type.name().toLowerCase().replaceAll("_", "-");
    }


    private String registerSubElement(String id, String text, String tagName, Condition... conditions) {
        String baseXpath = new AdvancedXpathBuilder()
                .withSearchProperty("id", id)
                .withTagName(tagName, true)
                .build();
        return conditions.length == 0
                ? register(baseXpath, text)
                : register(baseXpath, text, conditions);
    }

    private String registerComplexElement(String id, String text, String tagName, String... subNames) {
        String complexId = registerSubElement(id, text, tagName);
        if (subNames.length != 0) {
            String baseXpath = new AdvancedXpathBuilder()
                    .withSearchProperty("id", complexId)
                    .withSearchProperty("name", text)
                    .withTagName(tagName, true)
                    .withTagName(tagName + "-sub", false)
                    .build();
            for (String subName : subNames) {
                Matcher matcher = Pattern.compile("([a-zA-Z\\-]+):(.+)").matcher(subName);
                if (matcher.find()) {
                    register(String.format("%s[@name ='%s']", baseXpath, matcher.group(1)), matcher.group(2));
                } else {
                    register(String.format("%s[@name ='%s']", baseXpath, subName), subName);
                }
            }
        }
        return complexId;
    }

    @ElementRegister(type = Type.PANEL)
    private void registerPanel(String xpath, String text, Condition... conditions) {
        String id = register(xpath, text, conditions);
        registerComplexElement(id, "# body", "panel-body", "state-box", "in-body-element");
        registerComplexElement(id, "# header", "panel-header", "state-box", "in-header-element");
    }

    @ElementRegister(type = Type.TAB_CONTROL, conditions = Condition.IS_OPENED)
    public void registerTabControl(String xpath, String text, Condition... conditions) {
        String id = register(xpath, text, conditions);
        registerComplexElement(id, "option 1", "select-option", "j-box:in-option-1");
        registerComplexElement(id, "option 2", "select-option", "j-box:in-option-2");
        registerComplexElement(id, "option 3", "select-option", "j-box:in-option-3");
        registerSubElement(id, "body", "select-block");
        registerSubElement(id, "->", "select-button");
    }

    @ElementRegister(type = Type.COMBO_BOX, conditions = {Condition.IS_OPENED,Condition.NOT_SELECTED})
    public void registerSelect(String xpath, String text, Condition... conditions) {
        String id = register(xpath, text, conditions);
        register("./*", "option 1", conditions);
        register("./*", "option 2", conditions);
        if (Arrays.asList(conditions).contains(Condition.SELECTED))
            register("./*", "option selected", Condition.SELECTED);
        register("./*", "option visible disabled", Condition.VISIBLE, Condition.DISABLED);
        register("./*", "option invisible enabled", Condition.INVISIBLE, Condition.ENABLED);
        register("./*", "option invisible disabled", Condition.INVISIBLE, Condition.DISABLED);
    }

    @ElementRegister(type = Type.CHECK_BOX, conditions = Condition.CHECKED)
    public void registerCheckBox(String xpath, String text, Condition... conditions) {
        register(xpath, text, conditions);
    }

    @ElementRegister(type = Type.LIST)
    public void registerElementList(String xpath, @NotNull String elementTexts, Condition... conditions) {
        String[] texts = elementTexts.split(",");
        Arrays.stream(texts).forEach(o -> register(xpath, o, conditions));
    }

    @ElementRegister(type = Type.BLOCK)
    public void registerBlock(String xpath, String text, Condition... conditions) {
        register(xpath, text, conditions);
        register("./div/button", "Кнопка в блоке");
        register("./div/input", "Поле в блоке");
    }
}
