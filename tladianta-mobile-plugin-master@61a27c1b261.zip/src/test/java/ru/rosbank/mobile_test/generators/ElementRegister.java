package ru.rosbank.mobile_test.generators;

import ru.rosbank.at.annotations.ElementRegisterDecl;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@ElementRegisterDecl
public @interface ElementRegister {
    ElementManager.Condition[] conditions() default {};

    ElementManager.Type type();

}
