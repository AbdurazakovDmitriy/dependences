package ru.rosbank.mobile_test.utils;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

public class AdvancedXpathBuilder {
    private final Map<String, String> advancedProperties = new HashMap<>();
    private final StringBuilder builder = new StringBuilder();
    private boolean attributesOpened;

    @Contract(pure = true)
    public AdvancedXpathBuilder() {
        attributesOpened = false;
    }

    @Contract("_,_->this")
    public AdvancedXpathBuilder withSearchProperty(@NotNull String propertyName, @NotNull String value) {
        advancedProperties.put(propertyName, value);
        return this;
    }

    public AdvancedXpathBuilder withTagName(String tagName, boolean deep) {
        if (attributesOpened) {
            attributesOpened = false;
            builder.append(']');
        }
        if (deep) {
            builder.append("/");
        }
        builder.append("/")
                .append(tagName);
        return this;
    }

    public AdvancedXpathBuilder withAttributeValue(String attributeName, String value) {
        if (!attributesOpened) {
            attributesOpened = true;
            builder.append('[');
        } else {
            builder.append(" and ");
        }
        builder.append('@').append(attributeName)
                .append(" ='")
                .append(value)
                .append("'");
        return this;
    }

    public AdvancedXpathBuilder withValue(String value) {
        if (!attributesOpened) {
            attributesOpened = true;
            builder.append('[');
        } else {
            builder.append(" and ");
        }
        builder.append("text() ='")
                .append(value)
                .append("'");
        return this;
    }

    public AdvancedXpathBuilder withContains(String value) {
        if (!attributesOpened) {
            attributesOpened = true;
            builder.append('[');
        } else {
            builder.append(" and ");
        }
        builder.append("contains(text(), '")
                .append(value)
                .append("')");
        return this;
    }

    public AdvancedXpathBuilder withContains(String attributeName, String value) {
        if (!attributesOpened) {
            attributesOpened = true;
            builder.append('[');
        } else {
            builder.append(" and ");
        }
        builder.append("contains(@").append(attributeName)
                .append(", '")
                .append(value)
                .append("')");
        return this;
    }

    public String build(){
        if (attributesOpened) {
            attributesOpened = false;
            builder.append(']');
        }
        if (advancedProperties.size()!=0){
            builder.insert(0,'}');
            boolean isSequence=false;
            for (Map.Entry<String,String> entry:advancedProperties.entrySet()){
                if (isSequence){
                    builder.insert(0,", ");
                }
                builder.insert(0,"'")
                        .insert(0,entry.getValue())
                        .insert(0,"'")
                        .insert(0,'=')
                        .insert(0,entry.getKey());
                isSequence=true;
            }
            builder.insert(0,"${");
        }
        return builder.toString();
    }
}
