package ru.rosbank.mobile_test.utils;

public class XpathConstants {
    public final static String BUTTON_LOCATOR="//button";
    public final static String INPUT_LOCATOR="//input";
}
