package ru.rosbank.mobile_test.impls;

import ru.rosbank.automation.environment.IWrapElement;

public interface IButton<T> extends IWrapElement<T> {
    void click();
}
