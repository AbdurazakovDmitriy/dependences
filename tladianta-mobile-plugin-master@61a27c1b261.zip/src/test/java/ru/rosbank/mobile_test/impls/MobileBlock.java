package ru.rosbank.mobile_test.impls;

import io.appium.java_client.MobileElement;
import org.openqa.selenium.support.FindBy;
import ru.rosbank.at.exceptions.InnerAssertionException;
import ru.rosbank.at.results.TestResults;
import ru.rosbank.mobile_plugin.elements.AbstractMobileBlock;
import ru.sbtqa.tag.pagefactory.annotations.ActionTitle;
import ru.sbtqa.tag.pagefactory.annotations.ElementTitle;

public class MobileBlock extends AbstractMobileBlock {
    private static final String inBlockPath="./div/";
    @ElementTitle("Кнопка в блоке")
    @FindBy(xpath = inBlockPath+"button")
    ButtonImpl button;
    @ElementTitle("Поле в блоке")
    @FindBy(xpath = inBlockPath+"input")
    InputImpl input;

    public MobileBlock(MobileElement element) {
        super(element);
    }
    @ActionTitle("Действие")
    public void actionInBlock(){
        TestResults.getInstance().push("action in block",this.getAttribute("test-id"));
    }

    @ActionTitle("Действие с параметром")
    public void actionInBlock(String param){
        TestResults.getInstance().push(param,this.getAttribute("test-id"));
        TestResults.getInstance().push("action in block",this.getAttribute("test-id"));
    }
    @ActionTitle("Действие с ошибкой")
    public void failActionInBlock(){
        TestResults.getInstance().push("exception in block",this.getAttribute("test-id"));
        throw new InnerAssertionException();
    }
}
