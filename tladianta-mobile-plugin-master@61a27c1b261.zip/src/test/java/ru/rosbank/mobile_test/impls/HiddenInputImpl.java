package ru.rosbank.mobile_test.impls;

import io.appium.java_client.MobileElement;
import ru.rosbank.mobile_plugin.elements.base.Input;

public class HiddenInputImpl extends Input implements ITestResult {
    
    public HiddenInputImpl(MobileElement element) {
        super(element);
    }

    @Override
    public void clear() {
        pushResult("clear");
        super.clear();
    }

    @Override
    public String getText() {
        pushResult("getText");
        return super.getText();
    }

    @Override
    public void setText(String text) {
        pushResult("setText", text);
        super.setText(text);
    }
}
