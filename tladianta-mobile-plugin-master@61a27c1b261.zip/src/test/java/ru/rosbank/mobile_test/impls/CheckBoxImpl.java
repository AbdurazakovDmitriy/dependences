package ru.rosbank.mobile_test.impls;

import io.appium.java_client.MobileElement;
import ru.rosbank.mobile_plugin.elements.base.CheckBox;

public class CheckBoxImpl extends CheckBox implements ITestResult {
    public CheckBoxImpl(MobileElement element) {
        super(element);
    }

    @Override
    public void check() {
        pushResult("check");
        super.check();
    }

    @Override
    public void uncheck() {
        pushResult("uncheck");
        super.uncheck();
    }

    @Override
    public void check(boolean targetState) {
        pushResult("check",targetState);
        super.check(targetState);
    }

    @Override
    public boolean getState() {
        pushResult("getState");
        return super.getState();
    }
}
