package ru.rosbank.mobile_test.impls;

import io.appium.java_client.MobileElement;
import ru.rosbank.mobile_plugin.elements.base.Select;

public class SelectImpl extends Select implements ITestResult{

    public SelectImpl(MobileElement element) {
        super(element);
    }

    @Override
    public void selectByValue(String value) {
        pushResult("selectByValue",value);
        super.selectByValue(value);
    }
}
