package ru.rosbank.mobile_test.impls;

import io.appium.java_client.MobileElement;
import ru.rosbank.mobile_plugin.elements.core.text.IHaveMask;

public class MaskedInput extends InputImpl implements IHaveMask {
    public MaskedInput(MobileElement element) {
        super(element);
    }

    @Override
    public void setText(String text){
        super.setText(getMask().convert(text));
    }

    @Override
    public String getText(){
        return getMask().restore(super.getText());
    }
}
