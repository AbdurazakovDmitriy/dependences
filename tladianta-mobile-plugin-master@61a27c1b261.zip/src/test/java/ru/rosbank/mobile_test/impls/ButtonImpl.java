package ru.rosbank.mobile_test.impls;

import io.appium.java_client.MobileElement;
import ru.rosbank.mobile_plugin.elements.base.Button;

public class ButtonImpl extends Button implements ITestResult{
    public ButtonImpl(MobileElement element) {
        super(element);
    }

    @Override
    public void click() {
        pushResult("click");
        super.click();
    }
}
