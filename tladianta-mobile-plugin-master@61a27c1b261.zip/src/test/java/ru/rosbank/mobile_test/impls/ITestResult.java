package ru.rosbank.mobile_test.impls;

import org.openqa.selenium.WebElement;
import ru.rosbank.at.results.TestResults;

public interface ITestResult {

    WebElement getWrappedElement();

    default void pushResult(String message) {
        TestResults.getInstance().push(message, getTestId());
    }

    default void pushResult(String message, Object arg) {
        TestResults.getInstance().push(String.format(":%s", message),arg);
        TestResults.getInstance().push(message, getTestId());
    }

    default String getTestId() {
        return getWrappedElement().getAttribute("test-id");
    }
}
