package ru.rosbank.mobile_plugin.environment;


import org.junit.Test;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.at.annotations.ITestInstance;
import ru.rosbank.at.helpers.FastUnit;

@ITestClass(Mask.class)
public class MaskTest implements FastUnit {

    Object[] args={"_:2_:2_:4","_:2/_:2/_:4"};

    @ITestInstance(argSource = "args")
    @Test
    @IExpectTestResult(errDesc = "Неверно сконвертировано значение", value = FAST_RESULT, expected = "12/10/2012")
    public void convert() {
        runTest("convert","12102012");
    }

    @ITestInstance(argSource = "args")
    @Test
    @IExpectTestResult(errDesc = "Неверно сконвертировано значение", value = FAST_RESULT, expected = "12102012")
    public void restore() {
        runTest("restore","12/10/2012");
    }
}