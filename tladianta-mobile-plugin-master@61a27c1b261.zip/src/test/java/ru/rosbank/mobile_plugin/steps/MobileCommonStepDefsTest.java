package ru.rosbank.mobile_plugin.steps;

import io.cucumber.datatable.DataTable;
import org.junit.Test;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.at.solutions.Cucumber;
import ru.rosbank.mobile_plugin.stepdefs.MobileCommonStepDefs;
import ru.rosbank.mobile_test.environment.*;
import ru.rosbank.mobile_test.environment.class_generate.IInitPages;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.environment.generate.IStoreValue;
import ru.rosbank.mobile_test.generators.ElementManager;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;
import ru.rosbank.mobile_test.utils.XpathConstants;

@IInitPages
@ITestClass(MobileCommonStepDefs.class)
public class MobileCommonStepDefsTest extends MobileUnitTest {
    /**
     * {@link MobileCommonStepDefs#elementWithTextExists(String, String)}
     */
    @IGenerateElement(type = ElementManager.Type.BUTTON)
    @Test
    @IExpectTestResult(errDesc = "Не был вызван метод получения размеров элемента", value = "#isDisplayed", expected = XpathConstants.BUTTON_LOCATOR, convertedBy = Converters.XpathToIdConverter.class)
    public void elementWithTextExistsTestPositive() {
        runTest("elementWithTextExists", "Кнопка", "button");
    }

    /**
     * {@link MobileCommonStepDefs#elementWithTextExists(String, String)}
     */
    @IGenerateElement(type = ElementManager.Type.BUTTON)
    @Test(expected = AssertionError.class)
    @IExpectTestResult(errDesc = "Не был вызван метод получения размеров элемента", value = "#isDisplayed", force = true, expected = XpathConstants.BUTTON_LOCATOR, convertedBy = Converters.XpathToIdConverter.class)
    public void elementWithTextExistsTestNegative() {
        runTest("elementWithTextExists", "Кнопка", "not button");
    }

    /**
     * {@link MobileCommonStepDefs#checkElementsWithText(DataTable)}
     */
    @IGenerateElement(type = ElementManager.Type.BUTTON)
    @Test
    public void checkElementsWithTextPositiveTest() {
        runTest("checkElementsWithText", new Cucumber.DataTableBuilder().withRow("Кнопка", "button").build());
    }

    /**
     * {@link MobileCommonStepDefs#checkElementsWithText(DataTable)}
     */
    @IGenerateElement(type = ElementManager.Type.BUTTON, conditions = ElementManager.Condition.APPEAR_FAST)
    @Test(expected = AssertionError.class)
    public void checkElementsWithTextNegativeTest() {
        runTest("checkElementsWithText", new Cucumber.DataTableBuilder().withRow("Кнопка", "not button").build());
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IStoreValue(key = "some-key", value = "some-value")
    @Test
    @IExpectTestResult(errDesc = "Метод sendKeys не был вызван у ожидаемого элемента", value = "#sendKeys", expected = XpathConstants.INPUT_LOCATOR, convertedBy = Converters.XpathToIdConverter.class)
    @IExpectTestResult(errDesc = "Метод sendKeys был вызван с некорректным текстом", value = "#sendKeys/value/", expected = "some-value")
    public void sendTextFromStashToFieldTest() {
        runTest("sendTextFromStashToField", "Поле", "some-key");
    }
}