package ru.rosbank.mobile_plugin.steps;

import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.IProvideInstance;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.at.exceptions.InnerAssertionException;
import ru.rosbank.automation.configuration.ApplicationContext;
import ru.rosbank.automation.configuration.ApplicationManager;
import ru.rosbank.automation.exceptions.ElementSearchError;
import ru.rosbank.mobile_test.environment.Converters;
import ru.rosbank.mobile_test.environment.class_generate.IInitPages;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.generators.ElementManager;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;
import ru.sbtqa.tag.pagefactory.exceptions.FactoryRuntimeException;
import ru.sbtqa.tag.qautils.errors.AutotestError;

@IInitPages
@ITestClass(MobileCoreSteps.class)
public class MobileCoreStepsTest extends MobileUnitTest {

    @IProvideInstance
    public MobileCoreSteps getInstance() {
        return (MobileCoreSteps) ApplicationContext.getStepsImpl("CoreStepsImpl");
    }


    @IGenerateElement(type = ElementManager.Type.BLOCK)
    @IExpectTestResult(errDesc = "не был вызван action Действие", value = "action in block", expected = "//block",convertedBy = Converters.XpathToIdConverter.class)
    @IExpectTestResult(errDesc = "не был вызван action Действие", value = "Параметр", expected = "//block",convertedBy = Converters.XpathToIdConverter.class)
    @Test
    public void actionInBlockVarArgTest() {
        runTest("actionInBlock", "Блок", "Действие с параметром", new Object[]{"Параметр"});
    }

    @IGenerateElement(type = ElementManager.Type.BLOCK)
    @IExpectTestResult(errDesc = "не был вызван action Действие", value = "action in block", expected = "//block",convertedBy = Converters.XpathToIdConverter.class)
    @Test
    public void actionInBlockTestPositive() {
        runTest("actionInBlock", "Блок", "Действие");
    }

    @IGenerateElement(type = ElementManager.Type.BLOCK)
    @Test(expected = ElementSearchError.class)
    public void actionInBlockTestNegativeBadLocator() {
        runTest("actionInBlock", "Другой блок", "Нажимает кнопку");
    }

    @IGenerateElement(type = ElementManager.Type.BLOCK)
    @Test(expected = ElementSearchError.class)
    public void actionInBlockTestNegativeBadMethod() {
        runTest("actionInBlock", "Другой блок", "Несуществующее действие");
    }


    @IGenerateElement(type = ElementManager.Type.BLOCK)
    @Test(expected = FactoryRuntimeException.class)
    @IExpectTestResult(errDesc = "Не был вызван вызван ожидаемый action", value = "exception in block", expected = "//block", convertedBy = Converters.XpathToIdConverter.class, force = true)
    public void actionInBlockTestNegative() {
        runTest("actionInBlock", "Блок", "Действие с ошибкой");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Текст не был введен", value = "setText", expected = "//input", convertedBy = Converters.XpathToIdConverter.class)
    @IExpectTestResult(errDesc = "Текст не был введен", value = ":setText", expected = "Текст")
    @Test
    public void fill() {
        runTest("fill", "Поле", "Текст");
    }

    @IGenerateElement(type = ElementManager.Type.BUTTON)
    @IExpectTestResult(errDesc = "Клик не был выполнен", value = "click", expected = "//button", convertedBy = Converters.XpathToIdConverter.class)
    @Test
    public void click() {
        runTest("click", "Кнопка");
    }

    @IGenerateElement(type = ElementManager.Type.COMBO_BOX)
    @IExpectTestResult(errDesc = "Не был вызван метод элемента", value = "selectByValue", expected = "//combo-box", convertedBy = Converters.XpathToIdConverter.class)
    @IExpectTestResult(errDesc = "Методу были выданы неверные параметры\"", value = ":selectByValue", expected = "option 2")
    @Test
    public void select() {
        runTest("select","Табулятор","option 2");
    }

    @IGenerateElement(type = ElementManager.Type.COMBO_BOX)
    @IExpectTestResult(errDesc = "Не был вызван метод элемента", value = "selectByValue", force = true, expected = "//combo-box", convertedBy = Converters.XpathToIdConverter.class)
    @IExpectTestResult(errDesc = "Методу были выданы неверные параметры", value = ":selectByValue", force = true, expected = "option 3")
    @Test(expected = NoSuchElementException.class)
    public void selectNegative() {
        runTest("select","Табулятор","option 3");
    }

    @IGenerateElement(type = ElementManager.Type.CHECK_BOX)
    @IExpectTestResult(errDesc = "Чекбокс не был переключен", value = "check", expected = "//check-box", convertedBy = Converters.XpathToIdConverter.class)
    @Test
    public void setCheckBox() {
        runTest("setCheckBox", "Переключатель");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Значение текста не было извлечено", value = "getText", expected = "//input", convertedBy = Converters.XpathToIdConverter.class)
    @Test
    public void checkValueIsEqual() {
        runTest("checkValueIsEqual", "Поле", "input");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Значение текста не было извлечено", value = "getText", expected = "//input", convertedBy = Converters.XpathToIdConverter.class, force = true)
    @Test(expected = AutotestError.class)
    public void checkValueIsEqualNegative() {
        runTest("checkValueIsEqual", "Поле", "inpu");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Значение текста не было извлечено", value = "getText", expected = "//input", convertedBy = Converters.XpathToIdConverter.class)
    @Test
    public void checkValueContains() {
        runTest("checkValueContains", "Поле", "inpu");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Значение текста не было извлечено", value = "getText", expected = "//input", convertedBy = Converters.XpathToIdConverter.class, force = true)
    @Test(expected = AutotestError.class)
    public void checkValueContainsNegative() {
        runTest("checkValueContains", "Поле", "inputs");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Значение текста не было извлечено", value = "getText", expected = "//input", convertedBy = Converters.XpathToIdConverter.class, force = true)
    @Test
    public void checkValueNotContains() {
        runTest("checkValueNotContains", "Поле", "inputs");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Значение текста не было извлечено", value = "getText", expected = "//input", convertedBy = Converters.XpathToIdConverter.class)
    @Test
    public void checkValueIsNotEqual() {
        runTest("checkValueContains", "Поле", "inpu");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Значение текста не было извлечено", value = "getText", expected = "//input", convertedBy = Converters.XpathToIdConverter.class)
    @Test
    public void checkNotEmpty() {
        runTest("checkNotEmpty", "Поле");
    }

    @IGenerateElement(locator = "//input")
    @IExpectTestResult(errDesc = "Значение текста не было извлечено", value = "getText", expected = "//input", convertedBy = Converters.XpathToIdConverter.class)
    @Test
    public void checkEmpty() {
        runTest("checkEmpty", "Поле");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT, conditions = ElementManager.Condition.VISIBLE_FAST)
    @Test
    public void appearElement() {
        runTest("appearElement", "Поле");
    }

    @Test(expected = TimeoutException.class)
    public void appearElementNegative() {
        runTest("appearElement", "Поле");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT, conditions = ElementManager.Condition.INVISIBLE_FAST)
    @Test
    public void waitInvisibility() {
        runTest("waitInvisibility", "Поле");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @Test(expected = TimeoutException.class)
    public void waitInvisibilityNegative() {
        runTest("waitInvisibility", "Поле");
    }

    @IGenerateElement(type = ElementManager.Type.BUTTON, conditions = ElementManager.Condition.ENABLE_FAST)
    @Test
    public void waitClickability() {
        runTest("waitClickability", "Кнопка");
    }

    @IGenerateElement(type = ElementManager.Type.BUTTON, conditions = ElementManager.Condition.DISABLED)
    @Test(expected = TimeoutException.class)
    public void waitClickabilityNegative() {
        runTest("waitClickability", "Кнопка");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Поле не было очищено", value = "#clear", expected = "//input", convertedBy = Converters.XpathToIdConverter.class)
    @Test
    public void clearField() {
        runTest("clearField", "Поле");
    }


    @Test
    @Ignore("can not be tested yet")
    public void waitChangeAttribute() {
    }

    @Test
    @Ignore("can not be tested yet")
    public void testWaitChangeAttribute() {
    }

    @Test
    @Ignore("can not be tested yet")
    public void waitAttributeContains() {
    }

    @Test
    @Ignore("can not be tested yet")
    public void testWaitAttributeContains() {
    }

    @Test
    @Ignore("can not be tested yet")
    public void waitElementContainsText() {
    }

}
