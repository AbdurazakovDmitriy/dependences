package ru.rosbank.mobile_plugin.steps;

import org.junit.Test;
import org.openqa.selenium.NoSuchElementException;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.mobile_plugin.stepdefs.MobileStepDefs;
import ru.rosbank.mobile_test.environment.Converters;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.environment.class_generate.IInitPages;
import ru.rosbank.mobile_test.generators.ElementManager;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;
import ru.rosbank.mobile_test.utils.XpathConstants;
@IInitPages
@ITestClass(MobileStepDefs.class)
public class MobileStepDefsTest extends MobileUnitTest {

    /**
     * {@link MobileStepDefs#pressOn}
     */
    @IGenerateElement(type = ElementManager.Type.BUTTON)
    @Test
    @IExpectTestResult(errDesc = "Не был вызван метод получения размеров элемента", value = "#getRect", expected = XpathConstants.BUTTON_LOCATOR, convertedBy = Converters.XpathToIdConverter.class)
    public void pressOnTest(){
        runTest("pressOn", "Кнопка");
    }


    /**
     * {@link MobileStepDefs#pressOn}
     */
    @Test(expected = NoSuchElementException.class)
    public void pressOnNegativeTest() {
        runTest("pressOn", "Кнопка");
    }

    @IGenerateElement(type = ElementManager.Type.BUTTON)
    @Test
    public void tapOnTestPositive() {
        runTest("tapOn","Кнопка");
    }

    @Test(expected = NoSuchElementException.class)
    public void tapOnTestNegative() {
        runTest("tapOn","Кнопка");
    }
}
