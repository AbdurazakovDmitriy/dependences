package ru.rosbank.mobile_plugin.steps;

import org.junit.Test;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.at.helpers.ReflectionBuilder;
import ru.rosbank.automation.configuration.ApplicationContext;
import ru.rosbank.automation.configuration.ConfigurationManager;
import ru.rosbank.automation.utils.FieldValueResetter;
import ru.rosbank.mobile_plugin.actions.MobilePageActions;
import ru.rosbank.mobile_plugin.checks.MobilePageChecks;
import ru.rosbank.mobile_plugin.driver.AndroidDriverManager;
import ru.rosbank.mobile_plugin.driver.IOSDriverManager;
import ru.rosbank.mobile_plugin.driver.MobileDriverService;
import ru.rosbank.mobile_plugin.find.MobileFindUtils;
import ru.rosbank.mobile_plugin.helper.MobileHelper;
import ru.rosbank.mobile_plugin.interception.MobileDecorator;
import ru.rosbank.mobile_plugin.properties.MobileConfiguration;
import ru.rosbank.mobile_plugin.reflection.MobileReflection;
import ru.rosbank.mobile_plugin.screen.MobileVideoRecorder;
import ru.rosbank.mobile_plugin.screen.MobileVideoUtils;
import ru.rosbank.mobile_plugin.stepdefs.MobileSetupStepDefs;
import ru.rosbank.mobile_plugin.utils.MobileAlert;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;
import ru.sbtqa.tag.pagefactory.environment.Environment;

import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

import static junit.framework.TestCase.assertTrue;

@ITestClass(MobileSetupSteps.class)
public class MobileSetupStepsTest extends MobileUnitTest {

    @Test
    public void registerClassForResetTest() {
        runTest("registerClassForReset");
        Supplier<MobileConfiguration> valueSupplier = MobileConfiguration::create;
        Set<FieldValueResetter> classesToReset = (Set) ReflectionBuilder.join(ConfigurationManager.class)
                .withField("classesToReset").get();
        boolean checked;
        checked = classesToReset.stream().anyMatch(o -> o.equals(new FieldValueResetter(AndroidDriverManager.class, ConfigurationManager.PROPERTIES, valueSupplier)));
        checked &= classesToReset.stream().anyMatch(o -> o.equals(new FieldValueResetter(IOSDriverManager.class, ConfigurationManager.PROPERTIES, valueSupplier)));
        checked &= classesToReset.stream().anyMatch(o -> o.equals(new FieldValueResetter(MobileDriverService.class, ConfigurationManager.PROPERTIES, valueSupplier)));
        checked &= classesToReset.stream().anyMatch(o -> o.equals(new FieldValueResetter(MobileHelper.class, ConfigurationManager.PROPERTIES, valueSupplier)));
        checked &= classesToReset.stream().anyMatch(o -> o.equals(new FieldValueResetter(MobileDecorator.class, ConfigurationManager.PROPERTIES, valueSupplier)));
        checked &= classesToReset.stream().anyMatch(o -> o.equals(new FieldValueResetter(MobileVideoRecorder.class, ConfigurationManager.PROPERTIES, valueSupplier)));
        checked &= classesToReset.stream().anyMatch(o -> o.equals(new FieldValueResetter(MobileVideoUtils.class, ConfigurationManager.PROPERTIES, valueSupplier)));
        checked &= classesToReset.stream().anyMatch(o -> o.equals(new FieldValueResetter(MobileSetupStepDefs.class, ConfigurationManager.PROPERTIES, valueSupplier)));
        checked &= classesToReset.stream().anyMatch(o -> o.equals(new FieldValueResetter(MobileCommonSteps.class, ConfigurationManager.PROPERTIES, valueSupplier)));
        checked &= classesToReset.stream().anyMatch(o -> o.equals(new FieldValueResetter(MobileCoreSteps.class, ConfigurationManager.PROPERTIES, valueSupplier)));
        checked &= classesToReset.stream().anyMatch(o -> o.equals(new FieldValueResetter(MobileAlert.class, ConfigurationManager.PROPERTIES, valueSupplier)));
        assertTrue("метод registerClassForReset не отработал", checked);
    }

    @Test
    public void initEnvironmentTest() {
        runTest("initEnvironment");
        boolean checked = Environment.getReflection().getClass().isAssignableFrom(MobileReflection.class);
        checked &= Environment.getFindUtils().getClass().isAssignableFrom(MobileFindUtils.class);
        checked &= Environment.getFindUtils().getClass().isAssignableFrom(MobileFindUtils.class);
        checked &= Environment.getPageActions().getClass().isAssignableFrom(MobilePageActions.class);
        checked &= Environment.getPageChecks().getClass().isAssignableFrom(MobilePageChecks.class);
        assertTrue("метод initEnvironment не отработал", checked);
    }

    @Test
    public void uploadStepsTest() {
        runTest("uploadSteps");
        Map<String, Object> stepsImpl = ((ThreadLocal<Map<String, Object>>) ReflectionBuilder
                .join(ApplicationContext.class)
                .withField("stepsImpl")
                .get())
                .get();
        boolean checked = Objects.equals(stepsImpl.get("MobileSteps"), MobileSteps.getInstance());
        checked &= Objects.equals(stepsImpl.get("CoreStepsImpl"), MobileCoreSteps.getInstance());
        checked &= Objects.equals(stepsImpl.get("CommonSteps"), MobileCommonSteps.getInstance());
        assertTrue("метод uploadSteps не отработал", checked);
    }
}
