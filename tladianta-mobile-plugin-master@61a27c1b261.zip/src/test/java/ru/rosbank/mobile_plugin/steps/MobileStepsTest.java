package ru.rosbank.mobile_plugin.steps;

import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.IProvideInstance;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.at.exceptions.InnerAssertionException;
import ru.rosbank.mobile_test.environment.Converters;
import ru.rosbank.mobile_test.environment.class_generate.IInitPages;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.generators.ElementManager;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;
import ru.sbtqa.tag.qautils.errors.AutotestError;

@IInitPages
@ITestClass(MobileSteps.class)
public class MobileStepsTest extends MobileUnitTest {
    @Test
    @Ignore("can not be tested yet")
    public void swipeToTextByDirection() {
    }

    @Test
    @Ignore("can not be tested yet")
    public void swipeToTextByMatch() {
    }

    @Test
    @Ignore("can not be tested yet")
    public void press() {
    }

    @Test
    @Ignore("can not be tested yet")
    public void tap() {
    }

    @Test
    @Ignore("can not be tested yet")
    public void pressKey() {
    }
}