package ru.rosbank.mobile_plugin.checks;

import org.jetbrains.annotations.NotNull;
import org.junit.Test;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.IProcessPhase;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.at.data.TestData;
import ru.rosbank.at.helpers.TypeConverters;
import ru.rosbank.mobile_test.driver.ElementProvider;
import ru.rosbank.mobile_test.environment.class_generate.IInitPages;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.generators.ElementManager;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;
import ru.sbtqa.tag.qautils.strategies.MatchStrategy;

import java.lang.reflect.Method;

@IInitPages
@ITestClass(value = MobilePageChecks.class, phases = {"package-generate", "class-generate", "generate", "ref", "test", "assert"})
public class MobilePageChecksTest extends MobileUnitTest {

    @IProcessPhase("ref")
    public Throwable refer(@NotNull Method method) {
        TestData.getInstance().push("element", ElementProvider.getInstance().provide("//input").force());
        return null;
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @Test
    @IExpectTestResult(errDesc = "метод вернул неожиданный результат", value = FAST_RESULT, expected = "true", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void checkEqualityContainsTestPositive() {
        runTest("checkEquality", TestData.ref("element"), "input", MatchStrategy.CONTAINS);
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @Test
    @IExpectTestResult(errDesc = "метод вернул неожиданный результат", value = FAST_RESULT, expected = "false", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void checkEqualityContainsTestNegative() {
        runTest("checkEquality", TestData.ref("element"), "text actual", MatchStrategy.CONTAINS);
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @Test
    @IExpectTestResult(errDesc = "метод вернул неожиданный результат", value = FAST_RESULT, expected = "true", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void checkEqualityTestPositive() {
        runTest("checkEquality", TestData.ref("element"), "input");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @Test
    @IExpectTestResult(errDesc = "метод вернул неожиданный результат", value = FAST_RESULT, expected = "false", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void checkEqualityTestNegative() {
        runTest("checkEquality", TestData.ref("element"), "text");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @Test
    @IExpectTestResult(errDesc = "метод вернул неожиданный результат", value = FAST_RESULT, expected = "input")
    public void getElementValueTest() {
        runTest("getElementValue", TestData.ref("element"));
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @Test
    @IExpectTestResult(errDesc = "метод вернул неожиданный результат", value = FAST_RESULT, expected = "false", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void checkEmptinessTestPositive() {
        runTest("checkEmptiness", TestData.ref("element"));
    }

    @IGenerateElement(locator = "//input", text = "")
    @Test
    @IExpectTestResult(errDesc = "метод вернул неожиданный результат", value = FAST_RESULT, expected = "true", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void checkEmptinessTestNegative() {
        runTest("checkEmptiness", TestData.ref("element"));
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @Test
    @IExpectTestResult(errDesc = "метод вернул неожиданный результат", value = FAST_RESULT, expected = "true", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void checkEqualityIgnoreCaseTestPositive() {
        runTest("checkEqualityIgnoreCase", TestData.ref("element"), "INPUT");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @Test
    @IExpectTestResult(errDesc = "метод вернул неожиданный результат", value = FAST_RESULT, expected = "false", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void checkEqualityIgnoreCaseTestNegative() {
        runTest("checkEqualityIgnoreCase", TestData.ref("element"), "TEXT");
    }
}
