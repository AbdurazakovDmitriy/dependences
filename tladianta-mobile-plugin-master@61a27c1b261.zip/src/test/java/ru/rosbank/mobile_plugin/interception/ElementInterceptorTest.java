package ru.rosbank.mobile_plugin.interception;

import io.appium.java_client.MobileElement;
import net.sf.cglib.proxy.MethodInterceptor;
import org.junit.Test;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.pagefactory.ElementLocator;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.IProvideInstance;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.at.data.TestData;
import ru.rosbank.mobile_plugin.interception.ElementInterceptor;
import ru.rosbank.mobile_test.environment.Converters;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.generators.ElementManager;


@ITestClass(ElementInterceptor.class)
public class ElementInterceptorTest extends IntereceptorTest {

    @IProvideInstance
    private ElementInterceptor buildInterceptor(){
        Object page=new Object(){
            @FindBy(xpath = "//input")
            MobileElement field;
        };
        return (ElementInterceptor) buildInterceptor(MobileElement.class,"click",page);
    }

    @Test
    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "метод click не был вызван", value = "#click", expected = "[input]", convertedBy= Converters.PredicateToIdConverter.class)
    public void getObjectTestPositive() {
        runTest("getObject", TestData.ref("Проксируемый элемент"), TestData.ref("Проксируемый метод"), new Object[]{});
    }

    @Test(expected = NoSuchElementException.class)
    @IGenerateElement(type = ElementManager.Type.BUTTON)
    public void getObjectTestNegative() {
        runTest("getObject", TestData.ref("Проксируемый элемент"), TestData.ref("Проксируемый метод"), new Object[]{});
    }

    @Override
    protected MethodInterceptor buildInterceptor(ElementLocator locator, WebDriver webDriver) {
        return new ElementInterceptor(locator,webDriver);
    }
}
