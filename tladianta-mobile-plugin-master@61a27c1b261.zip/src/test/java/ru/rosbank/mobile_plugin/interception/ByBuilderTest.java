package ru.rosbank.mobile_plugin.interception;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.*;
import io.appium.java_client.pagefactory.bys.builder.AnnotatedElementContainer;
import io.appium.java_client.pagefactory.bys.builder.AppiumByBuilder;
import lombok.SneakyThrows;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.IProvideInstance;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.at.annotations.ITestInstance;
import ru.rosbank.at.data.TestData;
import ru.rosbank.at.helpers.ReflectionBuilder;
import ru.rosbank.at.helpers.TypeConverters;
import ru.rosbank.at.results.TestResults;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;
import ru.rosbank.mobile_test.impls.ButtonImpl;
import ru.sbtqa.tag.pagefactory.environment.Environment;

import java.lang.reflect.Field;

import static junit.framework.TestCase.assertNotNull;

@ITestClass(ByBuilder.class)
public class ByBuilderTest extends MobileUnitTest {

    @IProvideInstance
    @SneakyThrows
    private ByBuilder instanciate() {
        Object page = new Object() {
            @CacheLookup
            @FindBy(xpath = "//element")
            MobileElement element;

            @FindBy(xpath = "//element")
            MobileElement field;
        };
        ByBuilder byBuilder = (ByBuilder) ReflectionBuilder
                .join(ByBuilder.class)
                .force()
                .build(Environment.getDriverService().getDriver());
        Field element = page.getClass().getDeclaredField("element");
        Field field = page.getClass().getDeclaredField("field");
        TestData.getInstance().push("FindBy", element.getAnnotation(FindBy.class));
        TestData.getInstance().push("CacheLookup", element.getAnnotation(CacheLookup.class));
        byBuilder.setAnnotated(element);
        By byElement = new FindBy.FindByBuilder().buildIt(element.getAnnotation(FindBy.class), element);
        By byField = new FindBy.FindByBuilder().buildIt(field.getAnnotation(FindBy.class), field);
        TestData.getInstance().push("by", byElement);
        TestData.getInstance().push("bies", new By[] {byElement, byField});
        return byBuilder;
    }

    @IProvideInstance("android element")
    @SneakyThrows
    private ByBuilder byBuilder() {
        Object page = new Object() {
            @AndroidFindBy(xpath = "//button")
            ButtonImpl element;
        };
        ByBuilder byBuilder = (ByBuilder) ReflectionBuilder
                .join(ByBuilder.class)
                .force()
                .build(Environment.getDriverService().getDriver());
        byBuilder.setAnnotated(page.getClass().getDeclaredField("element"));
        return byBuilder;
    }


    @Test
    @IExpectTestResult(errDesc = "локатор не соответствует заданному", value = FAST_RESULT, expected = "By.xpath: //element", convertedBy = TypeConverters.ConvertToStringMethod.class)
    public void buildByTest() {
        runTest("buildBy");
    }

    @Test
    @IExpectTestResult(errDesc = "локатор не соответствует заданному", value = FAST_RESULT, expected = "By.xpath: //element", convertedBy = TypeConverters.ConvertToStringMethod.class)
    public void returnMappedByTest() {
        runTest("returnMappedBy", TestData.ref("by"), TestData.ref("by"));
    }

    @Test
    @IExpectTestResult(errDesc = "аннотация CacheLookup неожиданно отсутствует", value = FAST_RESULT, expected = "true", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void isLookupCachedTestPositive() {
        runTest("isLookupCached");
    }

    @Test
    @ITestInstance("android element")
    @IExpectTestResult(errDesc = "аннотация CacheLookup неожиданно отсутствует", value = FAST_RESULT, expected = "false", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void isLookupCachedTestNegative() {
        runTest("isLookupCached");
    }

    @Test
    public void assertValidAnnotationsTest() {
        runTest("assertValidAnnotations");
        assertNotNull("проверяемое поле не инициализировано", ((AnnotatedElementContainer) ReflectionBuilder
                .join(AppiumByBuilder.class)
                .withField("annotatedElementContainer")
                .joinTarget(TestResults.getInstance().getTestResult(FAST_INSTANCE))
                .get()).getAnnotated());
    }

    @Test(expected = IllegalArgumentException.class)
    public void checkDisallowedAnnotationPairsTestAllPresent() {
        runTest("checkDisallowedAnnotationPairs", TestData.ref("FindBy"), TestData.ref("CacheLookup"));
    }

    @Test
    @IExpectTestResult(errDesc = "локатор не соответствует заданному", value = FAST_RESULT, expected = "By.xpath: //element", convertedBy = TypeConverters.ConvertToStringMethod.class)
    public void buildDefaultByTest() {
        runTest("buildDefaultBy");
    }

    @Test
    @IExpectTestResult(errDesc = "локатор не соответствует заданному", value = FAST_RESULT, expected = "null", convertedBy = TypeConverters.ConvertToStringMethod.class)
    public void buildMobileNativeByTest() {
        runTest("buildMobileNativeBy");
    }

    @Test
    @ITestInstance("android element")
    @IExpectTestResult(errDesc = "локатор не соответствует заданному", value = FAST_RESULT, expected = "By.chained({By.xpath: //button})", convertedBy = TypeConverters.ConvertToStringMethod.class)
    public void buildMobileNativeByTestNative() {
        runTest("buildMobileNativeBy");
    }

    @Test
    @ITestInstance("android element")
    @IExpectTestResult(errDesc = "локатор не был найден", value = FAST_RESULT, expected = "1", convertedBy = TypeConverters.ConvertToEnumerableSize.class)
    public void getBysTest() {
        runTest("getBys", AndroidFindBy.class, AndroidFindBys.class, AndroidFindAll.class);
    }

    @Test
    @IExpectTestResult(errDesc = "комбинированный локатор не соответствует заданному", value = FAST_RESULT, expected = "By.all({By.xpath: //element,By.xpath: //element})", convertedBy = TypeConverters.ConvertToStringMethod.class)
    public void buildMobileByTest() {
        runTest("buildMobileBy", LocatorGroupStrategy.ALL_POSSIBLE, TestData.ref("bies"));
    }
}
