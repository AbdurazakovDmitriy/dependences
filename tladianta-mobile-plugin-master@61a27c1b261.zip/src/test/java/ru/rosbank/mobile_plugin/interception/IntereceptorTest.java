package ru.rosbank.mobile_plugin.interception;

import io.appium.java_client.pagefactory.AppiumElementLocatorFactory;
import io.appium.java_client.pagefactory.utils.ProxyFactory;
import lombok.SneakyThrows;
import net.sf.cglib.proxy.MethodInterceptor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.pagefactory.ElementLocator;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import ru.rosbank.at.data.TestData;
import ru.rosbank.at.helpers.ReflectionBuilder;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;
import ru.sbtqa.tag.pagefactory.environment.Environment;

import java.lang.reflect.Field;
import java.time.Duration;

public abstract class IntereceptorTest extends MobileUnitTest {
    @SneakyThrows
    @SuppressWarnings("unchecked")
    MethodInterceptor buildInterceptor(Class clazz, String methodName, Object page) {
        TestData.getInstance().push("Проксируемый метод", clazz.getMethod(methodName));
        Field field = page.getClass().getDeclaredField("field");
        MethodInterceptor interceptor = buildInterceptor(getFactory().createLocator(field), Environment.getDriverService().getDriver());
        ReflectionBuilder.join(page.getClass())
                .joinTarget(page)
                .withField("field")
                .set(ProxyFactory.getEnhancedProxy(clazz, interceptor));
        TestData.getInstance().push("Проксируемый элемент", field.get(page));
        return interceptor;
    }

    protected ElementLocatorFactory getFactory() {
        WebDriver webDriver = Environment.getDriverService().getDriver();
        ByBuilder builder = (ByBuilder) ReflectionBuilder.join(ByBuilder.class).force().build(webDriver);
        return new AppiumElementLocatorFactory(webDriver,
                Duration.ofSeconds(1),
                builder);
    }

    protected abstract MethodInterceptor buildInterceptor(ElementLocator locator, WebDriver webDriver);
}
