package ru.rosbank.mobile_plugin.interception;

import io.appium.java_client.MobileElement;
import lombok.SneakyThrows;
import net.sf.cglib.proxy.MethodInterceptor;
import org.junit.Test;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.pagefactory.ElementLocator;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.IProvideInstance;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.at.data.TestData;
import ru.rosbank.at.helpers.IReflectionBuilder;
import ru.rosbank.at.helpers.ReflectionBuilder;
import ru.rosbank.at.helpers.TypeConverters;
import ru.rosbank.at.results.TestResults;
import ru.rosbank.automation.environment.IContext;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;
import ru.rosbank.mobile_test.impls.ButtonImpl;
import ru.sbtqa.tag.pagefactory.environment.Environment;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertFalse;

@ITestClass(MobileDecorator.class)
public class MobileDecoratorTest extends MobileUnitTest {

    @SneakyThrows
    @IProvideInstance
    private MobileDecorator buildInterceptor() {
        Object page = new IContext() {
            @FindBy(xpath = "//button")
            List<MobileElement> list;

            @FindBy(xpath = "//baseElement")
            ButtonImpl element;

            @FindBy(xpath = "//elements")
            List<ButtonImpl> elements;

            @FindBy(xpath = "//input")
            MobileElement field;

            @FindBy(xpath = "//mobileButton")
            ButtonImpl mobileButton;

            @FindBy(xpath = "//elements")
            List<String> stringElements;
        };

        TestData.getInstance().push("page", page);
        TestData.getInstance().push("list", page.getClass().getDeclaredField("list"));
        TestData.getInstance().push("element", page.getClass().getDeclaredField("element"));
        TestData.getInstance().push("elements", page.getClass().getDeclaredField("elements"));
        TestData.getInstance().push("field", page.getClass().getDeclaredField("field"));
        TestData.getInstance().push("mobileButton", page.getClass().getDeclaredField("mobileButton"));
        TestData.getInstance().push("stringElements", page.getClass().getDeclaredField("stringElements"));
        MethodInterceptor elementInterceptor = (obj, method, args, proxy) -> {
            TestResults.getInstance().push("interceptor");
            return null;
        };
        TestData.getInstance().push("interceptor", elementInterceptor);
        ElementLocator locator = new ElementLocator() {
            @Override
            public WebElement findElement() {
                return null;
            }

            @Override
            public List<WebElement> findElements() {
                return null;
            }
        };
        ElementLocatorFactory factory = field -> locator;
        TestData.getInstance().push("locator", locator);
        TestData.getInstance().push("factory", factory);
        return new MobileDecorator((SearchContext) Environment.getDriverService().getDriver());
    }

    @Test
    @IExpectTestResult(errDesc = "полученный класс не соответствует MobileElement", value = FAST_RESULT, expected = "io.appium.java_client.MobileElement", convertedBy = TypeConverters.ConvertToClass.class)
    public void getListGenericClassTestPositive() {
        runTest("getListGenericClass", TestData.ref("list"));
    }

    @Test(expected = ClassCastException.class)
    public void getListGenericClassTestNegative() {
        runTest("getListGenericClass", TestData.ref("element"));
    }

    @Test
    @IExpectTestResult(errDesc = "поле list не прошло валидацию", value = FAST_RESULT, expected = "true", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void isDecoratableListTestPositive() {
        runTest("isDecoratableList", MobileElement.class, TestData.ref("list"));
    }

    @Test
    @IExpectTestResult(errDesc = "поле element неожиданно прошло валидацию", value = FAST_RESULT, expected = "false", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void isDecoratableListTestElement() {
        runTest("isDecoratableList", MobileElement.class, TestData.ref("element"));
    }

    @Test
    @IExpectTestResult(errDesc = "поле stringElements неожиданно прошло валидацию", value = FAST_RESULT, expected = "false", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void isDecoratableListTestNegative() {
        runTest("isDecoratableList", MobileElement.class, TestData.ref("stringElements"));
    }

    @Test
    @IExpectTestResult(errDesc = "поле element не является оборачиваемым полем", value = FAST_RESULT, expected = "true", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void shallWrapSingleTestPositive() {
        runTest("shallWrapSingle", TestData.ref("element"));
    }

    @Test
    @IExpectTestResult(errDesc = "поле elements неожиданно является оборачиваемым полем", value = FAST_RESULT, expected = "false", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void shallWrapSingleTestNegative() {
        runTest("shallWrapSingle", TestData.ref("elements"));
    }

    @Test
    @IExpectTestResult(errDesc = "элементы поля не следует оборачивать", value = FAST_RESULT, expected = "true", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void shallWrapMultipleTestPositive() {
        runTest("shallWrapMultiple", TestData.ref("elements"));
    }

    @Test
    @IExpectTestResult(errDesc = "элементы поля неожиданно следует оборачивать", value = FAST_RESULT, expected = "false", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void shallWrapMultipleTestNegative() {
        runTest("shallWrapMultiple", TestData.ref("list"));
    }

    @Test
    @IExpectTestResult(errDesc = "поле element не следует декорировать", value = FAST_RESULT, expected = "true", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void shallDecorateSingleTestPositive() {
        runTest("shallDecorateSingle", TestData.ref("field"));
    }

    @Test
    @IExpectTestResult(errDesc = "поле element не следует декорировать", value = FAST_RESULT, expected = "false", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void shallDecorateSingleTestNegative() {
        runTest("shallDecorateSingle", TestData.ref("elements"));
    }

    @Test
    @IExpectTestResult(errDesc = "элементы листа не следует декорировать", value = FAST_RESULT, expected = "true", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void shallDecorateMultipleTestPositive() {
        runTest("shallDecorateMultiple", TestData.ref("elements"));
    }

    @Test
    @IExpectTestResult(errDesc = "элементы листа не следует декорировать", value = FAST_RESULT, expected = "false", convertedBy = TypeConverters.ConvertToBoolean.class)
    public void shallDecorateMultipleTestNegative() {
        runTest("shallDecorateMultiple", TestData.ref("stringElements"));
    }

    @Test
    @IExpectTestResult(errDesc = "полученный класс не соответствует MobileElement$$EnhancerByCGLIB$$ee712d7e", value = FAST_RESULT, expected = "io.appium.java_client.MobileElement$$EnhancerByCGLIB$$ee712d7e", convertedBy = TypeConverters.ConvertToClass.class)
    public void buildProxyTestPositive() {
        runTest("buildProxy", MobileElement.class, TestData.ref("interceptor"));
    }

    @Test(expected = AssertionError.class)
    @IExpectTestResult(errDesc = "полученный класс неожиданно соответствует MobileElement$$EnhancerByCGLIB$$ee712d7e", value = FAST_RESULT, expected = "io.appium.java_client.AppiumDriver", convertedBy = TypeConverters.ConvertToClass.class)
    public void buildProxyTestNegative() {
        runTest("buildProxy", MobileElement.class, TestData.ref("interceptor"));
    }

    @Test
    @IExpectTestResult(errDesc = "полученный класс не соответствует MobileButton", value = FAST_RESULT, expected = "ru.rosbank.mobile_test.impls.ButtonImpl", convertedBy = TypeConverters.ConvertToClass.class)
    public void proxyForWrappedSingleTestPositive() {
        runTest("proxyForWrappedSingle", TestData.ref("mobileButton"), TestData.ref("locator"));
    }

    @Test(expected = Exception.class)
    public void proxyForWrappedSingleTestNegative() {
        runTest("proxyForWrappedSingle", TestData.ref("field"), TestData.ref("locator"));
    }

    @Test
    @IExpectTestResult(errDesc = "полученный класс не соответствует $java.util.List$$EnhancerByCGLIB$$1964e348", value = FAST_RESULT, expected = "$java.util.List$$EnhancerByCGLIB$$1964e348", convertedBy = TypeConverters.ConvertToClass.class)
    public void proxyForWrappedMultipleTestPositive() {
        runTest("proxyForWrappedMultiple", TestData.ref("list"), TestData.ref("locator"));
    }

    @Test(expected = ClassCastException.class)
    public void proxyForWrappedMultipleTestNegative() {
        runTest("proxyForWrappedMultiple", TestData.ref("element"), TestData.ref("locator"));
    }

    @Test
    @IExpectTestResult(errDesc = "полученный класс не соответствует io.appium.java_client.android.AndroidElement$$EnhancerByCGLIB$$b598166c", value = FAST_RESULT, expected = "io.appium.java_client.android.AndroidElement$$EnhancerByCGLIB$$b598166c", convertedBy = TypeConverters.ConvertToClass.class)
    public void proxyForLocatorTestPositive() {
        runTest("proxyForLocator", TestData.ref("locator"));
    }

    @Test
    @IExpectTestResult(errDesc = "полученный класс не соответствует $java.util.List$$EnhancerByCGLIB$$1964e348", value = FAST_RESULT, expected = "$java.util.List$$EnhancerByCGLIB$$1964e348", convertedBy = TypeConverters.ConvertToClass.class)
    public void proxyForListLocatorTestPositive() {
        runTest("proxyForListLocator", TestData.ref("locator"));
    }

    @Test
    public void initProxyingTest() {
        runTest("initProxying", TestData.ref("factory"));
        assertFalse("Дефолтные обработчики не были загружены", ((Set) ReflectionBuilder
                .join(MobileDecorator.class)
                .withField("proxyProviders")
                .joinTarget(TestResults.getInstance().getTestResult(FAST_INSTANCE)).get()).isEmpty());

    }

    @Test
    public void decorateTest() {
        runTest("decorate", TestData.ref("page"));
        Object o = TestData.getInstance().provide("page");
        IReflectionBuilder.IUnassignedReflectionBuilder builder = ReflectionBuilder.join(o.getClass()).joinTarget(o).force();
        assertEquals("Поля контекста не были инициализированы", 1, Arrays.stream(o.getClass().getDeclaredFields()).filter(field -> builder.withField(field.getName()).get() == null).count());
    }
}
