package ru.rosbank.mobile_plugin.interception;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumElementLocatorFactory;
import io.appium.java_client.pagefactory.utils.ProxyFactory;
import lombok.SneakyThrows;
import net.sf.cglib.proxy.MethodProxy;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.IProvideInstance;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.at.data.TestData;
import ru.rosbank.at.helpers.ReflectionBuilder;
import ru.rosbank.at.helpers.TypeConverters;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.generators.ElementManager;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;
import ru.rosbank.mobile_test.impls.InputImpl;
import ru.sbtqa.tag.pagefactory.environment.Environment;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.time.Duration;
import java.util.List;

@ITestClass(ReferentListInterceptor.class)
public class ReferentListInterceptorTest extends MobileUnitTest {

    @IProvideInstance
    @SneakyThrows
    private ReferentListInterceptor getInterceptor() {
        WebDriver webDriver = Environment.getDriverService().getDriver();
        ByBuilder builder = (ByBuilder) ReflectionBuilder.join(ByBuilder.class).force().build(webDriver);
        ElementLocatorFactory factory = new AppiumElementLocatorFactory(webDriver,
                Duration.ofSeconds(1),
                builder);
        Object page = new Object() {
            @FindBy(xpath = "//input")
            MobileElement field;
        };
        Method method = List.class.getDeclaredMethod("size");
        TestData.getInstance().push("proxed method", method);
        Field field = page.getClass().getDeclaredField("field");
        ReferentListInterceptor referentListInterceptor = new ReferentListInterceptor(MobileElement.class,
                InputImpl.class,
                ProxyFactory.getEnhancedProxy(List.class, new ElementListInterceptor(factory.createLocator(field))));
        Constructor constructor = MethodProxy.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        TestData.getInstance().push("methodProxy", constructor.newInstance());
        return referentListInterceptor;
    }

    @Test
    @SneakyThrows
    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "size вернул значение отличное от 1", value = FAST_RESULT, expected = "1", convertedBy = TypeConverters.ConvertToInteger.class)
    public void interceptTestPositive() {
        runTest("intercept", new Object(), TestData.ref("proxed method"), new Object[]{}, TestData.ref("methodProxy"));
    }

    @Test(expected = AssertionError.class)
    @SneakyThrows
    @IExpectTestResult(errDesc = "size вернул значение отличное от 0", value = FAST_RESULT, expected = "1", convertedBy = TypeConverters.ConvertToInteger.class)
    public void interceptTestNegative() {
        runTest("intercept", new Object(), TestData.ref("proxed method"), new Object[]{}, TestData.ref("methodProxy"));
    }
}
