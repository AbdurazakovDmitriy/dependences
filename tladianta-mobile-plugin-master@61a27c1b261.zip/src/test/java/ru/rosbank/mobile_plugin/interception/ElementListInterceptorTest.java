package ru.rosbank.mobile_plugin.interception;

import io.appium.java_client.MobileElement;
import net.sf.cglib.proxy.MethodInterceptor;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.pagefactory.ElementLocator;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.IProvideInstance;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.at.data.TestData;
import ru.rosbank.at.helpers.TypeConverters;
import ru.rosbank.mobile_plugin.interception.ElementListInterceptor;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.generators.ElementManager;

import java.util.List;

//двойное использование фазы тест не является ошибкой
@ITestClass(value = ElementListInterceptor.class, phases = {"package-generate", "test", "generate", "test", "assert"})
public class ElementListInterceptorTest extends IntereceptorTest {

    @IProvideInstance
    private ElementListInterceptor buildInterceptor() {
        Object page = new Object() {
            @FindBy(xpath = "//button")
            List<MobileElement> field;
        };
        return (ElementListInterceptor) buildInterceptor(List.class, "size", page);
    }

    @Test
    @IGenerateElement(type = ElementManager.Type.BUTTON)
    @IExpectTestResult(errDesc = "size вернул значение отличное от 1", value = FAST_RESULT, expected = "1", convertedBy = TypeConverters.ConvertToInteger.class, soft = true)
    @IExpectTestResult(errDesc = "size вернул значение отличное от 0", value = FAST_RESULT, expected = "0", convertedBy = TypeConverters.ConvertToInteger.class, soft = true)
    public void getObjectTest() {
        runTest("getObject", TestData.ref("Проксируемый элемент"), TestData.ref("Проксируемый метод"), new Object[]{});
    }

    @Override
    protected MethodInterceptor buildInterceptor(ElementLocator locator, WebDriver webDriver) {
        return new ElementListInterceptor(locator);
    }
}
