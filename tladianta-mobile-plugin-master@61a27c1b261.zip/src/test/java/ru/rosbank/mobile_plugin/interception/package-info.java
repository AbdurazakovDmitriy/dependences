/**
 * пакет с общими тестами и тестами функциональности андроида
 */
@ILoadConfig("android_config")
@IStabDriver(PseudoDriver.class)
package ru.rosbank.mobile_plugin.interception;

import ru.rosbank.mobile_test.driver.PseudoDriver;
import ru.rosbank.mobile_test.environment.package_generate.ILoadConfig;
import ru.rosbank.mobile_test.environment.package_generate.IStabDriver;