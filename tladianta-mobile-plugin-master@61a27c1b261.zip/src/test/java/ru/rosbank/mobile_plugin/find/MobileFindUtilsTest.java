package ru.rosbank.mobile_plugin.find;

import org.junit.Test;
import org.openqa.selenium.TimeoutException;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.IProvideInstance;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.at.annotations.ITestInstance;
import ru.rosbank.at.data.TestData;
import ru.rosbank.at.helpers.TypeConverters;
import ru.rosbank.automation.environment.IContext;
import ru.rosbank.automation.exceptions.IncorrectElementTypeError;
import ru.rosbank.mobile_plugin.elements.AbstractMobileBlock;
import ru.rosbank.mobile_test.environment.Converters;
import ru.rosbank.mobile_test.environment.class_generate.IInitPages;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.generators.ElementManager;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;
import ru.rosbank.mobile_test.impls.ButtonImpl;
import ru.rosbank.mobile_test.impls.InputImpl;
import ru.sbtqa.tag.pagefactory.Page;
import ru.sbtqa.tag.pagefactory.PageManager;
import ru.sbtqa.tag.pagefactory.exceptions.PageInitializationException;

import java.util.Arrays;
import java.util.List;

import static ru.rosbank.at.data.TestData.ref;

@IInitPages
@ITestClass(value = MobileFindUtils.class, phases = {"package-generate", "class-generate", "generate", "test", "assert"})
public class MobileFindUtilsTest extends MobileUnitTest {
    @IProvideInstance("Страница с пост-инициализацией")
    MobileFindUtils getUtils() throws PageInitializationException {
        TestData.getInstance().push("Страница логина", PageManager.getPage("Страница логина"));
        return new MobileFindUtils();
    }

    /**
     * {@link MobileFindUtils#find(String)}
     */
    @IGenerateElement(type = ElementManager.Type.BUTTON)
    @Test
    @IExpectTestResult(errDesc = "Полученный элемент отличается от ожидаемого", value = FAST_RESULT, expected = "[button]", convertedBy = Converters.PredicateToElementConverter.class)
    public void findTestPositive() {
        runTest("find", "Кнопка");
    }

    /**
     * {@link MobileFindUtils#find(String)}
     */
    @Test(expected = TimeoutException.class)
    public void findTestInvalid() {
        runTest("find", "Кнопка");
    }

    /**
     * {@link MobileFindUtils#find(String)}
     */
    @IGenerateElement(type = ElementManager.Type.BUTTON, conditions = ElementManager.Condition.INVISIBLE)
    @Test(expected = TimeoutException.class)
    public void findTestMissing() {
        runTest("find", "Кнопка");
    }

    /**
     * {@link MobileFindUtils#find(String)}
     */
    @IGenerateElement(type = ElementManager.Type.BUTTON, conditions = ElementManager.Condition.APPEAR_FAST)
    @Test
    @IExpectTestResult(errDesc = "Полученный элемент отличается от ожидаемого", value = FAST_RESULT, expected = "[button]", convertedBy = Converters.PredicateToElementConverter.class)
    public void findTestAppearing() {
        runTest("find", "Кнопка");
    }

    /**
     * {@link MobileFindUtils#find(String)}
     */
    @IGenerateElement(type = ElementManager.Type.BLOCK)
    @Test
    @IExpectTestResult(errDesc = "Полученный элемент отличается от ожидаемого", value = FAST_RESULT, expected = "${getText}:Кнопка в блоке", convertedBy = TypeConverters.ConvertToElementMethodResult.class)
    public void findFieldTestPositive() {
        runTest("find", "Блок->Кнопка в блоке");
    }

    /**
     * {@link MobileFindUtils#findList(String)}
     */
    @IGenerateElement(type = ElementManager.Type.LIST, locator = "//button", text = "button1,button2,button3")
    @Test
    public void findListTestPositive() {
        runTest("findList", "Кнопки");
    }

    /**
     * {@link MobileFindUtils#findList(String)}
     */
    @Test
    public void findListTestPositiveEmpty() {
        runTest("findList", "Кнопки");
    }

    /**
     * {@link MobileFindUtils#findList(String)}
     */
    @Test(expected = IncorrectElementTypeError.class)
    public void findListTestWrongType() {
        runTest("findList", "Кнопка");
    }

    /**
     * {@link MobileFindUtils#getElementByTitle(Page, String)}
     */
    @ITestInstance("Страница с пост-инициализацией")
    @IGenerateElement(type = ElementManager.Type.BUTTON)
    @IExpectTestResult(errDesc = "элемент с именем 'Кнопка' не был найден", value = FAST_RESULT, expected = "Located by By.chained({By.xpath: //button})", convertedBy = TypeConverters.ConvertToStringMethod.class)
    @Test
    public void getElementByTitleTestPositive() {
        runTest("getElementByTitle", ref("Страница логина"), "Кнопка");
    }

    /**
     * {@link MobileFindUtils#getElementByTitle(Page, String)}
     */
    @ITestInstance("Страница с пост-инициализацией")
    @IGenerateElement(type = ElementManager.Type.BLOCK)
    @IExpectTestResult(errDesc = "элемент с именем 'Кнопка в блоке' не был найден", value = FAST_RESULT, expected = "${getText}:Кнопка в блоке", convertedBy = TypeConverters.ConvertToElementMethodResult.class)
    @Test
    public void getElementByTitleFieldTestPositive() {
        runTest("getElementByTitle", ref("Страница логина"), "Блок->Кнопка в блоке");
    }

    /**
     * {@link MobileFindUtils#getElementByTitle(Page, String)}
     */
    @ITestInstance("Страница с пост-инициализацией")
    @IGenerateElement(type = ElementManager.Type.BUTTON)
    @Test(expected = AssertionError.class)
    public void getElementByTitleTestNegative() {
        runTest("getElementByTitle", ref("Страница логина"), "Не кнопка");
    }

    /**
     * {@link MobileFindUtils#find(String, boolean)}
     */
    @Test
    @IGenerateElement(type = ElementManager.Type.BUTTON)
    public void findWaitTestPositive() {
        runTest("find", "Кнопка", true);
    }

    /**
     * {@link MobileFindUtils#find(String, boolean)}
     */
    @Test
    @IGenerateElement(type = ElementManager.Type.BLOCK)
    @IExpectTestResult(errDesc = "элемент 'Кнопка в блоке' не был найден", value = FAST_RESULT, expected = "${getText}:Кнопка в блоке", convertedBy = TypeConverters.ConvertToElementMethodResult.class)
    public void findWaitFieldTestPositive() {
        runTest("find", "Блок->Кнопка в блоке", true);
    }

    /**
     * {@link MobileFindUtils#find(String, boolean)}
     */
    @Test(expected = TimeoutException.class)
    @IGenerateElement(type = ElementManager.Type.BUTTON, conditions = ElementManager.Condition.INVISIBLE)
    public void findWaitTestNegative() {
        runTest("find", "Кнопка", true);
    }

    /**
     * {@link MobileFindUtils#findList(IContext, String)}
     */
    @Test
    @ITestInstance("Страница с пост-инициализацией")
    @IGenerateElement(type = ElementManager.Type.LIST, locator = "//button", text = "button1,button2,button3")
    @IExpectTestResult(errDesc = "элемент 'кнопки' не был найден", value = FAST_RESULT, expected = "3", convertedBy = TypeConverters.ConvertToEnumerableSize.class)
    public void findListByContextTestPositive() {
        runTest("findList", ref("Страница логина"), "Кнопки");
    }

    /**
     * {@link MobileFindUtils#findList(IContext, String)}
     */
    @Test
    @ITestInstance("Страница с пост-инициализацией")
    @IExpectTestResult(errDesc = "элемент 'кнопки' не был найден", value = FAST_RESULT, expected = "0", convertedBy = TypeConverters.ConvertToEnumerableSize.class)
    public void findListByContextTestNegative() {
        runTest("findList", ref("Страница логина"), "Кнопки");
    }

    /**
     * {@link MobileFindUtils#find(String, Class)}
     */
    @Test
    @IGenerateElement(type = ElementManager.Type.BLOCK)
    @IExpectTestResult(errDesc = "элемент 'Блок' не был найден", value = FAST_RESULT, expected = "Located by By.xpath: //block", convertedBy = TypeConverters.ConvertToStringMethod.class)
    public void findByTypeTestPositive() {
        runTest("find", "Блок", AbstractMobileBlock.class);
    }

    /**
     * {@link MobileFindUtils#find(String, Class)}
     */
    @Test
    @IGenerateElement(type = ElementManager.Type.BLOCK)
    @IExpectTestResult(errDesc = "элемент 'Поле в блоке' не был найден", value = FAST_RESULT, expected = "${getText}:Поле в блоке", convertedBy = TypeConverters.ConvertToElementMethodResult.class)
    public void findByTypeFieldTestPositive() {
        runTest("find", "Блок->Поле в блоке", InputImpl.class);
    }

    /**
     * {@link MobileFindUtils#find(String, Class)}
     */
    @Test(expected = AssertionError.class)
    @IGenerateElement(type = ElementManager.Type.BLOCK)
    public void findByTypeTestNegative() {
        runTest("find", "Блок", InputImpl.class);
    }

    /**
     * {@link MobileFindUtils#find(String, Class, boolean)}
     */
    @Test
    @IGenerateElement(type = ElementManager.Type.BLOCK)
    @IExpectTestResult(errDesc = "элемент 'Блок' не был найден", value = FAST_RESULT, expected = "Located by By.xpath: //block", convertedBy = TypeConverters.ConvertToStringMethod.class)
    public void findWaitByTypeTestPositive() {
        runTest("find", "Блок", AbstractMobileBlock.class, true);
    }

    /**
     * {@link MobileFindUtils#find(String, Class, boolean)}
     */
    @Test
    @IGenerateElement(type = ElementManager.Type.BLOCK)
    @IExpectTestResult(errDesc = "элемент 'Блок' не был найден", value = FAST_RESULT, expected = "Located by By.xpath: //block", convertedBy = TypeConverters.ConvertToStringMethod.class)
    public void findWaitByTypeFieldTestPositive() {
        runTest("find", "Блок", AbstractMobileBlock.class, true);
    }

    /**
     * {@link MobileFindUtils#find(String, Class, boolean)}
     */
    @Test(expected = TimeoutException.class)
    @IGenerateElement(type = ElementManager.Type.BLOCK, conditions = ElementManager.Condition.INVISIBLE)
    public void findWaitByTypeTestNegative() {
        runTest("find", "Блок", AbstractMobileBlock.class, true);
    }

    /**
     * {@link MobileFindUtils#find(String, List)}
     */
    @Test
    @IGenerateElement(type = ElementManager.Type.BUTTON)
    @IExpectTestResult(errDesc = "элемент 'Кнопка' не был найден", value = FAST_RESULT, expected = "Located by By.chained({By.xpath: //button})", convertedBy = TypeConverters.ConvertToStringMethod.class)
    public void findByTypesTestPositive() {
        runTest("find", "Кнопка", Arrays.asList(ButtonImpl.class, InputImpl.class));
    }

    /**
     * {@link MobileFindUtils#find(String, List)}
     */
    @Test(expected = TimeoutException.class)
    public void findByTypesTestNegative() {
        runTest("find", "Кнопка", Arrays.asList(ButtonImpl.class, InputImpl.class));
    }

    /**
     * {@link MobileFindUtils#find(String, List)}
     */
    @Test
    @IGenerateElement(type = ElementManager.Type.BLOCK)
    @IExpectTestResult(errDesc = "элемент 'Кнопка в блоке' не был найден", value = FAST_RESULT, expected = "${getText}:Кнопка в блоке", convertedBy = TypeConverters.ConvertToElementMethodResult.class)
    public void findByTypesFieldTestPositive() {
        runTest("find", "Блок->Кнопка в блоке", Arrays.asList(ButtonImpl.class, InputImpl.class));
    }

    /**
     * {@link MobileFindUtils#find(String, List, boolean)}
     */
    @Test
    @IGenerateElement(type = ElementManager.Type.BUTTON)
    @IExpectTestResult(errDesc = "элемент 'Кнопка' не был найден", value = FAST_RESULT, expected = "Located by By.chained({By.xpath: //button})", convertedBy = TypeConverters.ConvertToStringMethod.class)
    public void findWaitByTypesTestPositive() {
        runTest("find", "Кнопка", Arrays.asList(ButtonImpl.class, InputImpl.class), true);
    }

    /**
     * {@link MobileFindUtils#find(String, List, boolean)}
     */
    @Test
    @IGenerateElement(type = ElementManager.Type.BLOCK)
    @IExpectTestResult(errDesc = "элемент 'Кнопка в блоке' не был найден", value = FAST_RESULT, expected = "${getText}:Кнопка в блоке", convertedBy = TypeConverters.ConvertToElementMethodResult.class)
    public void findWaitByTypesFieldTestPositive() {
        runTest("find", "Блок->Кнопка в блоке", Arrays.asList(ButtonImpl.class, InputImpl.class), true);
    }

    /**
     * {@link MobileFindUtils#find(String, List, boolean)}
     */
    @Test(expected = TimeoutException.class)
    public void findWaitByTypesTestNegative() {
        runTest("find", "Кнопка", Arrays.asList(ButtonImpl.class, InputImpl.class), true);
    }

    /**
     * {@link MobileFindUtils#find(IContext, String, boolean)}
     */
    @Test
    @ITestInstance("Страница с пост-инициализацией")
    @IGenerateElement(type = ElementManager.Type.BUTTON)
    @IExpectTestResult(errDesc = "элемент 'Кнопка' не был найден", value = FAST_RESULT, expected = "Located by By.chained({By.xpath: //button})", convertedBy = TypeConverters.ConvertToStringMethod.class)
    public void findWaitByContextTestPositive() {
        runTest("find", ref("Страница логина"), "Кнопка", true);
    }

    /**
     * {@link MobileFindUtils#find(IContext, String, boolean)}
     */
    @Test
    @ITestInstance("Страница с пост-инициализацией")
    @IGenerateElement(type = ElementManager.Type.LIST, locator = "//button", text = "button1,button2,button3")
    @IExpectTestResult(errDesc = "элемент 'button2' не был найден", value = FAST_RESULT, expected = "${getText}:button2", convertedBy = TypeConverters.ConvertToElementMethodResult.class)
    public void findWaitByContextIndexTestPositive() {
        runTest("find", ref("Страница логина"), "Кнопки->1", true);
    }

    /**
     * {@link MobileFindUtils#find(IContext, String, boolean)}
     */
    @Test
    @ITestInstance("Страница с пост-инициализацией")
    @IGenerateElement(type = ElementManager.Type.BLOCK)
    @IExpectTestResult(errDesc = "элемент 'Кнопка в блоке' не был найден", value = FAST_RESULT, expected = "${getText}:Кнопка в блоке", convertedBy = TypeConverters.ConvertToElementMethodResult.class)
    public void findWaitByContextFieldTestPositive() {
        runTest("find", ref("Страница логина"), "Блок->Кнопка в блоке", true);
    }

    /**
     * {@link MobileFindUtils#find(IContext, String, boolean)}
     */
    @ITestInstance("Страница с пост-инициализацией")
    @Test(expected = TimeoutException.class)
    public void findWaitByContextTestNegative() {
        runTest("find", ref("Страница логина"), "Кнопка", true);
    }
}