/**
 * пакет с тестами для find
 */
@ILoadConfig(value = "mobile_config", initContext = true)
@IStabDriver(PseudoDriver.class)
package ru.rosbank.mobile_plugin.find;

import ru.rosbank.mobile_test.driver.PseudoDriver;
import ru.rosbank.mobile_test.environment.package_generate.ILoadConfig;
import ru.rosbank.mobile_test.environment.package_generate.IStabDriver;