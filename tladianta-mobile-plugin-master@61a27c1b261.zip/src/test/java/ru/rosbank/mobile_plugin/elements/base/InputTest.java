package ru.rosbank.mobile_plugin.elements.base;

import io.appium.java_client.MobileElement;
import org.junit.Test;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.IProvideInstance;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.mobile_test.driver.ElementProvider;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.generators.ElementManager;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;

@ITestClass(Input.class)
public class InputTest extends MobileUnitTest {

    @IProvideInstance
    Input generateButton() {
        return new Input((MobileElement) ElementProvider.getInstance().provide("//input").get());
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Не был вызван метод click", value = "#click")
    @Test
    public void clickTest() {
        runTest("click");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Не был вызван метод getText", value = "#getText")
    @IExpectTestResult(errDesc = "Аргументы были искажены при передаче", value = FAST_RESULT, expected = "input")
    @Test
    public void getTextTest() {
        runTest("getText");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Не был вызван метод sendKeys", value = "#sendKeys")
    @IExpectTestResult(errDesc = "Аргументы были искажены при передаче", value = "#sendKeys/value/", expected = "text")
    @Test
    public void setTextTest() {
        runTest("setText","text");
    }
}