/**
 * пакет с общими тестами и тестами функциональности андроида
 */
@IStabDriver(PseudoDriver.class)
package ru.rosbank.mobile_plugin.elements.base;

import ru.rosbank.mobile_test.driver.PseudoDriver;
import ru.rosbank.mobile_test.environment.package_generate.ILoadConfig;
import ru.rosbank.mobile_test.environment.package_generate.IStabDriver;