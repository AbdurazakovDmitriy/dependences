package ru.rosbank.mobile_plugin.elements.base;

import io.appium.java_client.MobileElement;
import org.junit.Test;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.IProvideInstance;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.mobile_test.driver.ElementProvider;
import ru.rosbank.mobile_test.environment.Converters;
import ru.rosbank.mobile_test.environment.class_generate.IInitPages;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.generators.ElementManager;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;

@ITestClass(Select.class)
public class SelectTest extends MobileUnitTest {

    @IProvideInstance
    Select generateSelect() {
        return new Select((MobileElement) ElementProvider.getInstance().provide("//combo-box").get());
    }

    @IGenerateElement(type = ElementManager.Type.COMBO_BOX)
    @IExpectTestResult(errDesc = "Не найден ожидаемый элемент", value = FAST_RESULT + "$0", expected = "option 1", convertedBy = Converters.ElementListExtractor.class, soft = true)
    @IExpectTestResult(errDesc = "Не найден ожидаемый элемент", value = FAST_RESULT + "$0", expected = "option 2", convertedBy = Converters.ElementListExtractor.class, soft = true)
    @IExpectTestResult(errDesc = "Не найден ожидаемый элемент", value = FAST_RESULT + "$0", expected = "option visible disabled", convertedBy = Converters.ElementListExtractor.class, soft = true)
    @IExpectTestResult(errDesc = "Не найден ожидаемый элемент", value = FAST_RESULT + "$0", expected = "option invisible enabled", convertedBy = Converters.ElementListExtractor.class, soft = true)
    @IExpectTestResult(errDesc = "Не найден ожидаемый элемент", value = FAST_RESULT + "$0", expected = "option invisible disabled", convertedBy = Converters.ElementListExtractor.class, soft = true)
    @Test
    public void getOptions() {
        runTest("getOptions");
    }

    @IGenerateElement(type = ElementManager.Type.COMBO_BOX, conditions = ElementManager.Condition.SELECTED)
    @IExpectTestResult(errDesc = "Не найден ожидаемый элемент", value = FAST_RESULT, expected = "option selected")
    @Test
    public void getTextSelected() {
        runTest("getText");
    }

    @IGenerateElement(type = ElementManager.Type.COMBO_BOX)
    @IExpectTestResult(errDesc = "Не найден ожидаемый элемент", value = FAST_RESULT, expected = "")
    @Test
    public void getTextNotSelected() {
        runTest("getText");
    }

    @IGenerateElement(type = ElementManager.Type.COMBO_BOX, conditions = ElementManager.Condition.SELECTED)
    @IExpectTestResult(errDesc = "Не найден ожидаемый элемент", value = FAST_RESULT, expected = "option selected", convertedBy = Converters.ElementListExtractor.class)
    @Test
    public void getAllSelectedOptions() {
        runTest("getAllSelectedOptions");
    }

    @IGenerateElement(type = ElementManager.Type.COMBO_BOX, conditions = ElementManager.Condition.SELECTED)
    @IExpectTestResult(errDesc = "Не найден ожидаемый элемент", value = "#isSelected", expected = "[*:text='option selected']", convertedBy = Converters.PredicateToIdConverter.class)
    @Test
    public void getSelectedOption() {
        runTest("getSelectedOption");
    }

    @IGenerateElement(type = ElementManager.Type.COMBO_BOX)
    @Test(expected = NoSuchElementException.class)
    public void getSelectedOptionNegative() {
        runTest("getSelectedOption");
    }

    @IGenerateElement(type = ElementManager.Type.COMBO_BOX)
    @IExpectTestResult(errDesc = "Не был выполнен выбор в селекте", value = "#click", expected = "[*:text='option 2']", convertedBy = Converters.PredicateToIdConverter.class)
    @Test
    public void selectByIndex() {
        runTest("selectByIndex", 1);
    }

    @IGenerateElement(type = ElementManager.Type.COMBO_BOX)
    @IExpectTestResult(errDesc = "Не был выполнен выбор в селекте", value = "#click", convertedBy = Converters.PredicateToIdConverter.class, force = true, exists = false)
    @Test(expected = TimeoutException.class)
    public void selectByIndexNegative() {
        runTest("selectByIndex", 2);
    }

    @IGenerateElement(type = ElementManager.Type.COMBO_BOX)
    @IExpectTestResult(errDesc = "Не был выполнен выбор в селекте", value = "#click", expected = "[*:text='option 2']", convertedBy = Converters.PredicateToIdConverter.class)
    @Test
    public void selectByValue() {
        runTest("selectByValue", "option 2");
    }

    @IGenerateElement(type = ElementManager.Type.COMBO_BOX)
    @IExpectTestResult(errDesc = "Не был выполнен выбор в селекте", value = "#click", convertedBy = Converters.PredicateToIdConverter.class, force = true, exists = false)
    @Test(expected = NoSuchElementException.class)
    public void selectByValueNegative() {
        runTest("selectByValue", "option selected");
    }

    @IGenerateElement(type = ElementManager.Type.COMBO_BOX, conditions = ElementManager.Condition.SELECTED)
    @Test(expected = UnsupportedOperationException.class)
    public void deselectByValue() {
        runTest("deselectByValue", "option selected");
    }

    @IGenerateElement(type = ElementManager.Type.COMBO_BOX, conditions = ElementManager.Condition.SELECTED)
    @Test(expected = UnsupportedOperationException.class)
    public void deselectByIndex() {
        runTest("deselectByIndex", 2);
    }
}