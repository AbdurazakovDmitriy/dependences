package ru.rosbank.mobile_plugin.elements.base;


import io.appium.java_client.MobileElement;
import org.junit.Test;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.IProvideInstance;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.mobile_test.driver.ElementProvider;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.generators.ElementManager;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;

@ITestClass(Button.class)
public class ButtonTest extends MobileUnitTest {

    @IProvideInstance
    Button generateButton() {
        return new Button((MobileElement) ElementProvider.getInstance().provide("//button").get());
    }

    @IGenerateElement(type = ElementManager.Type.BUTTON)
    @IExpectTestResult(errDesc = "Не был вызван метод click", value = "#click")
    @Test
    public void clickTest() {
        runTest("click");
    }

    @IGenerateElement(type = ElementManager.Type.BUTTON)
    @IExpectTestResult(errDesc = "Не был вызван метод getText", value = "#getText")
    @IExpectTestResult(errDesc = "Не был вызван метод getText", value = FAST_RESULT, expected = "button")
    @Test
    public void getTextTest() {
        runTest("getText");
    }
}