package ru.rosbank.mobile_plugin.elements.base;

import io.appium.java_client.MobileElement;
import org.junit.Test;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.IProvideInstance;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.at.helpers.TypeConverters;
import ru.rosbank.mobile_test.driver.ElementProvider;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.generators.ElementManager;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;

@ITestClass(CheckBox.class)
public class CheckBoxTest extends MobileUnitTest {

    @IProvideInstance
    CheckBox generateCheckBox() {
        return new CheckBox((MobileElement) ElementProvider.getInstance().provide("//check-box").get());
    }

    @IGenerateElement(type = ElementManager.Type.CHECK_BOX)
    @IExpectTestResult(errDesc = "Не был вызван метод click", value = "#click")
    @Test
    public void clickTest() {
        runTest("click");
    }

    @IGenerateElement(type = ElementManager.Type.CHECK_BOX, conditions = ElementManager.Condition.UNCHECKED)
    @IExpectTestResult(errDesc = "Не был вызван метод click", value = "#click")
    @Test
    public void checkPositive() {
        runTest("check");
    }

    @IGenerateElement(type = ElementManager.Type.CHECK_BOX)
    @IExpectTestResult(errDesc = "Был ошибочно вызван метод click", value = "#click", exists = false)
    @Test
    public void checkNegative() {
        runTest("check");
    }

    @IGenerateElement(type = ElementManager.Type.CHECK_BOX)
    @IExpectTestResult(errDesc = "Не был вызван метод click", value = "#click")
    @Test
    public void uncheckPositive() {
        runTest("uncheck");
    }

    @IGenerateElement(type = ElementManager.Type.CHECK_BOX, conditions = ElementManager.Condition.UNCHECKED)
    @IExpectTestResult(errDesc = "Был ошибочно вызван метод click", value = "#click", exists = false)
    @Test
    public void uncheckNegative() {
        runTest("uncheck");
    }

    @IGenerateElement(type = ElementManager.Type.CHECK_BOX, conditions = ElementManager.Condition.UNCHECKED)
    @IExpectTestResult(errDesc = "Был ошибочно вызван метод click", value = "#click")
    @Test
    public void testCheckTruePositive() {
        runTest("check", new Object[]{true});
    }

    @IGenerateElement(type = ElementManager.Type.CHECK_BOX)
    @IExpectTestResult(errDesc = "Был ошибочно вызван метод click", value = "#click", exists = false)
    @Test
    public void testCheckTrueNegative() {
        runTest("check", new Object[]{true});
    }

    @IGenerateElement(type = ElementManager.Type.CHECK_BOX)
    @IExpectTestResult(errDesc = "Был ошибочно вызван метод click", value = "#click")
    @Test
    public void testCheckFalsePositive() {
        runTest("check", new Object[]{false});
    }

    @IGenerateElement(type = ElementManager.Type.CHECK_BOX, conditions = ElementManager.Condition.UNCHECKED)
    @IExpectTestResult(errDesc = "Был ошибочно вызван метод click", value = "#click", exists = false)
    @Test
    public void testCheckFalseNegative() {
        runTest("check", new Object[]{false});
    }


    @IGenerateElement(type = ElementManager.Type.CHECK_BOX)
    @IExpectTestResult(errDesc = "Значение не соответсвует ожидаемому", value = FAST_RESULT, expected = "true",convertedBy = TypeConverters.ConvertToBoolean.class)
    @Test
    public void getStatePositive() {
        runTest("getState");
    }

    @IGenerateElement(type = ElementManager.Type.CHECK_BOX, conditions = ElementManager.Condition.UNCHECKED)
    @IExpectTestResult(errDesc = "Значение не соответсвует ожидаемому", value = FAST_RESULT, expected = "false",convertedBy = TypeConverters.ConvertToBoolean.class)
    @Test
    public void getStateNegative() {
        runTest("getState");
    }

    @IGenerateElement(type = ElementManager.Type.CHECK_BOX)
    @IExpectTestResult(errDesc = "Не был вызван метод getText", value = "#getText")
    @IExpectTestResult(errDesc = "Не был вызван метод getText", value = FAST_RESULT, expected = "checkbox")
    @Test
    public void getTextTest() {
        runTest("getText");
    }
}