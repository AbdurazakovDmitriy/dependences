/**
 * пакет с тестами для IOS
 */
/**
 * пакет с общими тестами и тестами функциональности андроида
 */
@ILoadConfig(value = "android_config", initContext = true)
@IStabDriver(PseudoDriver.class)
package ru.rosbank.mobile_plugin.elements;

import ru.rosbank.mobile_test.driver.PseudoDriver;
import ru.rosbank.mobile_test.environment.package_generate.ILoadConfig;
import ru.rosbank.mobile_test.environment.package_generate.IStabDriver;