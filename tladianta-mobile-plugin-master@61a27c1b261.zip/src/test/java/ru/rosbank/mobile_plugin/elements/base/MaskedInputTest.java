package ru.rosbank.mobile_plugin.elements.base;

import io.appium.java_client.MobileElement;
import org.junit.Test;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.IProvideInstance;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.at.helpers.ReflectionBuilder;
import ru.rosbank.mobile_plugin.environment.Mask;
import ru.rosbank.mobile_test.driver.ElementProvider;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.generators.ElementManager;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;

@ITestClass(MaskedInput.class)
public class MaskedInputTest extends MobileUnitTest {

    @IProvideInstance
    MaskedInput generateInput() {
        Mask mask=new Mask("_:3_:3_:2_:2","+ 7 (_:3) _:3 _:2 _:2");
        MaskedInput input= new MaskedInput((MobileElement) ElementProvider.getInstance().provide("//input").get());
        ReflectionBuilder.join(MaskedInput.class).joinTarget(input).withField("mask").force().set(mask);
        return input;
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Не был вызван метод click", value = "#click")
    @Test
    public void clickTest() {
        runTest("click");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT,text = "+ 7 (499) 123 12 12")
    @IExpectTestResult(errDesc = "Не был вызван метод getText", value = "#getText")
    @IExpectTestResult(errDesc = "Аргументы были искажены при конвертации", value = FAST_RESULT, expected = "4991231212")
    @Test
    public void getTextTest() {
        runTest("getText");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Не был вызван метод sendKeys", value = "#sendKeys")
    @IExpectTestResult(errDesc = "Аргументы были искажены при передаче", value = "#sendKeys/value/", expected = "4991231212")
    @Test
    public void setTextTest() {
        runTest("setText","4991231212");
    }
}