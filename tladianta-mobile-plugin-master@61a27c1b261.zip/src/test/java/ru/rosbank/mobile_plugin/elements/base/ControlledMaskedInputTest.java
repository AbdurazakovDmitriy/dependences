package ru.rosbank.mobile_plugin.elements.base;

import io.appium.java_client.MobileElement;
import org.junit.ComparisonFailure;
import org.junit.Test;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.IProvideInstance;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.at.annotations.ITestInstance;
import ru.rosbank.at.helpers.ReflectionBuilder;
import ru.rosbank.mobile_plugin.environment.Mask;
import ru.rosbank.mobile_test.driver.ElementProvider;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.generators.ElementManager;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;

@ITestClass(ControlledMaskedInput.class)
public class ControlledMaskedInputTest extends MobileUnitTest {

    Object[] empty={Boolean.TRUE};
    Object[] nonEmpty={Boolean.FALSE};

    @IProvideInstance
    ControlledMaskedInput loadMask(boolean clean){
        MobileElement element=(MobileElement) ElementProvider.getInstance().provide("//input").get();
        if (clean){
            element.clear();
        }
        Mask mask=new Mask("_:3_:3_:2_:2","+ 7 (_:3) _:3 _:2 _:2");
        ControlledMaskedInput input= new ControlledMaskedInput(element);
        ReflectionBuilder.join(MaskedInput.class).joinTarget(input).force().withField("mask").set(mask);
        return input;
    }

    @ITestInstance(argSource = "empty")
    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Не был вызван метод click", value = "#click")
    @Test
    public void clickTest() {
        runTest("click");
    }

    @ITestInstance(argSource = "nonEmpty")
    @IGenerateElement(type = ElementManager.Type.INPUT,text = "+ 7 (499) 123 12 12")
    @IExpectTestResult(errDesc = "Не был вызван метод getText", value = "#getText")
    @IExpectTestResult(errDesc = "Аргументы были искажены при конвертации", value = FAST_RESULT, expected = "4991231212")
    @Test
    public void getTextTest() {
        runTest("getText");
    }

    @ITestInstance(argSource = "nonEmpty")
    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Не был вызван метод sendKeys", value = "#sendKeys")
    @IExpectTestResult(errDesc = "Аргументы были искажены при передаче", value = "#sendKeys/value/", expected = "4991231212", force = true)
    @Test(expected = AssertionError.class)
    public void setTextTestNegative() {
        runTest("setText","4991231212");
    }

    @ITestInstance(argSource = "nonEmpty")
    @IGenerateElement(type = ElementManager.Type.INPUT, text = "+ 7 (499) 123 12 12")
    @IExpectTestResult(errDesc = "Не был вызван метод getText", value = "#getText")
    @Test
    public void assertTestPositive() {
        runTest("assertText","4991231212");
    }

    @ITestInstance(argSource = "nonEmpty")
    @IGenerateElement(type = ElementManager.Type.INPUT, text = "+ 7 (499) 123 12 12")
    @Test(expected = ComparisonFailure.class)
    public void assertTestWronMaskNegative() {
        runTest("assertText","NaN");
    }

    @ITestInstance(argSource = "nonEmpty")
    @IGenerateElement(type = ElementManager.Type.INPUT, text = "+ 7 (499) 123 12 12")
    @Test(expected = ComparisonFailure.class)
    public void assertTestWrongDataNegative() {
        runTest("assertText","1231231212");
    }
}