package ru.rosbank.mobile_plugin.elements.base;

import io.appium.java_client.MobileElement;
import org.junit.ComparisonFailure;
import org.junit.Test;
import ru.rosbank.at.annotations.IExpectTestResult;
import ru.rosbank.at.annotations.IProvideInstance;
import ru.rosbank.at.annotations.ITestClass;
import ru.rosbank.at.annotations.ITestInstance;
import ru.rosbank.mobile_test.driver.ElementProvider;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.generators.ElementManager;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;

@ITestClass(ControlledInput.class)
public class ControlledInputTest extends MobileUnitTest {

    @IProvideInstance
    ControlledInput generateControlledInput() {
        return new ControlledInput((MobileElement) ElementProvider.getInstance().provide("//input").get());
    }

    @IProvideInstance("clean")
    ControlledInput generateCleanControlledInput() {
        MobileElement element=(MobileElement) ElementProvider.getInstance().provide("//input").get();
        element.clear();
        return new ControlledInput(element);
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Не был вызван метод click", value = "#click")
    @Test
    public void clickTest() {
        runTest("click");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Не был вызван метод getText", value = "#getText")
    @IExpectTestResult(errDesc = "Аргументы были искажены при передаче", value = FAST_RESULT, expected = "input")
    @Test
    public void getTextTest() {
        runTest("getText");
    }

    @ITestInstance("clean")
    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Не был вызван метод sendKeys", value = "#sendKeys")
    @IExpectTestResult(errDesc = "Аргументы были искажены при передаче", value = "#sendKeys/value/", expected = "text")
    @Test
    public void setTextTestPositive() {
        runTest("setText","text");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Не был вызван метод sendKeys", value = "#sendKeys")
    @IExpectTestResult(errDesc = "Аргументы были искажены при передаче", value = "#sendKeys/value/", expected = "text", force = true)
    @Test(expected = ComparisonFailure.class)
    public void setTextTestNegative() {
        runTest("setText","text");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Не был вызван метод getText", value = "#getText")
    @Test
    public void assertTestPositive() {
        runTest("assertText","input");
    }

    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "Не был вызван метод getText", value = "#getText", force = true)
    @Test(expected = ComparisonFailure.class)
    public void assertTestNegative() {
        runTest("assertText","NaN");
    }
}