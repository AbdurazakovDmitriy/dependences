package ru.rosbank.mobile_plugin.elements;

import lombok.SneakyThrows;
import org.junit.Test;
import ru.rosbank.at.annotations.*;
import ru.rosbank.at.data.TestData;
import ru.rosbank.at.helpers.ReflectionBuilder;
import ru.rosbank.at.helpers.TypeConverters;
import ru.rosbank.at.results.TestResults;
import ru.rosbank.mobile_plugin.elements.core.text.IEditText;
import ru.rosbank.mobile_plugin.environment.IMaskData;
import ru.rosbank.mobile_plugin.environment.PlatformName;
import ru.rosbank.mobile_test.driver.ElementProvider;
import ru.rosbank.mobile_test.environment.class_generate.IInitPages;
import ru.rosbank.mobile_test.environment.generate.IGenerateElement;
import ru.rosbank.mobile_test.generators.ElementManager;
import ru.rosbank.mobile_test.helpers.MobileUnitTest;
import ru.rosbank.mobile_test.impls.HiddenInputImpl;
import ru.rosbank.mobile_test.impls.InputImpl;
import ru.rosbank.mobile_test.impls.MaskedInput;
import ru.rosbank.mobile_test.pages.FeaturePage;
import ru.sbtqa.tag.pagefactory.Page;
import ru.sbtqa.tag.pagefactory.context.PageContext;
import ru.sbtqa.tag.pagefactory.exceptions.PageInitializationException;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.function.Predicate;

@ITestClass(value = TypeResolver.class, instanceProvider = "static",
        phases = {"package-generate", "generate", "test", "class-generate", "result", "assert"})
@IInitPages("Страница нестандартных элементов")
public class TypeResolverTest extends MobileUnitTest {

    @SneakyThrows
    @IProvideInstance("referent")
    public TypeResolver refer() {
        TypeResolver.registerType(IEditText.class, InputImpl.class);
        TypeResolver.TypeInfo info = new TypeResolver.TypeInfo(IEditText.class, ElementProvider.getInstance().provide("//input").force(),
                FeaturePage.class.getDeclaredField("dynamicEdit").getAnnotations());
        TestData.getInstance().push("Field description", info);
        return null;
    }

    @IProcessPhase("result")
    public Throwable result(Method method) {
        Page page = PageContext.getCurrentPage();
        Object dynamicEdit = ReflectionBuilder.join(FeaturePage.class).joinTarget(page).force().withField("dynamicEdit").get();
        TestResults.getInstance().push("generated class", dynamicEdit.getClass().getCanonicalName());
        ReflectionBuilder.join(TypeResolver.class).force()
                .withField("renderMap")
                .andThen()
                .withMethod("get")
                .andThen()
                .withMethod("clear")
                .call();
        return null;
    }

    @Test
    @IExpectTestResult(errDesc = "ошибка при определении класса", expected = "ru.rosbank.mobile_test.impls.InputImpl", value = "generated class")
    public void registerTypeClassTest() {
        Predicate<TypeResolver.TypeInfo> predicate = info -> info.getType() == IEditText.class;
        runTest("registerType", predicate, InputImpl.class);
    }

    @Test
    @IExpectTestResult(errDesc = "ошибка при определении класса", expected = "ru.rosbank.mobile_test.impls.MaskedInput", value = "generated class")
    public void registerTypeAnnotationTest() {
        Predicate<TypeResolver.TypeInfo> predicate = info -> Arrays.stream(info.getAnnotations()).anyMatch(o -> o.annotationType() == IMaskData.class);
        runTest("registerType", predicate, MaskedInput.class);
    }

    @Test
    @IGenerateElement(type = ElementManager.Type.INPUT, locator = "//dynamic-field", conditions = ElementManager.Condition.INVISIBLE)
    @IExpectTestResult(errDesc = "ошибка при определении класса", expected = "ru.rosbank.mobile_test.impls.HiddenInputImpl", value = "generated class")
    public void registerTypeAttributeTest() {
        Predicate<TypeResolver.TypeInfo> predicate = info -> info.getElement().getAttribute("visible").equals("false");
        runTest("registerType", predicate, HiddenInputImpl.class);
    }

    @Test(expected = PageInitializationException.class)
    public void registerTypeNegativeTest() {
        Predicate<TypeResolver.TypeInfo> predicate = info -> info.getType() == TypeResolverTest.class;
        runTest("registerType", predicate, InputImpl.class);
    }

    @Test
    @IExpectTestResult(errDesc = "ошибка при определении класса", expected = "ru.rosbank.mobile_test.impls.HiddenInputImpl", value = "generated class")
    public void registerTypePlatformNamePositiveTest() {
        runTest("registerType", PlatformName.ANDROID, IEditText.class, HiddenInputImpl.class);
    }

    @Test(expected = PageInitializationException.class)
    public void registerTypePlatformNameNegativeTest() {
        runTest("registerType", PlatformName.IOS, IEditText.class, HiddenInputImpl.class);
    }

    @Test
    @IExpectTestResult(errDesc = "ошибка при определении класса", expected = "ru.rosbank.mobile_test.impls.HiddenInputImpl", value = "generated class")
    public void registerTypeRenderElementClassPlatformPositiveTest() {
        runTest("registerType", IEditText.class, HiddenInputImpl.class);
    }

    @Test(expected = PageInitializationException.class)
    public void registerTypeRenderElementClassNegativeTest() {
        runTest("registerType", MaskedInput.class, HiddenInputImpl.class);
    }

    @Test
    @IExpectTestResult(errDesc = "ошибка при определении класса", expected = "ru.rosbank.mobile_test.impls.HiddenInputImpl", value = "generated class")
    public void registerTypeElementRenderPositiveTest() {
        runTest("registerType", IEditText.class, "ru.rosbank.mobile_test.impls.HiddenInputImpl");
    }

    @Test(expected = RuntimeException.class)
    public void registerTypeElementRenderNegativeTest() {
        runTest("registerType", IEditText.class, "class404");
    }

    @Test
    @ITestInstance("referent")
    @IGenerateElement(type = ElementManager.Type.INPUT)
    @IExpectTestResult(errDesc = "элемент с именем 'Кнопка' не был найден", value = FAST_RESULT, expected = "ru.rosbank.mobile_test.impls.InputImpl", convertedBy = TypeConverters.ConvertToClass.class)
    public void getElementByTitleTestPositiveTest() {
        runTest("getImplementationForField", TestData.ref("Field description"));
    }

    @Test(expected = NullPointerException.class)
    @ITestInstance("referent")
    @IGenerateElement(type = ElementManager.Type.INPUT)
    public void getElementByTitleTestNegativeTest() {
        runTest("getImplementationForField", TestData.ref("class404"));
    }
}

