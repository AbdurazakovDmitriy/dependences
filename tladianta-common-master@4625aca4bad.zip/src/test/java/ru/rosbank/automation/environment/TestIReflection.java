package ru.rosbank.automation.environment;

import io.qameta.allure.Description;
import org.apache.commons.lang3.StringUtils;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import ru.rosbank.automation.annotations.ClassAnnotation;
import ru.rosbank.automation_test.pages.testPage8;
import ru.rosbank.automation_test.pages.testPage9;
import ru.sbtqa.tag.pagefactory.exceptions.FactoryRuntimeException;
import ru.sbtqa.tag.pagefactory.reflection.Reflection;

import static junit.framework.TestCase.assertEquals;

public class TestIReflection {

    @Rule
    public final ExpectedException thrown = ExpectedException.none();
    private final String FIELD_VALUE = "name";
    private final IReflection iReflection = new IReflection() {
        @Override
        public void executeMethodByTitleInBlock(String blockPath, String actionTitle, Object... parameters) {

        }

        @Override
        public Reflection getSource() {
            return null;
        }
    };
    private final Class<?> testPage9 = testPage9.class;
    private final Class<?> testPage8 = testPage8.class;

    @Test
    @Description("Класс есть. Аннотация у класса есть. Аннотация содержит нужное поле. Мягкая проверка. Тест пройдёт.")
    public void shouldReturnName() {
        assertEquals(iReflection.getAnnotationField(testPage9, ClassAnnotation.class, "title", false), "Test page");
    }

    @Test
    @Description("Класс есть. Аннотация у класса есть. Аннотация не содержит нужное поле. Мягкая проверка. Метод вернет пустую строку")
    public void shouldReturnEmptyString_AnnotationDoesNotContainField() {
        assertEquals(iReflection.getAnnotationField(testPage9, ClassAnnotation.class, FIELD_VALUE, true), StringUtils.EMPTY);
    }

    @Test
    @Description("Класс есть. Аннотация у класса есть. Аннотация не содержит нужное поле. Жёсткая проверка. Метод выбросит исключение")
    public void shouldReturnFactoryRuntimeException_AnnotationDoesNotContainField() {
        shouldThrowException("У аннотации нет свойства 'name'");
        iReflection.getAnnotationField(testPage9, ClassAnnotation.class, FIELD_VALUE, false);
    }

    @Test
    @Description("Класс есть. Аннотации у класса нет. Мягкая проверка. Метод вернёт пустую строку")
    public void shouldReturnEmptyString_ClassWithoutAnnotation() {
        assertEquals(iReflection.getAnnotationField(testPage8, ClassAnnotation.class, FIELD_VALUE, true), StringUtils.EMPTY);
    }

    @Test
    @Description("Класс есть. Аннотации у класса нет. Жесткая проверка. Метод выбросит исключение")
    public void shouldReturnFactoryRuntimeException_ClassWithoutAnnotation() {
        shouldThrowException("У класса нет аннотации 'ru.rosbank.automation.annotations.ClassAnnotation'");
        iReflection.getAnnotationField(testPage8, ClassAnnotation.class, FIELD_VALUE, false);
    }

    private void shouldThrowException(String errorMessage) {
        thrown.expect(FactoryRuntimeException.class);
        thrown.expectMessage(errorMessage);
    }
}
