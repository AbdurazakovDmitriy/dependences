package ru.rosbank.automation.tasks;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.jutils.jprocesses.JProcesses;
import org.jutils.jprocesses.model.ProcessInfo;
import ru.rosbank.automation.helpers.SystemHelperImpl;

import java.util.List;

import static org.junit.Assert.assertEquals;

public class KillProcessesTaskTest {
    private static final String EXE = "black.exe";
    private static final String EXE_PATH = "executable/" + EXE;
    private static final String COMMAND = KillProcessesTaskTest.class.getClassLoader().getResource(EXE_PATH).getPath()
            .replaceFirst("/", "")
            .replace("%20", " ");

    private KillProcessesTask killProcessesTask;

    /**
     * Запускает black.exe
     */
    @Before
    public void before() {
        SystemHelperImpl.getInstance().killProcess(EXE);
        killProcessesTask = new KillProcessesTask(EXE);
    }

    /**
     * Обнуляет таски после теста
     */
    @After
    public void after() {
        killProcessesTask = null;
    }

    /**
     * Тест запуска команды с 3я проверками:
     * - Запустить 3 приложения black.exe и проверить что их стало 3, убить, проверить что стало 0
     */
    @Test
    public void killProcess() {
        SystemHelperImpl.getInstance().runCommand(COMMAND);
        SystemHelperImpl.getInstance().runCommand(COMMAND);
        SystemHelperImpl.getInstance().runCommand(COMMAND);

        List<ProcessInfo> processesBefore = JProcesses.get().fastMode(true).listProcesses("black.exe");

        assertEquals(3, processesBefore.size());

        killProcessesTask.handle();

        List<ProcessInfo> processesAfter = JProcesses.get().fastMode(true).listProcesses("black.exe");

        assertEquals(0, processesAfter.size());
    }
}