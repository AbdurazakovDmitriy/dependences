package ru.rosbank.automation.extensions;

import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalUnit;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public class DateWorkerTest {

    private  static LocalDateTime dateTime;
    private  static LocalDateTime parsedDateTime;
    private  static LocalDateTime parsedBisDate;

    private static TemporalUnit years = ChronoUnit.YEARS;
    private static TemporalUnit months = ChronoUnit.MONTHS;
    private static TemporalUnit days = ChronoUnit.DAYS;
    private static TemporalUnit hours = ChronoUnit.HOURS;
    private static TemporalUnit minutes = ChronoUnit.MINUTES;

    private  static LocalDateTime year;
    private  static LocalDateTime yOffset;
    private  static LocalDateTime month;
    private  static LocalDateTime mOffset;
    private  static LocalDateTime day;
    private  static LocalDateTime dOffset;
    private  static LocalDateTime hour;
    private  static LocalDateTime hOffset;
    private  static LocalDateTime minute;
    private  static LocalDateTime minOffset;

    private static Integer yearOffset;
    private static Integer monthOffset;
    private static Integer dayOffset;
    private static Integer hourOffset;
    private static Integer minuteOffset;

    private static String testDateStr;
    private static Integer testDateInt;
    private static String testBisStr;
    private static String testRusStr;

    private static String pattern;
    private static String pattern2;

    /**
     * Выполняется перед каждым тестом
     */
    @Before
    public void before(){

        dateTime = LocalDateTime.of(2017, Month.JANUARY, 1, 6, 30);
        testDateStr = "2000-05-07 12:30";
        parsedDateTime = LocalDateTime.of(2000, Month.MAY, 7, 12, 30);
        testBisStr = "1180324";
        testRusStr = "24.03.2018";
        parsedBisDate = LocalDateTime.of(2018, Month.MARCH, 24, 0,0);


        year = LocalDateTime.of(2003, Month.JANUARY, 14, 12, 30);
        yOffset = LocalDateTime.of(2095, Month.JANUARY, 14, 12, 30);
        yearOffset = 92;

        month = LocalDateTime.of(2003, Month.JANUARY, 14, 12, 30);
        mOffset = LocalDateTime.of(2061, Month.JULY, 14, 12, 30);
        monthOffset = 702;

        day = LocalDateTime.of(2003, Month.JANUARY, 14, 12, 30);
        dOffset = LocalDateTime.of(2105, Month.APRIL, 8, 12, 30);
        dayOffset = 37339;

        hour = LocalDateTime.of(2003, Month.JANUARY, 14, 12, 30);
        hOffset = LocalDateTime.of(2105, Month.APRIL, 8, 12, 30);
        hourOffset = 896136;

        minute = LocalDateTime.of(2003, Month.JANUARY, 14, 12, 30);
        minOffset = LocalDateTime.of(2105, Month.APRIL, 8, 12, 30);
        minuteOffset = 53768160;

        pattern = "yyyy-MM-dd HH:mm";
        pattern2 = "yyddMMHHmm";
        testDateInt = 1701010630;
    }

    /**
     * Проверка DateWorker.offset c 2я параметрами
     */
    @Test
    public void offset_2params() {
        assertEquals(dOffset, DateWorker.offset(day, dayOffset));
    }

    /**
     * Проверка DateWorker.offset c 3я параметрами
     */
    @Test
    public void offset_3params() {
        assertEquals(yOffset, DateWorker.offset(year, yearOffset, years));
        assertEquals(mOffset, DateWorker.offset(month, monthOffset, months));
        assertEquals(dOffset, DateWorker.offset(day, dayOffset, days));
        assertEquals(hOffset, DateWorker.offset(hour, hourOffset, hours));
        assertEquals(minOffset, DateWorker.offset(minute, minuteOffset, minutes));
    }

    /**
     * Проверка DateWorker.parse
     */
    @Test
    public void parse() {
        assertEquals(parsedDateTime, DateWorker.parse(testDateStr, pattern));
        assertEquals(parsedDateTime, DateWorker.parse(parsedDateTime, pattern));
    }

    /**
     * Негативная проверка DateWorker.parse
     */
    @Test(expected = AssertionError.class)
    public void parse_AssertionError() {
        LocalDate date = LocalDate.now();
        DateWorker.parse(date, pattern);
    }

    /**
     * Проверка DateWorker.format
     */
    @Test
    public void format() {
        assertEquals(testDateStr, DateWorker.format(parsedDateTime, String.class, pattern));
        assertEquals(testDateInt, DateWorker.format(dateTime, Integer.class, pattern2));
        assertEquals(testBisStr, DateWorker.format(parsedBisDate, String.class, "bis"));
        assertEquals(testBisStr, DateWorker.format(parsedBisDate, String.class, "бис"));
        assertEquals(testRusStr, DateWorker.format(parsedBisDate, String.class, "ру"));
        assertEquals(testRusStr, DateWorker.format(parsedBisDate, String.class, "ru"));
    }

    /**
     * Негативная проверка DateWorker.format
     */
    @Test(expected = AssertionError.class)
    public void format_AssertionError() {
        DateWorker.format(dateTime, LocalDate.class, pattern2);
    }

    /**
     * Проверка DateWorker.parseOffsetFormat с 3я параметрами
     */
    @Test
    public void parseOffsetFormat_3params() {
        assertEquals(DateWorker.format(dOffset, String.class, pattern), DateWorker.parseOffsetFormat(DateWorker.format(day, String.class, pattern), pattern, dayOffset));
    }

    /**
     * Проверка DateWorker.parseOffsetFormat с 4я параметрами
     */
    @Test
    public void parseOffsetFormat_4params() {
        assertEquals(DateWorker.format(yOffset, String.class, pattern), DateWorker.parseOffsetFormat(DateWorker.format(year, String.class, pattern), pattern, yearOffset, years));
        assertEquals(DateWorker.format(mOffset, String.class, pattern), DateWorker.parseOffsetFormat(DateWorker.format(month, String.class, pattern), pattern, monthOffset, months));
        assertEquals(DateWorker.format(dOffset, String.class, pattern), DateWorker.parseOffsetFormat(DateWorker.format(day, String.class, pattern), pattern, dayOffset, days));
        assertEquals(DateWorker.format(hOffset, String.class, pattern), DateWorker.parseOffsetFormat(DateWorker.format(hour, String.class, pattern), pattern, hourOffset, hours));
        assertEquals(DateWorker.format(minOffset, String.class, pattern), DateWorker.parseOffsetFormat(DateWorker.format(minute, String.class, pattern), pattern, minuteOffset, minutes));
    }

    /**
     * Проверка DateWorker.parseFormat
     */
    @Test
    public void parseFormat() {
        assertEquals(day, DateWorker.parseFormat(DateWorker.format(day, String.class, pattern), pattern, LocalDateTime.class, pattern));
        assertEquals(DateWorker.format(day, String.class, pattern), DateWorker.parseFormat(DateWorker.format(day, String.class, pattern), pattern, String.class, pattern));
    }

    /**
     * Проверка DateWorker.dateWorker
     */
    @Test
    public void dateWorker() {
        assertEquals(dOffset, DateWorker.dateWorker(DateWorker.format(day, String.class, pattern), pattern, LocalDateTime.class, pattern, dayOffset, days));
        assertEquals(DateWorker.format(dOffset, String.class, pattern), DateWorker.dateWorker(DateWorker.format(day, String.class, pattern), pattern, String.class, pattern, dayOffset, days));
    }

    /**
     * Проверка DateWorker.getStringByPattern
     */
    @Test
    public void getStringByPattern() {
        assertEquals(testDateStr, DateWorker.getStringByPattern(parsedDateTime, pattern));
    }

    /**
     * Проверка DateWorker.parseStringDate
     */
    @Test
    public void parseStringDate() {
        assertEquals(parsedDateTime, DateWorker.parseStringDate(testDateStr, pattern));
    }

    /**
     * Негативная проверка DateWorker.getBISDateFromText
     */
    @Test(expected = AssertionError.class)
    public void getBISDateFromTextNegative() {
        DateWorker.getBISDateFromText(String.format("just some %s example text", testRusStr));
    }

    /**
     * Проверка DateWorker.getBISDateFromText
     */
    @Test
    public void getBISDateFromText() {
        assertEquals(testBisStr, DateWorker.getBISDateFromText(String.format("just some %s example text", testBisStr)));
    }

    /**
     * Проверка DateWorker.getDiffBetweenDates
     */
    @Test
    public void getDiffBetweenDates() {
        assertEquals(dayOffset.longValue(), DateWorker.getDiffBetweenDates(day.toLocalDate(), dOffset.toLocalDate()));
        assertEquals(dayOffset.longValue(), DateWorker.getDiffBetweenDates(dOffset.toLocalDate(), day.toLocalDate()));
    }
}