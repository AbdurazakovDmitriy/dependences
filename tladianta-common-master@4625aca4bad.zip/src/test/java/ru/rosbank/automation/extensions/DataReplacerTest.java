package ru.rosbank.automation.extensions;

import cucumber.api.PickleStepTestStep;
import gherkin.pickles.Argument;
import gherkin.pickles.PickleStep;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import ru.rosbank.automation.exceptions.DataGeneratorException;
import ru.rosbank.automation.exceptions.DataGeneratorKeyNotFoundException;
import ru.sbtqa.tag.pagefactory.optional.PickleStepTag;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.junit.Assert.*;

public class DataReplacerTest {
    private static final String KEY = "TEST_GENERATOR";
    private static final String KEY_WRONG = "WRONG";
    private static final String KEY_WRONG_GENERATOR = "WRONG_GENERATOR";
    private static final String ARGUMENT = "TEST_ARGUMENT";
    private static final String STRING = "TEST_STRING";
    private static final String STRING_INPUT = STRING + "[~{%s:%s}]";
    private static final String STRING_OUTPUT = STRING + "[%s]";
    private static final DataReplacer DATA_REPLACER = new DataReplacer();

    /**
     * Получение списка генераторов через рефлексию
     *
     * @return Список генераторов
     * @throws Exception - возникающие исключения
     */
    private static HashMap<String, Method> getGenerators() throws Exception {
        Field field = DataReplacer.class.getDeclaredField("generators");
        field.setAccessible(true);
        return (HashMap<String, Method>) field.get(null);
    }

    /**
     * Тестовый генератор, который доступен для вызова
     *
     * @param a - строка
     * @return - строка в нижнем реестре
     */
    private static String accessibleGenerator(String a) {
        return a.toLowerCase();
    }

    /**
     * Тестовый генератор, который не доступен для вызова
     *
     * @param a - строка
     * @return - строка в нижнем реестре
     */
    private static String unAccessibleGenerator(String a) {
        return a.toLowerCase();
    }


    /**
     * Выполняется перед каждым тестом: генератор с доступом публичным и закрытый
     *
     * @throws Exception - возникающие исключения
     */
    @Before
    public void before() throws Exception {
        HashMap<String, Method> generators = getGenerators();

        Method method1 = DataReplacerTest.class.getDeclaredMethod("accessibleGenerator", String.class);
        method1.setAccessible(true);
        generators.put(KEY, method1);

        Method method2 = DataReplacerTest.class.getDeclaredMethod("unAccessibleGenerator", String.class);
        generators.put(KEY_WRONG_GENERATOR, method2);
    }

    /**
     * Выполняется после каждого теста: удаление генераторов
     * @throws Exception - возникающие исключения
     */
    @After
    public void after() throws Exception {
        HashMap<String, Method> generators = getGenerators();
        generators.remove(KEY);
        generators.remove(KEY_WRONG_GENERATOR);
    }


    /**
     * Тест замены в степе на основе генератора:
     * - На основе действительного ключа
     */
    @Test
    public void replaceGeneratorFound() {

        PickleStepTestStep testStep1 = createTestStepForGenerator(KEY);

        DATA_REPLACER.replace(testStep1);

        String text = testStep1.getStepText();
        assertEquals(String.format(STRING_OUTPUT, ARGUMENT.toLowerCase()), text);
    }

    /**
     * Тест замены в степе на основе генератора:
     * - На основе не действительного ключа - генератор не зарегистрирован
     * - замена не происходит
     */
    @Test
    public void replaceGeneratorNotFound() {

        PickleStepTestStep testStep2 = createTestStepForGenerator(KEY_WRONG);
        String textInput = testStep2.getStepText();
        PickleStepTag stepCustom = ((PickleStepTag) testStep2.getPickleStep());

        DATA_REPLACER.replace(testStep2);

        String textOutput = testStep2.getStepText();
        Throwable throwable = stepCustom.getError();

        assertNotNull(throwable);
        assertEquals(DataGeneratorKeyNotFoundException.class, throwable.getClass());
        assertEquals(textInput, textOutput);
    }
    /**
     * Тест замены в степе на основе генератора:
     * - На основе не действительного генератора - метод генератор недоступен
     * - замена не происходит
     */
    @Test
    public void replaceGeneratorNotAccessible() {

        PickleStepTestStep testStep3 = createTestStepForGenerator(KEY_WRONG_GENERATOR);
        PickleStepTag stepCustom = ((PickleStepTag)testStep3.getPickleStep());
        String textInput = testStep3.getStepText();

        DATA_REPLACER.replace(testStep3);

        String textOutput = testStep3.getStepText();
        Throwable throwable = stepCustom.getError();

        assertNotNull(throwable);
        assertEquals(DataGeneratorException.class, throwable.getClass());
        assertEquals(textInput, textOutput);
    }

    /**
     * Тест замены в степе на основе генератора:
     * - степ пропущен
     * - метод генератора не доступен
     * - замена не происходит
     */
    @Test
    public void replaceGeneratorNotAccessibleStepSkipped() {

        PickleStepTestStep testStep3 = createTestStepForGenerator(KEY_WRONG_GENERATOR);
        PickleStepTag stepCustom = ((PickleStepTag)testStep3.getPickleStep());
        String textInput = testStep3.getStepText();
        stepCustom.setSkipped(true);

        DATA_REPLACER.replace(testStep3);

        String textOutput = testStep3.getStepText();

        assertTrue(stepCustom.getLog().contains("Ошибка генерации значения"));
        assertEquals(textInput, textOutput);
    }


    /**
     * Создание PickleStepTestStep на основе ключа
     * @param key - ключ
     * @return - новый степ
     */
    private PickleStepTestStep createTestStepForGenerator(String key) {
        return createTestStep(String.format(STRING_INPUT, key, ARGUMENT));
//                                      "TEST_STRING[~{TEST_GENERATOR:TEST_ARGUMENT}]"
    }

    /**
     * Создание PickleStepTestStep на основе строки
     * @param text - строка
     * @return - новый степ
     */
    private PickleStepTestStep createTestStep(String text) {
        PickleStep step = new PickleStep(text, new ArrayList<>(), new ArrayList<>());
        PickleStepTag stepCustom = new PickleStepTag(step);
        return new FakePickleStepTestStep("", stepCustom, null);
    }

    public static class FakePickleStepTestStep implements cucumber.api.PickleStepTestStep {

        private final String uri;
        private final PickleStep step;

        FakePickleStepTestStep(String uri, PickleStep step, Object definitionMatch) {
            this.uri = uri;
            this.step = step;
        }
        @Override
        public String getPattern() {
            return null;
        }

        @Override
        public PickleStep getPickleStep() {
            return this.step;
        }

        @Override
        public List<cucumber.api.Argument> getDefinitionArgument() {
            return null;
        }

        @Override
        public List<Argument> getStepArgument() {
            return null;
        }

        @Override
        public int getStepLine() {
            return 0;
        }

        @Override
        public String getStepLocation() {
            return null;
        }

        @Override
        public String getStepText() {
            return this.step.getText();
        }

        @Override
        public String getCodeLocation() {
            return null;
        }
    }
}