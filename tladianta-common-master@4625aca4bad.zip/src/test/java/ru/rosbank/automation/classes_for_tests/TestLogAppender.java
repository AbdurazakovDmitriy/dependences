package ru.rosbank.automation.classes_for_tests;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.spi.LoggingEvent;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class TestLogAppender extends ConsoleAppender {
    private static final int SIZE = 5;
    @NotNull
    private static ArrayList<LoggingEvent> loggingEventList = new ArrayList<>();

    @NotNull
    @Contract(pure = true)
    public static ArrayList<LoggingEvent> getLoggingEventList() {
        return loggingEventList;
    }

    @Override
    public void append(@NotNull LoggingEvent event) {
        if (event.getLoggerName().equals("ru.rosbank.automation.allure.AllureHelper")) {
            return;
        }
        loggingEventList.add(0, event);
        if(loggingEventList.size() > SIZE) {
            loggingEventList.remove(SIZE);
        }
        super.append(event);
    }
}
