package ru.rosbank.automation.classes_for_tests;

public class TestClass {
    public static final Integer A = 0;
    public final Integer B = 0;
    public static final Integer C = 0;
    private final Integer D = 0;

    public Object getB() {
        return B;
    }

    public static Object getC() {
        return C;
    }

    public Object getD() {
        return D;
    }

    public static Object getA() {
        return A;
    }
}
