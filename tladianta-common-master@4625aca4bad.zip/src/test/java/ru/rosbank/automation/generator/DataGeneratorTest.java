package ru.rosbank.automation.generator;

import org.junit.Before;
import org.junit.Test;

import java.util.Random;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class DataGeneratorTest {

    private static Integer length;
    private static String range;
    private static String range2;
    private static String range3;
    private static String range4;
    private static Integer first;
    private static Integer second;

    private static String matcherRu;
    private static String matcherEn;
    private static String matcherDate;

    /**
     * Выполняется перед каждым тестом
     */
    @Before
    public void before(){
        Random random = new Random();
        length = 1 + random.nextInt(19);
        first = random.nextInt(1000);
        second = first + random.nextInt(1000);
        range = String.format("%d-%d", first, second);
        range2 = String.format("%d-%d", first, first);
        range3 = String.format("%d-%d", 0, first);
        range4 = String.format("%d", first);
        matcherRu = String.format("[а-яё]{%d}", length);
        matcherEn = String.format("[a-z]{%d}", length);
        matcherDate = "[0123]\\d.[01]\\d.\\d{4} \\d{2}:\\d{2}:\\d{2}";
    }

    /**
     * Проверка DataGenerator.getRusString
     */
    @Test
    public void getRusString() {
        String s = DataGenerator.getRusString(length.toString());
        assertTrue(String.format("%s does not match %s", s, matcherRu), s.matches(matcherRu));
    }

    /**
     * Проверка DataGenerator.getLatinString
     */
    @Test
    public void getLatinString() {
        String s = DataGenerator.getLatinString(length.toString());
        assertTrue(String.format("%s does not match %s", s, matcherEn), s.matches(matcherEn));
    }

    /**
     * Проверка DataGenerator.getRandomNumIn
     */
    @Test
    public void getRandomNumIn() {
        Integer a = Integer.parseInt(DataGenerator.getRandomNumIn(range));
        Integer b = Integer.parseInt(DataGenerator.getRandomNumIn(range2));
        Integer c = Integer.parseInt(DataGenerator.getRandomNumIn(range3));
        Integer d = Integer.parseInt(DataGenerator.getRandomNumIn(range4));
        assertTrue(first <= a & a <= second);
        assertEquals(first, b);
        assertTrue(0 <= c & c <= first);
        assertTrue(d <= first);
    }

    /**
     * Проверка DataGenerator.number
     */
    @Test
    public void number() {
        assertEquals(DataGenerator.number(length.toString()).length(), (int) length);
    }

    /**
     * Проверка DataGenerator.getTimeStamp
     */
    @Test
    public void getTimeStamp() {
        assertTrue(DataGenerator.getTimeStamp("дата-время-миллисекунды").matches("\\d{4}[01]\\d[0123]\\d[01]\\d[0-6]\\d[0-6]\\d\\d{3}"));
        assertTrue(DataGenerator.getTimeStamp("дата-время-секунды").matches("\\d{4}[01]\\d[0123]\\d[01]\\d[0-6]\\d[0-6]\\d"));
        assertTrue(DataGenerator.getTimeStamp("дата").matches("\\d{4}[01]\\d[0123]\\d"));
        String s = DataGenerator.getTimeStamp("yyyy/dd/MM HH:mm:ss");
        assertTrue(String.format("%s does not match %s", s, "\\d{4}\\/[0123]\\d\\/[01]\\d\\s[01]\\d:[0-6]\\d:[0-6]\\d"), s.matches("\\d{4}\\/[0123]\\d\\/[01]\\d\\s[01]\\d:[0-6]\\d:[0-6]\\d"));
    }


    /**
     * Проверка DataGenerator.getDate
     */
    @Test
    public void getDate() {
        assertTrue(DataGenerator.getDate("сейчас").matches(matcherDate));
        assertTrue(DataGenerator.getDate("сегодня").matches(matcherDate));
        assertTrue(DataGenerator.getDate("сегодня;+10").matches(matcherDate));
        assertTrue(DataGenerator.getDate("сегодня;+100;лет").matches(matcherDate));
        assertTrue(DataGenerator.getDate("вчера;-1;год").matches(matcherDate));
        assertTrue(DataGenerator.getDate("вчера;-3;года").matches(matcherDate));
        assertTrue(DataGenerator.getDate("завтра;-1;час").matches(matcherDate));
        assertTrue(DataGenerator.getDate("завтра;+20;часов").matches(matcherDate));
        assertTrue(DataGenerator.getDate("завтра;+2;часа").matches(matcherDate));
        assertTrue(DataGenerator.getDate("завтра;-1;день").matches(matcherDate));
        assertTrue(DataGenerator.getDate("завтра;-2;дня").matches(matcherDate));
        assertTrue(DataGenerator.getDate("завтра;+5;дней").matches(matcherDate));
        assertTrue(DataGenerator.getDate("вчера;-1;месяц").matches(matcherDate));
        assertTrue(DataGenerator.getDate("сейчас;+2;месяца").matches(matcherDate));
        assertTrue(DataGenerator.getDate("сейчас;+6;месяцев").matches(matcherDate));
        assertTrue(DataGenerator.getDate("вчера;-1;минута").matches(matcherDate));
        assertTrue(DataGenerator.getDate("завтра;+2;минуты").matches(matcherDate));
        assertTrue(DataGenerator.getDate("сейчас;+6;минут").matches(matcherDate));
        assertTrue(DataGenerator.getDate("вчера;+6;мин").matches(matcherDate));
        assertTrue(DataGenerator.getDate("вчера;-1;секунда").matches(matcherDate));
        assertTrue(DataGenerator.getDate("завтра;+2;секунды").matches(matcherDate));
        assertTrue(DataGenerator.getDate("сейчас;+6;секунд").matches(matcherDate));
        assertTrue(DataGenerator.getDate("вчера;+6;сек").matches(matcherDate));
        assertTrue(DataGenerator.getDate("").matches(matcherDate));
        assertTrue(DataGenerator.getDate("вчера;+6;сек;маска|yyyy/dd/MM HH:mm:ss").matches("\\d{4}\\/[0123]\\d\\/[01]\\d\\s[01]\\d:[0-6]\\d:[0-6]\\d"));
        assertTrue(DataGenerator.getDate("вчера;+6;сек;входная маска|yyyy/dd/MM HH:mm:ss").matches("\\d{4}\\/[0123]\\d\\/[01]\\d\\s[01]\\d:[0-6]\\d:[0-6]\\d"));
    }
}