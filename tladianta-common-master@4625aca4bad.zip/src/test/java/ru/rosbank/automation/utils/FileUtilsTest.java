package ru.rosbank.automation.utils;

import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.junit.BeforeClass;
import org.junit.Test;
import ru.sbtqa.tag.qautils.errors.AutotestError;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import static org.junit.Assert.*;

@Slf4j
public class FileUtilsTest {
    @NotNull
    private static final String[] keys = {"Key0", "Key1", "Key2", "Key3"};
    @NotNull
    private static final String[] values = {"Value0", "Value1", "Value2", "Value3", "Value4", "Value5"};

    private static Properties propertiesSource1;
    private static Properties propertiesSource2;


    private static String propsPath;
    private static String wrongPropsPath;

    private static List<String> resultProps;

    private static File file;

    @NotNull
    private List<String> readPropsFile() {
        List<String> result = new ArrayList<>();
        try {
            FileReader fr = new FileReader(file);
            Scanner scan = new Scanner(fr);

            while (scan.hasNextLine()) {
                result.add(scan.nextLine());
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException("Не найден файл с указанным именем.\\n");
        }
        return result;
    }

    /**
     * Инициализируются необходимые переменные.
     */
    @BeforeClass
    public static void beforeClass() {
        propsPath = "config/fortest.properties";
        wrongPropsPath = "config/";
        propertiesSource1 = new Properties();
        propertiesSource2 = new Properties();
        resultProps = new ArrayList<>();
        String fullPropsPath = FileUtilsTest.class.getClassLoader()
                .getResource("config/fortest.properties").getPath()
                .replaceFirst("/", "")
                .replace("%20", " ");
        file = new File(fullPropsPath);
    }


    /**
     * Юнит тест метод для проверки метода writePropertiesToResource
     * C помощью тестируемого метода записаем подготовленные проперти propertiesFile по пути propsPath
     * С помощью FileReader построчно записываем файл в Set<String> result
     * Далее проверяем строчки на соответствие записанным данным
     * После записываем новые проперти и проверяем смену содержимого файла
     * В конце записываем в проперти значения по умолочанию
     */
    @Test
    public void writePropertiesToResource() {
        for (int i=0;i<3;i++){
            propertiesSource1.setProperty(keys[i],values[i]);
        }

        FileUtils.writePropertiesToResource(propsPath, propertiesSource1);
        resultProps=this.readPropsFile();

        assertTrue(resultProps.stream().map(o -> o.split(" = ")).allMatch(o -> propertiesSource1.getProperty(o[0]).equals(o[1])));
        assertEquals(resultProps.size(),propertiesSource1.size());


        propertiesSource2.setProperty(keys[0], values[3]);
        propertiesSource2.setProperty(keys[1], values[4]);
        propertiesSource2.setProperty(keys[2], values[5]);
        propertiesSource2.setProperty(keys[3], values[2]);

        FileUtils.writePropertiesToResource(propsPath, propertiesSource2);
        resultProps = this.readPropsFile();

        assertTrue(resultProps.stream().map(o -> o.split(" = ")).allMatch(o -> propertiesSource2.getProperty(o[0]).equals(o[1])));
        assertEquals(resultProps.size(),propertiesSource2.size());

        try {
            FileUtils.writePropertiesToResource(wrongPropsPath, propertiesSource2);
            fail("Ожидается AutotestError");
        } catch (AutotestError thrown) {
            assertEquals(String.format("Не найден файл '%s'. Замена свойств не удалась.", wrongPropsPath), thrown.getMessage());
        }
    }
}
