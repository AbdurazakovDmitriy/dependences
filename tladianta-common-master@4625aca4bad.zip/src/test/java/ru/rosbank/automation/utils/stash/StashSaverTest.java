package ru.rosbank.automation.utils.stash;

import org.junit.*;
import ru.rosbank.automation.utils.db.DbClient;
import ru.rosbank.automation.utils.db.DbConfig;
import ru.sbtqa.tag.datajack.Stash;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.function.BiFunction;

import static org.junit.Assert.assertEquals;

public class StashSaverTest {
    private static final String[] array_keys = {"KeyA", "KeyB", "KeyC"};

    private static final String[] array_values = {"ValueA", "ValueB", "ValueC"};

    private static final String TEST_NAME = "first";
    private static final String TABLE_NAME = "test";
    private static Object oldDbClient = null;
    private static DbClient newDbClient = null;
    private static String oldSelect = null;
    private static String oldInsert = null;
    private static String oldUpdate = null;
    private static StashSaverSQL stashSaverSQL;

    /**
     * Рефлексивное изменение значения поля
     * @param name - имя поля
     * @param newValue - новое значение
     * @return - старое значение
     * @throws Exception - возникшие исключения
     */
    private static Object setField(String name, Object newValue) throws Exception {
        Field field = StashSaverSQL.class.getDeclaredField(name);
        field.setAccessible(true);
        Object returnValue = field.get(stashSaverSQL);
        field.set(stashSaverSQL, newValue);
        return returnValue;
    }

    /**
     * Рефлексивное изменение значения запроса
     * @param name - запрос
     * @param value - имя таблицы
     * @param processor - функция замены
     * @return - стаое значение
     * @throws Exception - возникшие исключения
     */
    private static String setQuery(String name, String value, BiFunction<String, String, String> processor) throws Exception {
        Field field = StashSaverSQL.class.getDeclaredField(name);
        field.setAccessible(true);
        String returnValue = (String)field.get(stashSaverSQL);
        String newValue = processor.apply(returnValue, value);
        field.set(stashSaverSQL, newValue);
        return returnValue;
    }

    /**
     * Подстановка значения имени таблицы в запрос
     * @param query - запрос
     * @param name - имя таблицы
     * @return - измененный запрос
     */
    private static String replaceTableName(String query, String name) {
        return query
                .replaceFirst("UPDATE ([\\s\\S]+?) SET", String.format("UPDATE %s SET",name))
                .replaceFirst("FROM ([\\s\\S]+?) WHERE", String.format("FROM %s WHERE",name))
                .replaceFirst("INTO ([\\s\\S]+?)\\(", String.format("INTO %s(",name))
                .replaceAll("\\[", "")
                .replaceAll("\\]", "");
    }

    /**
     * Выполняется перед веми тестами: подготовка данных
     * @throws Exception - возникшие исключения
     */
    @BeforeClass
    public static void beforeClass() throws Exception {
//        new StashSaverSQL();
        Field field = StashSaver.class.getDeclaredField("stashSaverSQL");
        field.setAccessible(true);
        stashSaverSQL = (StashSaverSQL)field.get(null);

        oldSelect = setQuery("SELECT", TABLE_NAME, StashSaverTest::replaceTableName);
        oldInsert = setQuery("INSERT", TABLE_NAME, StashSaverTest::replaceTableName);
        oldUpdate = setQuery("UPDATE", TABLE_NAME, StashSaverTest::replaceTableName);

        newDbClient = new DbClient(new DbConfig("jdbc:h2:mem:test", "", ""));
        oldDbClient = setField("dbClient", newDbClient);

        newDbClient.executeUpdateQuery(String.format("CREATE TABLE %s (testName varchar(128), json varchar(1024));", TABLE_NAME));
    }

    /**
     * Выполняется после всех тестов: очистка данных
     * @throws Exception - возникшие исключения
     */
    @AfterClass
    public static void afterClass() throws Exception {
        setQuery("SELECT", oldSelect, (a, b) -> b);
        setQuery("INSERT", oldInsert, (a, b) -> b);
        setQuery("UPDATE", oldUpdate, (a, b) -> b);

        DbClient dbClient = (DbClient) setField("dbClient", oldDbClient);
        dbClient.executeUpdateQuery(String.format("DROP TABLE %s;", TABLE_NAME));
    }

    /**
     * Выполняется перед каждым тестом
     * @throws Exception - возникшие исключения
     */
    @Before
    public void before() throws Exception {
        Stash.clear();
    }

    /**
     * Выполняется после каждого теста
     * @throws Exception - возникшие исключения
     */
    @After
    public void after() throws Exception {
        Stash.clear();
    }

    /**
     * Проверка сохранения и получения данных
     */
    @Test
    public void save_and_get() {
        String request = String.format("SELECT * FROM %s", TABLE_NAME);
        assertEquals(newDbClient.request(request).size(), 0);

        for(int i = 0; i < 3; i++) {
            Stash.put(array_keys[i], array_values[i]);
        }
        StashSaver.saveToDB(TEST_NAME);
        assertEquals(newDbClient.request(request).size(), 1);

        StashSaver.saveToDB(TEST_NAME);
        assertEquals(newDbClient.request(request).size(), 1);

        Stash.clear();

        Map<String, String> stash = StashSaver.getFromDB(TEST_NAME);
        for(int i = 0; i < 3; i++) {
            assertEquals(stash.get(array_keys[i]), array_values[i]);
        }
    }
}