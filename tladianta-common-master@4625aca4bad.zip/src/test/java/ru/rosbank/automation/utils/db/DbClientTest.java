package ru.rosbank.automation.utils.db;

import org.junit.*;
import ru.rosbank.automation.exceptions.DbConnectionException;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

public class DbClientTest {
    private static final String url = "jdbc:h2:~/test";
    private static final String SELECT = "SELECT * FROM %s";
    private static final String SELECT_NULL = "SELECT * FROM %s WHERE %s = 'wrong'";
    private static final String UPDATE = "UPDATE %s SET FirstColumn = '%s', SecondColumn = %s WHERE FirstColumn = '%s'";

    private static final String TABLE = "test_table";
    private static final String TABLE_WRONG = "wrong";
    private static final String FIRST_COLUMN = "FirstColumn";
    private static final String SECOND_COLUMN = "SecondColumn";

    private static final String CREATE_TABLE = "CREATE TABLE %s (%s varchar(255), %s int);";
    private static final String DROP_TABLE = "DROP TABLE IF EXISTS %s";
    private static final String INSERT = "INSERT INTO %s (%s, %s) VALUES ('%s', %s);";

    private static final String[] value_letter = {"aa", "a", "b", "c"};
    private static final String[] value_digit = {"11", "1", "2", "3"};

    private static Connection connection = null;
    private DbClient client = null;

    /**
     * Выполняется перед всеми тестами: создание соединение с H2
     * @throws SQLException - возникшие исключения
     */
    @BeforeClass
    public static void beforeClass() throws SQLException {
        connection = DriverManager.getConnection(url);
    }

    /**
     * Выполняется перед каждым тестом: подготовка данных в H2
     * @throws SQLException - возникшие исключения
     */
    @Before
    public void before() throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.execute(String.format(DROP_TABLE, TABLE));
            statement.execute(String.format(CREATE_TABLE, TABLE, FIRST_COLUMN, SECOND_COLUMN));
            for(int i = 1; i < 4; i++) {
                statement.execute(String.format(INSERT, TABLE, FIRST_COLUMN, SECOND_COLUMN, value_letter[i], value_digit[i]));
            }
        }

        client = new DbClient(new DbConfig(url, null, null));
    }

    /**
     * Проверка запроса: количество подготовленных данных
     */
    @Test
    public void executeQuery() {
        boolean result = client.executeQuery(String.format(SELECT, TABLE), rs -> {
            int rows = 0;
            while (rs.next()) {
                rows++;
                ResultSetMetaData rsMetaData = rs.getMetaData();
                if(rsMetaData.getColumnCount() != 2) return false;
            }
            return rows == 3;
        });

        assertTrue("ResultSet состоит из 3х строк и 2х колонок", result);
    }

    /**
     * Проверка запроса к не существующей таблице
     */
    @Test(expected = DbConnectionException.class)
    public void executeQuery_DbConnectionException_2() {
        client.executeQuery(String.format(SELECT, TABLE_WRONG), rs -> rs );
    }

    /**
     * Проверка запроса на обновление данных
     */
    @Test
    public void executeUpdateQuery() throws Exception {
        int result_code = client.executeUpdateQuery(String.format(UPDATE, TABLE, value_letter[0], value_digit[0], value_letter[1]));

        assertEquals(1, result_code);

        ArrayList<Map<String, String>> result = new ArrayList<>();
        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(String.format(SELECT, TABLE));
            while(resultSet.next()){
                HashMap<String, String> hashMap = new HashMap<>();
                result.add(hashMap);
                int columnCount = resultSet.getMetaData().getColumnCount();
                for(int i = 1; i < columnCount + 1; i ++) {
                    String columnLabel = resultSet.getMetaData().getColumnLabel(i);
                    hashMap.put(columnLabel, resultSet.getString(columnLabel));
                }
            }
        }

        assertEquals(value_letter[0], result.get(0).get(FIRST_COLUMN.toUpperCase()));
        assertEquals(value_digit[0], result.get(0).get(SECOND_COLUMN.toUpperCase()));

        for(int i = 1; i < 3; i++) {
            assertEquals(value_letter[i + 1], result.get(i).get(FIRST_COLUMN.toUpperCase()));
            assertEquals(value_digit[i + 1], result.get(i).get(SECOND_COLUMN.toUpperCase()));
        }
    }

    /**
     * Проверка запроса на обновление данных к несуществующей таблице
     */
    @Test(expected = DbConnectionException.class)
    public void executeUpdateQuery_DbConnectionException() {
        client.executeUpdateQuery(String.format(UPDATE, TABLE_WRONG, value_letter[0], value_digit[0], value_letter[1]));
    }

    /**
     * Проверка запроса с конвертацие - все строки и столбцы
     */
    @Test
    public void request() {
        List<Map<String, String>> result = client.request(String.format(SELECT, TABLE));

        for(int i = 0; i < 3; i++) {
            assertEquals(value_letter[i + 1], result.get(i).get(FIRST_COLUMN.toUpperCase()));
            assertEquals(value_digit[i + 1], result.get(i).get(SECOND_COLUMN.toUpperCase()));
        }
    }

    /**
     * Проверка запроса с конвертацией - первая строка
     */
    @Test
    public void requestRow() {
        Map<String, String> result = client.requestRow(String.format(SELECT, TABLE));

        assertEquals(value_letter[1], result.get(FIRST_COLUMN.toUpperCase()));
        assertEquals(value_digit[1], result.get(SECOND_COLUMN.toUpperCase()));
    }

    /**
     * Проверка запроса с конвертацией - первое значение и первое значение по имени колонки
     */
    @Test
    public void requestValue() {
        String result;

        result = client.requestValue(String.format(SELECT_NULL, TABLE, FIRST_COLUMN));
        assertNull(result);

        result = client.requestValue(String.format(SELECT, TABLE));
        assertEquals(value_letter[1], result);

        result = client.requestValue(String.format(SELECT, TABLE), SECOND_COLUMN.toUpperCase());
        assertEquals(value_digit[1], result);
    }

    /**
     * Проверка запроса с конвертацией - первая колонка
     */
    @Test
    public void requestColumn() {
        List<String> result;

        result = client.requestColumn(String.format(SELECT, TABLE));
        for(int i = 0; i < 3; i++) {
            assertEquals(value_letter[i + 1], result.get(i));
        }

        result = client.requestColumn(String.format(SELECT, TABLE), SECOND_COLUMN.toUpperCase());
        for(int i = 0; i < 3; i++) {
            assertEquals(value_digit[i + 1], result.get(i));
        }
    }

    /**
     * Выполняется после кааждого теста: удаление данных
     * @throws SQLException - возникшие исключения
     */
    @After
    public void after() throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.execute(String.format(DROP_TABLE, TABLE));
        }

        client.closeConnection();
        client = null;
    }

    /**
     * Выполняется после всех тестов: закрытие соединения с H2
     * @throws SQLException - возникшие исключения
     */
    @AfterClass
    public static void afterClass() throws SQLException {
        if(connection != null) {
            connection.close();
        }
    }
}
