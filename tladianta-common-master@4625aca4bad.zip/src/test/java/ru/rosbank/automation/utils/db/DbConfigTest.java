package ru.rosbank.automation.utils.db;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import ru.rosbank.automation.exceptions.DbConnectionException;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import static org.junit.Assert.fail;

public class DbConfigTest {
    private static final String url = "jdbc:h2:~/test";
    private static final String url_wrong = "wrong";

    private static final String TABLE = "work";
    private static final String CREATE_TABLE = "CREATE TABLE %s (A varchar(255), B int);";
    private static final String DROP_TABLE = "DROP TABLE %s";

    private DbConfig dbConfig;

    private static class TestException extends RuntimeException {
    }

    /**
     * Выполняется перед каждым тестом
     * @throws Exception
     */
    @Before
    public void before() throws Exception {
        dbConfig = null;
    }

    /**
     * Выполняется после каждого теста
     * @throws Exception
     */
    @After
    public void after() throws Exception {
        if(dbConfig != null) {
            dbConfig.closeConnection();
        }
    }

    /**
     * Проверка на Подготовительный скрипт с исключением
     */
    @Test(expected = TestException.class)
    public void constructor() {
        DbConfig dbConfig = new DbConfig(url, null, null, () -> {
            throw new TestException();
        });

        dbConfig.getConnection();
    }

    /**
     * Проверка на получение соединения
     */
    @Test
    public void getConnection() {
        dbConfig = new DbConfig(url, null, null);

        try {
            Connection connection = dbConfig.getConnection();
            try (Statement statement = connection.createStatement()) {
                statement.execute(String.format(CREATE_TABLE, TABLE));
                statement.execute(String.format(DROP_TABLE, TABLE));
            }
        }
        catch(SQLException e) {
            fail();
        }
    }

    /**
     * Проверка на недействительный параметр адреса базы
     */
    @Test(expected = DbConnectionException.class)
    public void getConnection_DbConnectionException() {
        DbConfig dbConfig = new DbConfig(url_wrong, null, null);
        dbConfig.getConnection();
    }

    /**
     * Проверка на попытку обращения к базе после закрытия соединения
     * @throws SQLException
     */
    @Test(expected = SQLException.class)
    public void closeConnection_SQLException() throws SQLException {
        dbConfig = new DbConfig(url, null, null);

        Connection connection = dbConfig.getConnection();
        dbConfig.closeConnection();
        dbConfig.closeConnection();
        dbConfig = null;

        Statement statement = connection.createStatement();
    }
}