package ru.rosbank.automation.utils;

import org.junit.Test;
import ru.rosbank.automation.classes_for_tests.TestClass;
import ru.sbtqa.tag.qautils.errors.AutotestError;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import static org.junit.Assert.*;

public class ReflectionUtilsTest {
    private static Integer newValue = 1;
    private static String aa = "one";
    private static final TestClass testClassObject = new TestClass();

    /**
     * Проверяет переопределение поля класса
     */
    @Test
    public void resetStaticField() {
        ReflectionUtils.resetStaticField("A", newValue, TestClass.class);
        assertEquals(newValue,TestClass.getA());
    }

    /**
     * Проверяет переопределение поля объекта
     */
    @Test
    public void resetField() {
        assertEquals(Integer.valueOf(0),testClassObject.B);
        ReflectionUtils.resetField("B", newValue, testClassObject);
        assertEquals(newValue,testClassObject.B);

    }

    /**
     * Проверяет определение наличия static поля
     */
    @Test
    public void fieldExists() {
        assertTrue(ReflectionUtils.fieldExists(TestClass.class, "A", Integer.class));
        assertFalse(ReflectionUtils.fieldExists(TestClass.class, "B", Integer.class));
    }

    /**
     * Проверяет уборку модификатора final
     */
    @Test
    public void turnOffFinalModifier() {
        try {
            Field field = TestClass.class.getField("C");
            assertEquals((field.getModifiers() & Modifier.STATIC), Modifier.STATIC);
            assertEquals((field.getModifiers() & Modifier.PUBLIC), Modifier.PUBLIC);
            assertEquals((field.getModifiers() & Modifier.FINAL), Modifier.FINAL);
            ReflectionUtils.turnOffFinalModifier(field);
            assertEquals((field.getModifiers() & Modifier.STATIC), Modifier.STATIC);
            assertEquals((field.getModifiers() & Modifier.PUBLIC), Modifier.PUBLIC);
            assertNotEquals((field.getModifiers() & Modifier.FINAL), Modifier.FINAL);

        }catch(NoSuchFieldException e){
          throw new AutotestError("Не найдено поле");
        }

    }
}