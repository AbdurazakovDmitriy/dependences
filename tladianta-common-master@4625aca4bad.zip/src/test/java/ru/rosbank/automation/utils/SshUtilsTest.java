package ru.rosbank.automation.utils;

import org.junit.Test;

import java.io.IOException;
public class SshUtilsTest {

    /**
     * Проверка обращения к незапущенному серверу
     * @throws IOException - возникающие исключения
     */
    @Test(expected = IOException.class)
    public void executeCommand() throws IOException {
        String result = SshUtils.executeCommand("test", "");
    }
}