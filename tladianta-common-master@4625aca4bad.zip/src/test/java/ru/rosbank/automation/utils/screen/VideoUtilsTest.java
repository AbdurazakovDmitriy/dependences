package ru.rosbank.automation.utils.screen;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;
import ru.rosbank.automation.classes_for_tests.TestLogAppender;
import ru.rosbank.automation.configuration.CommonConfiguration;
import ru.sbtqa.tag.videorecorder.VideoRecorder;

import java.lang.reflect.Field;
import java.util.Map;

import static org.junit.Assert.*;

public class VideoUtilsTest {
    private static CommonConfiguration PROPERTIES;

    /**
     * Выполняется перед всеми тестами: инициализация VideoUtils
     */
    @BeforeClass
    public static void beforeClass() throws NoSuchFieldException, IllegalAccessException {
        VideoUtils.create();

        Field field = VideoUtils.class.getDeclaredField("PROPERTIES");
        field.setAccessible(true);
        PROPERTIES = (CommonConfiguration) field.get(null);
    }

    /**
     * Выполняется после каждого теста
     */
    @After
    public void after() {
        VideoUtils.stopRecord();
    }

    /**
     * Проверка, что экземпляр VideoUtils - создан
     */
    @Test
    public void create() {
        Map.Entry<String, VideoUtils> instance = VideoUtils.instances.entrySet().iterator().next();
        assertEquals("Default", instance.getKey());
        assertEquals(VideoUtils.class, instance.getValue().getClass());
    }

    /**
     * Проверка, что запись стартует
     */
    @Test
    public void startRecord()  {
        assertFalse(VideoRecorder.isVideoRecording());

        PROPERTIES.setProperty("video.enabled", "false");

        VideoUtils.startRecord();
        assertFalse(VideoRecorder.isVideoRecording());
        assertEquals("Запись видео отключена в настройках. Видеорекордер не запущен.", TestLogAppender.getLoggingEventList().get(0).getMessage() );
        assertEquals("Попытка стартовать видеорекордер: Default", TestLogAppender.getLoggingEventList().get(1).getMessage() );

        PROPERTIES.setProperty("video.enabled", "true");

        VideoUtils.startRecord();
        assertTrue(VideoRecorder.isVideoRecording());
        assertEquals("Видеорекордер запущен.", TestLogAppender.getLoggingEventList().get(0).getMessage());
        assertEquals("Video recording started", TestLogAppender.getLoggingEventList().get(1).getMessage());
        assertEquals("Попытка стартовать видеорекордер: Default", TestLogAppender.getLoggingEventList().get(2).getMessage());

        VideoUtils.startRecord();
        assertTrue(VideoRecorder.isVideoRecording());
        assertEquals("Видеорекордер уже запущен.", TestLogAppender.getLoggingEventList().get(0).getMessage());
        assertEquals("Попытка стартовать видеорекордер: Default", TestLogAppender.getLoggingEventList().get(1).getMessage());
    }

    /**
     * Проверка что запись останавливается
     */
    @Test
    public void stopRecord() {

        PROPERTIES.setProperty("video.enabled", "false");

        VideoUtils.stopRecord();
        assertFalse(VideoRecorder.isVideoRecording());
        assertEquals("Запись видео отключена в настройках. Видеорекордер не был запущен.", TestLogAppender.getLoggingEventList().get(0).getMessage());
        assertEquals("Попытка остановки видеорекордера: Default", TestLogAppender.getLoggingEventList().get(1).getMessage());

        PROPERTIES.setProperty("video.enabled", "true");

        VideoUtils.startRecord();
        assertTrue(VideoRecorder.isVideoRecording());
        assertEquals("Видеорекордер запущен.", TestLogAppender.getLoggingEventList().get(0).getMessage());
        assertEquals("Video recording started", TestLogAppender.getLoggingEventList().get(1).getMessage());
        assertEquals("Попытка стартовать видеорекордер: Default", TestLogAppender.getLoggingEventList().get(2).getMessage());

        VideoUtils.stopRecord();
        assertFalse(VideoRecorder.isVideoRecording());
        assertEquals("Видеорекордер остановлен.", TestLogAppender.getLoggingEventList().get(0).getMessage());
        assertTrue(((String)TestLogAppender.getLoggingEventList().get(1).getMessage()).contains("Video saved as"));
        assertEquals("Video recording stopped", TestLogAppender.getLoggingEventList().get(2).getMessage() );
        assertEquals("Попытка остановки видеорекордера: Default", TestLogAppender.getLoggingEventList().get(3).getMessage());
    }
}