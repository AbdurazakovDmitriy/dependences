package ru.rosbank.automation.configuration.loader;

import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Properties;

import static org.junit.Assert.assertEquals;

public class ConfigLoaderImplTest {

    private static ConfigLoader configLoader = null;
    private static Properties props;
    private final static String[] arrayKeys = {"keyA", "keyB", "keyC", "keyD", "keyE", "keyF"};

    private static String appApp;
    private static String cert;
    private static String app;
    private static String test;

    /**
     * Выполняется пред всеми тестами
     */
    @BeforeClass
    public static void beforeClass() throws Exception {
        configLoader = ConfigLoaderImpl.class.getConstructor().newInstance();

        appApp = "App.app";
        cert = "Cert";
        app = "App";
        test = "Test";
    }

    /**
     * Проверка подгружаемых значений loadModuleConfiguration с 2я параметрами
     */
    @Test
    public void loadModuleConfiguration_2params() {
        props = configLoader.loadModuleConfiguration("cert", "");

        assertEquals("value2", props.getProperty(arrayKeys[0]));
        assertEquals("value2", props.getProperty(arrayKeys[1]));
        assertEquals("value3", props.getProperty(arrayKeys[2]));
        assertEquals("value1", props.getProperty(arrayKeys[3]));
        assertEquals("value2", props.getProperty(arrayKeys[4]));
        assertEquals("value1", props.getProperty(arrayKeys[5]));
        assertEquals("1", props.getProperty(app));
        assertEquals("1", props.getProperty(appApp));
        assertEquals("1", props.getProperty(cert));

        props = configLoader.loadModuleConfiguration("cert", "config/test.properties");

        assertEquals("value2", props.getProperty(arrayKeys[0]));
        assertEquals("value2", props.getProperty(arrayKeys[1]));
        assertEquals("value4", props.getProperty(arrayKeys[2]));
        assertEquals("value1", props.getProperty(arrayKeys[3]));
        assertEquals("value4", props.getProperty(arrayKeys[4]));
        assertEquals("value4", props.getProperty(arrayKeys[5]));
        assertEquals("1", props.getProperty(app));
        assertEquals("1", props.getProperty(appApp));
        assertEquals("1", props.getProperty(cert));
        assertEquals("1", props.getProperty(test));
    }

    /**
     * Проверка подгружаемых значений loadModuleConfiguration с 4я параметрами
     */
    @Test
    public void loadModuleConfiguration_4params() {
        props = configLoader.loadModuleConfiguration("cert", "", "testModule", "");

        assertEquals("1", props.getProperty("Cert.testModule"));
        assertEquals("1", props.getProperty("App.app.testModule"));
        assertEquals("cert", props.getProperty("key.module"));

        props = configLoader.loadModuleConfiguration("cert", "", "testModule", "testplugin");

        assertEquals("1", props.getProperty("Cert.testModule"));
        assertEquals("1", props.getProperty("App.app.testModule"));
        assertEquals("cert", props.getProperty("key.module"));
        assertEquals("1", props.getProperty("plugin.test"));
    }
}