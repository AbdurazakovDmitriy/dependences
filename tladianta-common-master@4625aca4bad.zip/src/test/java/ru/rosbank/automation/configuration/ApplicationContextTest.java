package ru.rosbank.automation.configuration;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import ru.rosbank.automation.configuration.loader.ConfigLoader;
import ru.rosbank.automation.configuration.loader.ConfigLoaderImpl;
import ru.rosbank.automation.steps.CommonSteps;

import java.util.Properties;

public class ApplicationContextTest {

    private final static String[] arrayKeys = {"Key1", "Key2", "Key3", "Key4"};
    private final static String[] arrayValues = {"Value1", "Value2", "Value3", "Value4"};
    private final static String[] arrayAppNames = {"TestSet1", "TestSet2"};

    private static Object steps1 = null;
    private static Object steps = null;

    private static Properties properties1 = null;
    private static Properties properties2 = null;

    private static ConfigLoader configLoader = null;

    /**
     * Подготовка данных перед тестам:
     * - Создание двух наборов свойств
     * - Получение configLoader
     * - Инициализация CommonSteps
     * @throws Exception - возникшие исключения
     */
    @BeforeClass
    public static void beforeClass() throws Exception {

        properties1 = new Properties();
        properties2 = new Properties();

        for(int i = 0; i < 3; i++) {
            properties1.setProperty(arrayKeys[i], arrayValues[i]);
            properties2.setProperty(arrayKeys[i], arrayValues[i]);
        }

        properties2.setProperty(arrayKeys[3], arrayValues[3]);

        configLoader = ConfigLoaderImpl.class.getConstructor().newInstance();
        steps1 = "Test Object 1";
        steps = CommonSteps.getInstance();
    }

    /**
     * После проведения всех тестов: обнуление ссылок
     */
    @AfterClass
    public static void afterClass() {
        configLoader = null;
    }

    /**
     * Проверка работы с коллекцией StepsImpl на получение:
     * - Получение по не существующему ключу
     * - Запись и получение по ключу
     * - Получение по другому не существующему ключу
     */
    @Test
    public void getStepsImpl() {

        Object testSteps = ApplicationContext.getStepsImpl("TestGetCommonSteps1");

        ApplicationContext.setStepsImpl("TestGetCommonSteps1", steps);

        Object testSteps1 = ApplicationContext.getStepsImpl("TestGetCommonSteps1");
        Object testSteps2 = ApplicationContext.getStepsImpl("WrongKey");

        Assert.assertNull(testSteps);
        Assert.assertEquals(steps, testSteps1);
        Assert.assertNull(testSteps2);
    }

    /**
     * Проверка работы с коллекцией StepsImpl на запись:
     * - Запись по двум ключам
     * - Получение и сравнение по двум ключам
     */
    @Test
    public void setStepsImpl() {

        ApplicationContext.setStepsImpl("TestSetCommonSteps1", steps);

        ApplicationContext.setStepsImpl("TestSetCommonSteps2", steps1);

        Object testSteps = ApplicationContext.getStepsImpl("TestSetCommonSteps1");

        Object testSteps2 = ApplicationContext.getStepsImpl("TestSetCommonSteps2");

        Assert.assertEquals(steps, testSteps);
        Assert.assertEquals(steps1, testSteps2);
    }

    /**
     * Проверка установки и получения ConfigLoader:
     * - получение null
     */
    @Test
    public void get_set_ConfigLoader_null() {

        ApplicationContext.setConfigLoader(null);

        Object testLoader1 = ApplicationContext.getConfigLoader();

        Assert.assertNull(testLoader1);
    }

    /**
     * Проверка установки и получения ConfigLoader:
     * - получение действаительного экземпляра
     */
    @Test
    public void get_set_ConfigLoader() {

        ApplicationContext.setConfigLoader(configLoader);

        Object testLoader2 = ApplicationContext.getConfigLoader();

        Assert.assertEquals(configLoader, testLoader2);
    }

    /**
     * Проверка получения AppProperties: запись по имени, получение и проверка на соответствие
     */
    @Test
    public void getAppProperties() {
        ApplicationContext.setAppProperties(arrayAppNames[0], properties1);

        Properties properties = ApplicationContext.getAppProperties().get(arrayAppNames[0]);

        for(int i = 0; i < 3; i++) {
            Assert.assertEquals(properties.getProperty(arrayKeys[i]), arrayValues[i]);
        }
    }

    /**
     * Проверка записи AppProperties:
     * - Запись по ключу и проверка
     * - Повторная запись по ключу и проверка
     * - Запись по другому ключу, проверка на увеличение кол-ва записей на еденицу, проверка
     */
    @Test
    public void setAppProperties() {

        ApplicationContext.setAppProperties(arrayAppNames[0], properties1);
        Assert.assertEquals(ApplicationContext.getAppProperties().get(arrayAppNames[0]), properties1);

        ApplicationContext.setAppProperties(arrayAppNames[0], properties2);
        Assert.assertEquals(ApplicationContext.getAppProperties().get(arrayAppNames[0]), properties2);

        int size = ApplicationContext.getAppProperties().size();
        ApplicationContext.setAppProperties(arrayAppNames[1], properties1);
        Assert.assertEquals(ApplicationContext.getAppProperties().size(), size + 1);
        Assert.assertEquals(ApplicationContext.getAppProperties().get(arrayAppNames[1]), properties1);
    }
}