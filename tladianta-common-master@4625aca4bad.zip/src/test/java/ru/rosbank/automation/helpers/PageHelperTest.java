package ru.rosbank.automation.helpers;

import org.junit.Test;
import ru.rosbank.automation_test.pages.*;

import java.util.Set;

import static org.junit.Assert.assertTrue;

public class PageHelperTest {

    /**
     * Проверка на поиск родителя и родителя родителя
     */
    @Test
    public void SuperclassTest() {
        Set<String> superclasses = PageHelper.getPageSuperclasses(testPage3.class);
        assertTrue(superclasses.contains(testPage2.class.getName()));
        assertTrue(superclasses.contains(testPage1.class.getName()));
        assertTrue(superclasses.contains(testPage3.class.getName()));
        superclasses = PageHelper.getPageSuperclasses(testPage6.class);
        assertTrue(superclasses.contains(testPage5.class.getName()));
        assertTrue(superclasses.contains(testPage6.class.getName()));
        superclasses = PageHelper.getPageSuperclasses(testPage7.class);
        assertTrue(superclasses.contains(testPage7.class.getName()));
    }
}
