package ru.rosbank.automation.helpers;

import org.apache.commons.io.FileUtils;
import org.junit.*;
import org.jutils.jprocesses.model.ProcessInfo;
import ru.sbtqa.tag.pagefactory.exceptions.FactoryRuntimeException;

import java.io.File;
import java.io.IOException;
import java.util.List;

import static org.junit.Assert.*;

public class SystemHelperImplTest {
    private static String PROCESS;
    private static String PROCESS_FULL;
    private static final String PROCESS_WRONG = "wrong";

    /**
     * Выполняется перед всеми тестами: копирование black.exe в текущий католог
     * @throws IOException - возникающие исключения
     */
    @BeforeClass
    public static void beforeClass() throws IOException {
        String executablePath = SystemHelperImplTest.class.getClassLoader().getResource("executable/black.exe").getPath()
                .replaceFirst("/", "")
                .replace("%20", " ");
        String currentDir = new java.io.File( "." ).getCanonicalPath();
        String[] array = executablePath.split("[\\/\\\\]");
        PROCESS = array[array.length - 1];
        PROCESS_FULL = currentDir + File.separator + PROCESS;

        File source = new File(executablePath);
        File dest = new File(PROCESS_FULL);
        FileUtils.copyFile(source, dest);
    }

    /**
     * Выполняется после всех тестов: удаление black.exe из текщего каталога
     * @throws IOException - возникающие исключения
     */
    @AfterClass
    public static void afterClass() {
        FileUtils.deleteQuietly(new File(PROCESS_FULL));
    }

    /**
     * Выполняется перед каждым тестом: убить процессы black.exe
     */
    @Before
    public void before()  {
        SystemHelperImpl.getInstance().killProcess(PROCESS);
    }

    /**
     * Выполняется после каждого теста: убить процессы black.exe
     */
    @After
    public void after() {
        SystemHelperImpl.getInstance().killProcess(PROCESS);
    }

    /**
     * Тест получения экземпляра: проверка что возвращается один (singleton)
     */
    @Test
    public void getInstance() {
        SystemHelper helper1 = SystemHelperImpl.getInstance();
        SystemHelper helper2 = SystemHelperImpl.getInstance();
        assertEquals(helper1, helper2);
    }

    /**
     * Тест получения процессов по имени приложения и по строке запуска
     */
    @Test
    public void getProcesses() {
        List<ProcessInfo> list = SystemHelperImpl.getInstance().getProcesses(PROCESS);
        assertEquals(0, list.size());

        SystemHelperImpl.getInstance().runCommand(PROCESS);
        SystemHelperImpl.getInstance().runCommand(PROCESS_FULL);

        list = SystemHelperImpl.getInstance().getProcesses(PROCESS);
        assertEquals(2, list.size());

        list = SystemHelperImpl.getInstance().getProcesses(PROCESS_FULL);
        assertEquals(1, list.size());

        SystemHelperImpl.getInstance().killProcess(PROCESS);
    }

    /**
     * Тест получения всех приложений
     */
    @Test
    public void getProcesses_all() {
        List<ProcessInfo> listBefore = SystemHelperImpl.getInstance().getProcesses();
        assertNotEquals(0, listBefore.size());

        int countBefore = 0;
        for (ProcessInfo info : listBefore) {
            if(info.getCommand().equals(PROCESS)) {
                countBefore++;
            }
        }

        SystemHelperImpl.getInstance().runCommand(PROCESS);
        SystemHelperImpl.getInstance().runCommand(PROCESS);
        List<ProcessInfo> listAfter = SystemHelperImpl.getInstance().getProcesses();

        int countAfter = 0;
        for (ProcessInfo info : listAfter) {
            if(info.getCommand().equals(PROCESS)) {
                countAfter++;
            }
        }

        assertEquals(countBefore + 2, countAfter);
    }

    /**
     * Провека активности процесса
     */
    @Test
    public void isProcessActive() {
        assertFalse(SystemHelperImpl.getInstance().isProcessActive(PROCESS));
        SystemHelperImpl.getInstance().runCommand(PROCESS);
        assertTrue(SystemHelperImpl.getInstance().isProcessActive(PROCESS));
    }

    /**
     * Проверка запуска процесса
     */
    @Test
    public void runCommand() {
        List<ProcessInfo> listBefore = SystemHelperImpl.getInstance().getProcesses(PROCESS);
        SystemHelperImpl.getInstance().runCommand(PROCESS);
        List<ProcessInfo> listAfter = SystemHelperImpl.getInstance().getProcesses(PROCESS);
        assertEquals(listBefore.size() + 1, listAfter.size());

        SystemHelperImpl.getInstance().killProcess(PROCESS);
    }

    /**
     * Проверка запуска несуществующего процесса
     */
    @Test(expected = FactoryRuntimeException.class)
    public void runCommand_FactoryRuntimeException() {
        SystemHelperImpl.getInstance().runCommand(PROCESS_WRONG);
    }

    /**
     * Проверка убивания процесса
     */
    @Test
    public void killProcess() {
            SystemHelperImpl.getInstance().runCommand(PROCESS);
            SystemHelperImpl.getInstance().runCommand(PROCESS);
            List<ProcessInfo> list = SystemHelperImpl.getInstance().getProcesses(PROCESS);
            assertNotEquals(0, list.size());

            SystemHelperImpl.getInstance().killProcess(PROCESS);
            list = SystemHelperImpl.getInstance().getProcesses(PROCESS);
            assertEquals(0, list.size());

    }
}