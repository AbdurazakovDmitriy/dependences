package ru.rosbank.automation_test;

import cucumber.api.CucumberOptions;
import ru.sbtqa.tag.pagefactory.Tag;

//@RunWith(Cucumber.class)
@CucumberOptions(monochrome = true, plugin = {"pretty"},
        glue = {"ru.rosbank.automation.stepdefs"},
        features = {"src/test/resources/features"},
        tags = {"@Desktop_test"})
public class CommonTest extends Tag {
}