package ru.rosbank.automation_test.pages;


import ru.sbtqa.tag.pagefactory.Page;

public abstract class testPage1 implements Page {

}
