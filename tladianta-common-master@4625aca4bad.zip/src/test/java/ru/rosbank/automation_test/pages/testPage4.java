package ru.rosbank.automation_test.pages;


import ru.sbtqa.tag.pagefactory.Page;

public interface testPage4 extends Page {

}
