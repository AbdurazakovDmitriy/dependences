package ru.rosbank.automation_test.pages;

public abstract class testPage2 extends testPage1 {

}
