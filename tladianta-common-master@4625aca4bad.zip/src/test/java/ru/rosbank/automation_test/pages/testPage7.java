package ru.rosbank.automation_test.pages;


public interface testPage7 extends testPage4 {

}
