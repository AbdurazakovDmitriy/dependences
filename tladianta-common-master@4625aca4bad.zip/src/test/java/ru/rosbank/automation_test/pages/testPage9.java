package ru.rosbank.automation_test.pages;

import ru.rosbank.automation.annotations.ClassAnnotation;

@ClassAnnotation(title = "Test page")
public class testPage9 {
}
