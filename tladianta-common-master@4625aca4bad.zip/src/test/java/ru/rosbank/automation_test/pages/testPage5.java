package ru.rosbank.automation_test.pages;

public abstract class testPage5 implements testPage4 {

}
