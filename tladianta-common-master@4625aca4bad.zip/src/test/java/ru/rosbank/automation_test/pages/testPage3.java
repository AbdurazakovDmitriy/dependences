package ru.rosbank.automation_test.pages;


public class testPage3 extends testPage2 {
}
