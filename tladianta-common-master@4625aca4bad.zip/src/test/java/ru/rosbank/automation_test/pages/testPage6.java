package ru.rosbank.automation_test.pages;

public abstract class testPage6 extends testPage5 implements testPage4 {

}
