package ru.rosbank.automation.allure;

public enum Type {
    TEXT("text/plain", ".txt"),
    HTML("text/html", ".html"),
    CSV("text/csv", ".csv"),
    URI("text/uri-list", ".uri"),

    XML("application/xml", ".xml"),
    TARGZIP("application/x-gtar", ".tar.gz"),
    JSON("application/json", ".json"),
    YAML("application/yaml", ".yml"),

    VIDEO("video/webm", ".webm"),
    MP4("video/mp4", ".mp4"),
    OGG("video/ogg", ".ogg"),

    PNG("image/png", ".png"),
    BMP("image/bmp",".bmp"),
    TIFF("image/tiff", ".tiff"),
    JPEG("image/jpeg", ".jpg"),
    GIF("image/gif", ".gif");

    private final String type;
    private final String extension;

    Type(final String type, final String extension) {
        this.type = type;
        this.extension = extension;
    }

    @Override
    public String toString() {
        return "MIME: " + type + " EXTENSION: " + extension;
    }

    public String getExtension() {
        return extension;
    }

    public String getType() {
        return type;
    }
}
