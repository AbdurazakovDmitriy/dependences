package ru.rosbank.automation.allure;

import lombok.extern.slf4j.Slf4j;
import org.apache.log4j.AsyncAppender;
import org.apache.log4j.spi.LoggingEvent;

/**
 * Класс для выгрузки логов в Allure
 */
@Slf4j
public class LogAppender extends AsyncAppender {

    @Override
    public void append(LoggingEvent event) {
        String name = event.getMessage().toString();
        if (!event.getLogger().getName().equals("io.qameta.allure.AllureLifecycle")) {
            switch (event.getLevel().toString()) {
                case "INFO":
                    AllureHelper.info(name);
                    break;
                case "WARN":
                    AllureHelper.warn(name);
                    break;
                case "ERROR":
                    AllureHelper.error(name);
                    break;
            }
        }
    }
}
