package ru.rosbank.automation.allure;

import io.qameta.allure.Allure;
import io.qameta.allure.AllureLifecycle;
import io.qameta.allure.model.Parameter;
import io.qameta.allure.model.Status;
import io.qameta.allure.model.StepResult;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

@Slf4j
public class AllureHelper {

    /**
     * Добавление информации про поле в виде саб-степа.
     *
     * @param fieldName название.
     * @param value     значение.
     */
    public static void logFieldInfo(@NotNull String fieldName, String value) {
        info("%s: %s", new String[]{fieldName, value});
    }

    /**
     * Добавление информации про поле в виде саб-степа со статусом PASSED.
     *
     * @param format     формат строки.
     * @param parameters параметры.
     */
    public static void info(@NotNull String format, Object[] parameters) {
        String name = String.format(format, parameters);
        info(name);
    }

    /**
     * Добавление информации про поле в виде саб-степа со статусом PASSED.
     *
     * @param name имя саб-степа.
     */
    public static void info(@NotNull String name) {
        addSubStep(name, Status.PASSED);
    }

    /**
     * Добавление информации про поле в виде саб-степа со статусом BROKEN.
     *
     * @param format     формат строки.
     * @param parameters параметры строки.
     */
    public static void warn(@NotNull String format, Object[] parameters) {
        String name = String.format(format, parameters);
        warn(name);
    }

    /**
     * Добавление информации про поле в виде саб-степа со статусом BROKEN.
     *
     * @param name имя саб-степа.
     */
    public static void warn(@NotNull String name) {
        addSubStep(name, Status.BROKEN);
    }

    /**
     * Добавление информации про поле в виде саб-степа со статусом FAILED.
     *
     * @param format     формат строки.
     * @param parameters параметры строки.
     */
    public static void error(@NotNull String format, Object[] parameters) {
        String name = String.format(format, parameters);
        error(name);
    }

    /**
     * Добавление информации про поле в виде саб-степа со статусом FAILED.
     *
     * @param name имя саб-степа.
     */
    public static void error(@NotNull String name) {
        addSubStep(name, Status.FAILED);
    }

    /**
     * Добавление информации про поле в виде саб-степа.
     *
     * @param name   имя шага.
     * @param status статус шага {@link Status}.
     */
    public static void addSubStep(@NotNull String name, Status status) {
        log.debug(name);

        AllureLifecycle cycle = Allure.getLifecycle();
        if (cycle.getCurrentTestCase().isPresent()) {
            String uuid = UUID.randomUUID().toString();
            cycle.startStep(uuid, new StepResult().setName(name).setStatus(status));
            cycle.stopStep(uuid);
        }
    }

    /**
     * Добавление параметров к шагу в виде ключ значения.
     *
     * @param name  название.
     * @param value значение.
     */
    public static void addParam(String name, String value) {
        Allure.getLifecycle().updateStep(stepResult ->
                stepResult.getParameters().add(new Parameter().setName(name).setValue(value)));
    }

    /**
     * Добавление вложений к шагу.
     *
     * @param attachment массив байтов.
     * @param title      заголовок вложения. Показывается в отчете как имя вложения.
     * @param type       тип вложения {@link Type}.
     */
    public static void addAttachment(String title, Type type, byte[] attachment) {
        addAttachment(title, type.getType(), type.getExtension(), attachment);
    }

    /**
     * Добавление вложений к шагу, если предусмотренных типов не хватает.
     *
     * @param attachment массив байтов.
     * @param title      заголовок вложения. Показывается в отчете как имя вложения.
     * @param type       тип вложения.
     * @param extension  расширение вложения.
     */
    public static void addAttachment(String title, String type, String extension, byte[] attachment) {
        Allure.getLifecycle().addAttachment(title, type, extension, attachment);
    }
}
