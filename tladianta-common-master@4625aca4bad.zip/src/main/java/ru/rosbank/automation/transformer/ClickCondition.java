package ru.rosbank.automation.transformer;

import ru.sbtqa.tag.pagefactory.transformer.ClickVariation;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class ClickCondition extends ClickVariation implements ICondition{
    public ClickCondition(String name) {
        super(name.trim().toLowerCase());
    }

    @Override
    public boolean isDoubleClick() {
        Set<String> conditions = new HashSet<>(Arrays.asList("double-click", "двойным кликом"));
        return isConditionMatch(this.name, conditions);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClickCondition that = (ClickCondition) o;
        return name.equals(that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}
