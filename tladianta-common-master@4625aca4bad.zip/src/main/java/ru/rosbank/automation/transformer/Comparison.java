package ru.rosbank.automation.transformer;

import cucumber.runtime.CucumberException;

import java.util.Arrays;

public enum Comparison {
    EQUAL("равно"),
    NOT_EQUAL("не равно"),
    MORE_THAN("больше"),
    LESS_THAN("меньше"),
    MORE_OR_EQUAL_THAN("больше или равно"),
    LESS_OR_EQUAL_THAN("меньше или равно");

    private final String name;

    Comparison(String name) {
        this.name = name;
    }

    public String getValue() {
        return this.name;
    }

    public static Comparison fromString(String name) {
        String nameTrim = name.trim();
        switch (nameTrim) {
            case "равно":
                return Comparison.EQUAL;
            case "не равно":
                return Comparison.NOT_EQUAL;
            case "больше":
            case "больше чем":
                return Comparison.MORE_THAN;
            case "меньше":
            case "меньше чем":
                return Comparison.LESS_THAN;
            case "больше или равно":
            case "не меньше":
            case "не меньше чем":
                return Comparison.MORE_OR_EQUAL_THAN;
            case "меньше или равно":
            case "не больше":
            case "не больше чем":
                return Comparison.LESS_OR_EQUAL_THAN;
            default:
                return Arrays.stream(Comparison.values())
                        .filter(type -> type.toString().equalsIgnoreCase(nameTrim))
                        .findFirst()
                        .orElseThrow(() -> new CucumberException("Incorrect enum-value in steps:" + nameTrim));
        }
    }
}
