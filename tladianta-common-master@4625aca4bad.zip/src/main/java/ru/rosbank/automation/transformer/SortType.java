package ru.rosbank.automation.transformer;

import cucumber.runtime.CucumberException;

import java.util.Arrays;

public enum SortType {
    DESCENDING_ORDER("desc"),
    ASCENDING_ORDER("asc");

    private final String name;

    SortType(String name) {
        this.name = name;
    }

    public String getValue() {
        return this.name;
    }

    public static SortType fromString(String name) {
        String nameTrim = name.trim();

        switch (nameTrim) {
            case "desc":
            case "по-убыванию":
                return SortType.DESCENDING_ORDER;
            case "asc":
            case "по-возрастанию":
                return SortType.ASCENDING_ORDER;
            default:
                return Arrays.stream(SortType.values())
                        .filter(type -> type.toString().equalsIgnoreCase(nameTrim))
                        .findFirst()
                        .orElseThrow(() -> new CucumberException("Incorrect enum-value in steps:" + nameTrim));
        }
    }
}
