package ru.rosbank.automation.transformer;

import java.util.Objects;

public class ComparisonCondition {

    private final Comparison value;

    public ComparisonCondition(String name) {
        name = name.trim();
        this.value = name.isEmpty() ? Comparison.EQUAL : Comparison.fromString(name);
    }

    public Comparison getValue() {
        return value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ComparisonCondition that = (ComparisonCondition) o;
        return value == that.value;
    }

    @Override
    public int hashCode() {
        return Objects.hash(value);
    }
}
