package ru.rosbank.automation.transformer;

import java.util.Set;

public interface ICondition {
    default boolean isConditionMatch(String name, Set<String> conditions) {
        if (name == null) {
            return false;
        }
        return conditions.stream().anyMatch(name::startsWith);
    }
}
