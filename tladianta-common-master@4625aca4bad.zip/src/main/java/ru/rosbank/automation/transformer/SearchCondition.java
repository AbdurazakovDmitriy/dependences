package ru.rosbank.automation.transformer;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import ru.sbtqa.tag.pagefactory.transformer.SearchStrategy;

import java.util.Objects;

public class SearchCondition {
    @NotNull
    private final SearchStrategy value;

    public SearchCondition(@NotNull String name) {

        String nameTrim = name.trim().toLowerCase();

        switch (nameTrim) {
            case "по частичному совпадению с":
            case "contains":
                this.value = SearchStrategy.CONTAINS;
                break;
            default:
                this.value = SearchStrategy.EQUALS;
        }

    }

    @NotNull
    @Contract(pure = true)
    public SearchStrategy getValue() {
        return value;
    }

    @Override
    @Contract(value = "null->false", pure = true)
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SearchCondition that = (SearchCondition) o;
        return value == that.value;
    }

    @Override
    public int hashCode() {
        return Objects.hash(value);
    }
}
