package ru.rosbank.automation.transformer;

import org.aeonbits.owner.util.Collections;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ru.sbtqa.tag.pagefactory.transformer.ContainCondition;
import ru.sbtqa.tag.pagefactory.transformer.Presence;

import java.util.Objects;
import java.util.Set;

public class NegationCondition implements ICondition {
    @NotNull
    protected final String name;
    @NotNull
    private final Set<String> conditions;

    public NegationCondition(@NotNull String name) {
        this.name = name.trim().toLowerCase();
        this.conditions = Collections.set("not", "не", "от");
    }

    @Contract(pure = true)
    public boolean isPositive() {
        return !isConditionMatch(this.name, this.conditions);
    }

    @Contract(pure = true)
    @NotNull
    public ContainCondition toContainCondition() {
        return this.isPositive() ? new ContainCondition("contain") : new ContainCondition("not contain");
    }

    @Contract(pure = true)
    @NotNull
    public Presence toPresence() {
        return this.isPositive() ? new Presence("отображаются") : new Presence("не отображаются");
    }

    @Override
    @Contract(value = "null->false", pure = true)
    public boolean equals(@Nullable Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NegationCondition that = (NegationCondition) o;
        return name.equals(that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}
