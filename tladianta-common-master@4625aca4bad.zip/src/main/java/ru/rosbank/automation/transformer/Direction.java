package ru.rosbank.automation.transformer;

import cucumber.runtime.CucumberException;

import java.util.Arrays;

public enum Direction {
    UP("вверх"),
    DOWN("вниз"),
    LEFT("влево"),
    RIGHT("вправо");

    private final String name;

    Direction(String name) {
        this.name = name;
    }

    public String getValue() {
        return this.name;
    }

    public static Direction fromString(String name) {
        String nameTrim = name.trim();

        switch (nameTrim) {
            case "вверх":
                return Direction.UP;
            case "вниз":
                return Direction.DOWN;
            case "влево":
                return Direction.LEFT;
            case "вправо":
                return Direction.RIGHT;
            default:
                return Arrays.stream(Direction.values())
                        .filter(type -> type.toString().equalsIgnoreCase(nameTrim))
                        .findFirst()
                        .orElseThrow(() -> new CucumberException("Incorrect enum-value in steps:" + nameTrim));
        }
    }
}
