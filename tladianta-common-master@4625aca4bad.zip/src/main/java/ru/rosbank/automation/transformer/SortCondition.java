package ru.rosbank.automation.transformer;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public class SortCondition {
    @NotNull
    private final SortType value;

    @Contract(pure = true)
    public SortCondition(@NotNull String name) {
        this.value = SortType.fromString(name);
    }

    @NotNull
    @Contract(pure = true)
    public SortType getValue() {
        return value;
    }

    @Contract(value = "null -> false", pure = true)
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SortCondition that = (SortCondition) o;
        return value == that.value;
    }

    @Override
    public int hashCode() {
        return Objects.hash(value);
    }
}
