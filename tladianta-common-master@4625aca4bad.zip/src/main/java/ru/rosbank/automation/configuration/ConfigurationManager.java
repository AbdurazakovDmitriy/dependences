package ru.rosbank.automation.configuration;

import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ru.rosbank.automation.utils.FieldValueResetter;
import ru.rosbank.automation.utils.FileUtils;
import ru.rosbank.automation.utils.ReflectionUtils;
import ru.sbtqa.tag.pagefactory.properties.Configuration;
import ru.sbtqa.tag.qautils.properties.Props;

import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.function.Supplier;

@Slf4j
public class ConfigurationManager {

    public static final String PROPERTIES = "PROPERTIES";

    private static final Set<FieldValueResetter> classesToReset = new HashSet<>();

    static {
        registerClassesForConfigReset();
    }

    @Contract(pure = true)
    private ConfigurationManager() {
    }

    /**
     * Перезаписывает в файл ресурсов "config/application.properties" переданную коллекцию свойств
     *
     * @param sourceProperties коллекция свойств, которую нужно сохранить.
     */
    public static void resetPropertyFile(@Nullable Properties sourceProperties) {
        String fileName = "config/application.properties";

        if (sourceProperties == null || sourceProperties.isEmpty()) {
            log.debug("Файл {} не перезаписан. Коллекция новых свойств пуста.", fileName);
            return;
        }

        FileUtils.writePropertiesToResource(fileName, sourceProperties);

        log.debug("Конфигурационный файл {} был перезаполнен.", fileName);
    }

    /**
     * Меняет все свойства в синглтоне {@link ru.sbtqa.tag.qautils.properties.Props}
     * Сохраняет при этом системные свойства.
     *
     * @param sourceProperties новая коллекция свойств
     */
    public static void resetProps(@NotNull Properties sourceProperties) {
        Properties props = Props.getProps();
        props.clear();
        props.putAll(sourceProperties);
    }

    /**
     * Устанавливает новое значение конифгурации стаическому полю для зарегистрированных классов:
     */
    public static void resetConfigurationInClasses() {
        classesToReset.forEach(FieldValueResetter::reset);
    }

    /**
     * <p>Добавляет класс в спиок классов, для которых будет изменено значение поля.</p>
     * Перд добавлением класс проверяется на:
     * <ul>
     *     <li>класс должен содержать указанное поле</li>
     *     <li>поле класса должно быть статическим</li>
     *     <li>поле класса должно иметь тип значения {@link Configuration}</li>
     * </ul>
     *
     * @param <T>            параметр типа значения поля
     * @param className      имя класса,в котором нужно поменять значение поля
     * @param fieldName      имя статического поля, в котором нужно поменять значение
     * @param configSupplier метод-поставщик нового значения поля
     */
    public static <T> void registerClassForReset(@NotNull String className, @NotNull String fieldName, @NotNull Supplier<T> configSupplier) {
        try {
            T t = configSupplier.get();
            Class<?> clazz = Class.forName(className);
            if (ReflectionUtils.fieldExists(clazz, fieldName, t.getClass())) {
                classesToReset.add(new FieldValueResetter<>(clazz, fieldName, configSupplier));
            } else {
                log.debug("Поля {} не существует", fieldName);
            }
        } catch (ClassNotFoundException e) {
            log.debug(String.format("Класс не найден '%s'", className), e);
        }
    }

    /**
     * Регистрирует классы из PF2 для установки нового значение конифгурации стаическому полю 'PROPERTIES' классов:
     * <ul>
     *      <li>ru.sbtqa.tag.pagefactory.PageManager</li>
     *      <li>ru.sbtqa.tag.pagefactory.allure.ErrorHandler</li>
     *      <li>ru.sbtqa.tag.pagefactory.allure.JunitReporter</li>
     *      <li>ru.sbtqa.tag.pagefactory.aspects.FragmentsAspect</li>
     *      <li>ru.sbtqa.tag.pagefactory.aspects.report.Click</li>
     *      <li>ru.sbtqa.tag.pagefactory.aspects.report.Fill</li>
     *      <li>ru.sbtqa.tag.pagefactory.aspects.report.PressKey</li>
     *      <li>ru.sbtqa.tag.pagefactory.aspects.report.Select</li>
     *      <li>ru.sbtqa.tag.pagefactory.aspects.report.SetCheckbox</li>
     *      <li>ru.sbtqa.tag.pagefactory.data.DataFactory</li>
     *      <li>ru.sbtqa.tag.pagefactory.data.DataUtils</li>
     *      <li>ru.sbtqa.tag.pagefactory.fragments.FragmentCacheUtils</li>
     *      <li>ru.sbtqa.tag.pagefactory.junit.CoreSetupSteps</li>
     *      <li>ru.sbtqa.tag.pagefactory.junit.CoreStepsImpl</li>
     *      <li>ru.sbtqa.tag.pagefactory.tasks.KillProcessesTask</li>
     *      <li>ru.sbtqa.tag.pagefactory.tasks.StartVideoTask</li>
     *      <li>ru.sbtqa.tag.pagefactory.tasks.StopVideoTask</li>
     *      <li>ru.sbtqa.tag.pagefactory.utils.Alert</li>
     *      <li>ru.sbtqa.tag.pagefactory.utils.Wait</li>
     * </ul>
     */
    private static void registerClassesForConfigReset() {

        Supplier<? extends Configuration> configSupplier = Configuration::create;

        registerClassForReset("ru.sbtqa.tag.pagefactory.allure.ErrorHandler", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.allure.JunitReporter", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.aspects.report.Click", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.aspects.report.Fill", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.aspects.report.PressKey", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.aspects.report.Select", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.aspects.report.SetCheckbox", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.aspects.report.ErrorHandlerAspect", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.aspects.FragmentsAspect", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.data.DataFactory", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.data.DataUtils", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.fragments.FragmentCacheUtils", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.junit.CoreSetupSteps", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.junit.CoreStepsImpl", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.tasks.KillProcessesTask", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.tasks.StartVideoTask", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.tasks.StopVideoTask", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.utils.Alert", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.utils.Wait", PROPERTIES, configSupplier);
        registerClassForReset("ru.sbtqa.tag.pagefactory.PageManager", PROPERTIES, configSupplier);


    }

}
