package ru.rosbank.automation.configuration;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ru.rosbank.automation.configuration.loader.ConfigLoader;
import ru.rosbank.automation.utils.FileUtils;
import ru.sbtqa.tag.pagefactory.Page;
import ru.sbtqa.tag.pagefactory.PageManager;
import ru.sbtqa.tag.pagefactory.context.PageContext;
import ru.sbtqa.tag.qautils.properties.Props;

import java.lang.reflect.InvocationTargetException;
import java.util.*;


@Slf4j
public class ApplicationManager {

    private static final ThreadLocal<Map<String, List<Runnable>>> resetActions = ThreadLocal.withInitial(HashMap::new);

    @Contract(pure = true)
    private ApplicationManager() {
    }

    /**
     * <p>Заполняет список настроек текущего и гостевых модулей, исходя из описания модулей в свойствах текущего модуля</p>
     * <p>'props.&lt;имя приложения&gt;' - имя модуля гостевого приложения, из которого будут загружены .properties файлы</p>
     * <p>'props.&lt;имя приложения&gt;.custom' - список относительных путей к произвольным файлам .properties, через запятую без пробелов</p>
     * Пример:
     * <pre>
     * app.name = internet-bank
     * props.bis = bis-ui-tests
     * props.bis.custom = config/my1.properties,custom/my2.properties</pre>
     *
     * <p>затем по значению свойства 'app.name' в каждом модуле запоминает его коллекцию свойств</p>
     */
    public static void initApplicationsProperties() {

        if (ApplicationContext.getAppProperties().isEmpty()) {

            String env = System.getProperty("env", "cert");
            String appCustomConfigFiles = System.getProperty("CustomConfigFiles", "");

            determineConfigLoader();

            ConfigLoader configLoader = ApplicationContext.getConfigLoader();

            Properties appConfiguration = configLoader.loadModuleConfiguration(env, appCustomConfigFiles);

            ConfigurationManager.resetProps(appConfiguration);

            saveProperties(appConfiguration);

            String[] guestModules = appConfiguration.getProperty("guest.modules", "").split("[,;]");

            for (String moduleName : guestModules) {

                if (moduleName.trim().isEmpty()) {
                    continue;
                }

                log.info("Загружаю конфигурацию модуля {}", moduleName);

                Properties moduleApplicationProperties = FileUtils.loadPropertiesFromResource(String.format("config-%s/application.properties", moduleName));

                String customConfigFiles = appConfiguration.getProperty(String.format("%s.custom.props", moduleName), "");

                String customConfigLoader = moduleApplicationProperties.getProperty("config.loader", "");
                String customPluginName = moduleApplicationProperties.getProperty("plugin", "");

                ConfigLoader guestConfigLoader = createConfigLoader(customConfigLoader);
                if (guestConfigLoader == null) {
                    guestConfigLoader = configLoader;
                }

                Properties guestAppProperties = guestConfigLoader.loadModuleConfiguration(env, customConfigFiles, moduleName, customPluginName);
                saveProperties(guestAppProperties);
            }

        }
    }

    /**
     * Если в проекте подключены гостевые модули, принудительно инициализирует контекст текущего модуля и его плагина
     */
    public static void initDefaultContext() {
        CommonConfiguration configuration = CommonConfiguration.create();

        ConfigurationManager.resetConfigurationInClasses();

        runResetActions(configuration.getPlugin());
        runResetActions(configuration.getAppName());
    }


    /**
     * <p>Переключает контекст выполнения шагов и формирования страниц на контекст указанного модуля (appName)</p>
     * <ol>
     * <li>Заменяет файл настроек config/application.properties настройками указанного модуля,
     * собранными методом {@link ConfigLoader#loadModuleConfiguration(String, String, String, String)}</li>
     * <li>В качестве текущей страницы устанавливает страницу-пустышку с пустым заголовком, что равнозначно тому, что текущая страница не установлена.</li>
     * <li>Пересобирает репозиторий страниц, исходя из измененных настроек (п.1)</ol></li>
     *
     * @param appName имя модуля, тестирующего гостевое приложение
     */
    public static void resetApplicationContext(@NotNull String appName) {

        Properties moduleProperties = ApplicationContext.getAppProperties(appName);
        String pluginName = moduleProperties.getProperty("plugin", "default");

        // выгрузить свойства нужного модуля в файл config/application.properties
        ConfigurationManager.resetProps(moduleProperties);

        // заменить везде объект Configuration
        ConfigurationManager.resetConfigurationInClasses();

        // переключить на контекст плагина
        runResetActions(pluginName);

        // переключить на контекст модуля
        runResetActions(appName);
    }

    /**
     * Последовательно выполняет все методы из списка для контекста конкретного плагина
     *
     * @param contextName имя плагина, имя контекста
     */
    private static void runResetActions(@NotNull String contextName) {
        List<Runnable> resetActions = getResetActions(contextName);
        if (resetActions == null || resetActions.size() == 0) {
            log.debug("Нет действий для переключения на контекст '{}'", contextName);
            return;
        }
        resetActions.forEach(Runnable::run);
    }

    /**
     * Пересоздает репозиторий страниц
     */
    public static void resetPageRepository() {
        PageManager.getPageRepository().clear();
        PageManager.cachePages();
    }

    /**
     * Сбрасывает текущую страницу
     */
    public static void resetCurrentPage() {
        Page dummyPage = new Page() {
            @Override
            public String getTitle() {
                return "";
            }
        };

        PageContext.setCurrentPage(dummyPage);
    }

    /**
     * Добавляет для конкретного плагина метод, который нужно выполнить при переключении контекста модуля
     *
     * @param contextName имя контекста/плагина
     * @param action      метод
     */
    public static void addResetAction(@NotNull String contextName, @NotNull Runnable action) {
        Optional.ofNullable(getResetActions(contextName)).ifPresent(actions -> actions.add(action));
    }

    @Nullable
    @Contract(pure = true)
    public static List<Runnable> getResetActions(@NotNull String contextName) {
        return contextName.isEmpty() ? null
                : resetActions.get().computeIfAbsent(contextName, k -> new ArrayList<>());
    }

    /**
     * Сохраняет коллекцию свойств в {@link ApplicationContext}.
     * В переданной коллекции долно быть свойство {@code app.name}.
     *
     * @param properties коллекция свойств, которую нужно сохранить
     */
    private static void saveProperties(@NotNull Properties properties) {
        String appName = properties.getProperty("app.name", "");
        if (appName.isEmpty()) {
            log.debug("Настройки для приложения не содержат свойства 'app.name'. Настройки не загружены.");
        } else {
            ApplicationContext.setAppProperties(appName, properties);
        }
    }

    /**
     * Пытается создать и сохранить экземпляр {@link ConfigLoader}, полный путь к реализации которого указан {@code config/application.properties}
     * в свойстве {@code config.loader}
     */
    private static void determineConfigLoader() {
        ConfigLoader configLoader = createConfigLoader(Props.get("config.loader", ""));
        if (configLoader != null) {
            ApplicationContext.setConfigLoader(configLoader);
        } else {
            log.info("Использован ConfigLoader по-умолчанию для загрузки конфигурации текущего модуля.");
        }
    }

    /**
     * Создает экземпляр {@link ConfigLoader} по имени класа реализации
     *
     * @param configLoaderClassName имя класса реализации интерфейса {@link ConfigLoader}
     * @return экземпляр класа реализации лоадера
     */
    @Nullable
    private static ConfigLoader createConfigLoader(@NotNull String configLoaderClassName) {
        ConfigLoader configLoader = null;
        if (!configLoaderClassName.isEmpty()) {
            try {
                configLoader = (ConfigLoader) Class.forName(configLoaderClassName).getConstructor().newInstance();
                log.info("Загружен ConfigLoader: {}", configLoaderClassName);
            } catch (InstantiationException | IllegalAccessException | InvocationTargetException | NoSuchMethodException | ClassNotFoundException e) {
                log.info("Не найден класс с указанным именем: {}.\\n", configLoaderClassName);
            }
        }
        return configLoader;
    }

}
