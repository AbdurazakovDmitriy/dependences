package ru.rosbank.automation.configuration;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ru.rosbank.automation.configuration.loader.ConfigLoader;
import ru.rosbank.automation.configuration.loader.ConfigLoaderImpl;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Клас хранит контекст, общий для всех модулей и плагинов
 */
public class ApplicationContext {
    /**
     * <p>Коллекция объектов с методами реализации шагов</p>
     * <p>Инициализируется в {@code @Before}-методах</p>
     * <p>Ключом выступает имя родительского класса</p>
     * Например,
     * <ul>
     *     <li>{@code CoreStepsImpl} - имя родительского класса с реализацией методов шагов, общих для всех плагинов</li>
     *     <li>{@code CommonSteps} - имя родительского класса с реализацией методов дополнительных шагов общих для всех плагинов</li>
     * </ul>
     */
    private static final ThreadLocal<Map<String, Object>> stepsImpl = ThreadLocal.withInitial(HashMap::new);

    /**
     * Объект, реализующий логику загрузки свойств онфигурации
     */
    private static final ThreadLocal<ConfigLoader> configLoader = ThreadLocal.withInitial(ConfigLoaderImpl::new);

    /**
     * Коллекция свойств модулей: текущего и гостевых (если есть). Ключ - значение свойства {@code app.name}
     */
    private static final ThreadLocal<Map<String, Properties>> appProperties = ThreadLocal.withInitial(HashMap::new);

    /**
     * Возвращает по ключу из контекста текущий объекта с реализацией методов шагов.
     *
     * @param key имя родительского класса
     * @return объект с реализацией методов шагов
     */
    @Contract(pure = true)
    public static Object getStepsImpl(@NotNull String key) {
        return stepsImpl.get().get(key);
    }

    /**
     * Сохраняет в контекст объект с методами реализации шагов
     *
     * @param key          имя родительского класса
     * @param newStepsImpl объект с реализацией методов шагов
     */
    public static void setStepsImpl(@NotNull String key, @Nullable Object newStepsImpl) {
        stepsImpl.get().put(key, newStepsImpl);
    }

    @Contract(pure = true)
    public static ConfigLoader getConfigLoader() {
        return configLoader.get();
    }

    public static void setConfigLoader(@NotNull ConfigLoader loader) {
        configLoader.set(loader);
    }

    @Contract(pure = true)
    public static Map<String, Properties> getAppProperties() {
        return appProperties.get();
    }

    @Contract(pure = true)
    @NotNull
    public static Properties getAppProperties(@NotNull String appName) {
        return appProperties.get().get(appName);
    }

    public static void setAppProperties(@NotNull String appName, @NotNull Properties properties) {
        appProperties.get().put(appName, properties);
    }

    public static boolean hasAppProperties(@NotNull String appName) {
        return appProperties.get().containsKey(appName);
    }
}
