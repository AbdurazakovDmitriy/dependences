package ru.rosbank.automation.configuration;

import org.aeonbits.owner.Mutable;
import ru.sbtqa.tag.pagefactory.properties.Configuration;

public interface CommonConfiguration extends Configuration, Mutable {

    /**
     * @return имя модуля, используется для переключения контекста в шагах
     */
    @Key("app.name")
    @DefaultValue("")
    String getAppName();

    @Key("plugin")
    @DefaultValue("")
    String getPlugin();

    /**
     * @return Количество попыток завершения одного процесса из списка tasks.to.kill
     */
    @Key("task.kill.attempts")
    @DefaultValue("3")
    int getTaskKillAttempts();

    /**
     * @return Общее время (сек) на завершение одного процесса из списка tasks.to.kill
     */
    @Key("task.kill.timeout")
    @DefaultValue("5")
    int getTaskKillTimeout();

    /**
     * @return
     * FAIL - прикреплять видео к Allure отчету только если сценарий в статусе FAIL
     * ALWAYS - всегда прикреплять видео к Allure отчет
     */
    @Key("video.attach.flag")
    @DefaultValue("FAIL")
    String getVideoAttachFlag();

    @Key("${hostName}.ssh.host")
    String getSshHostName();

    @Key("${hostName}.ssh.user")
    String getSshHostUser();

    @Key("${hostName}.ssh.pass")
    String getSshHostPass();

    /**
     * Подключение к Alm reporter
     * @return свойства подключения
     */
    @Key("alm.url")
    String almUrl();

    @Key("alm.domain")
    String almDomain();

    @Key("alm.project")
    String almProject();

    @Key("alm.username")
    String almUsername();

    @Key("alm.password")
    String almPassword();

    /**
     * Путь по умолчанию для xml файлов
     */
    @Key("xml.path")
    String getXmlPath();

    static CommonConfiguration create() {
        return Configuration.init(CommonConfiguration.class);
    }
}
