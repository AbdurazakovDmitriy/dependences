package ru.rosbank.automation.configuration.loader;

import lombok.extern.slf4j.Slf4j;
import ru.rosbank.automation.utils.FileUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

@Slf4j
public final class ConfigLoaderImpl implements ConfigLoader {

    /**
     * Последовательно загружает файлы свойств текущего модуля:
     * <ol>
     * <li><span style='color:green;'>config/app/application.properties</span> - с настройками модуля</li>
     * <li><span style='color:green;'>config/app/&lt;env&gt;.properties</span> - с настройками среды выполнения</li>
     * <li>произвольные файлы настроек в том порядке, в котором они указаны в {@code -DCustomConfigFiles} через запятую без пробелов</li>
     * </ol>
     * <p>
     * Свойства каждого следующего файла перезаписывают свойства предыдущего.
     * Перезаписываются свойства, совпадающие по ключу.
     *
     * @param env               имя окружения - значение параметра командной строки {@code -Denv}
     * @param customConfigFiles - список относительных путей к произвольным файлам ресурсов через запятую без пробелов.
     *                          Для текущего модуля - значение параметра командной строки {@code -DCustomConfigFiles}
     * @return коллекция свойств
     */
    @Override
    public Properties loadModuleConfiguration(String env, String customConfigFiles) {
        Properties applicationProps = FileUtils.loadPropertiesFromResource("config/application.properties");
        List<String> resourceList = getResourceList(env, customConfigFiles, getPathPrefix(""), applicationProps.getProperty("plugin", ""));
        return loadConfiguration(env, resourceList);
    }

    /**
     * Последовательно загружает файлы свойств гостевого модуля:
     * <ol>
     * <li><span style='color:green;'>config/app-Имя модуля/application.properties</span> - с настройками модуля</li>
     * <li><span style='color:green;'>config/app-Имя модуля/&lt;env&gt;.properties</span> - с настройками среды выполнения</li>
     * <li>произвольные файлы настроек в том порядке, в котором они указаны в {@code -DCustomConfigFiles} через запятую без пробелов</li>
     * </ol>
     * <p>
     * Свойства каждого следующего файла перезаписывают свойства предыдущего.
     * Перезаписываются свойства, совпадающие по ключу.
     *
     * @param env               имя окружения - значение параметра командной строки {@code -Denv}
     * @param customConfigFiles - список относительных путей к произвольным файлам ресурсов через запятую без пробелов.
     *                          Для текущего модуля - значение параметра командной строки {@code -DCustomConfigFiles}
     * @param moduleName        имя гостевого модуля ({@code artifactid} из POM-файла этого модуля)
     * @param pluginName        имя плагина гостевого модуля
     * @return коллекция свойств
     */
    @Override
    public Properties loadModuleConfiguration(String env, String customConfigFiles, String moduleName, String pluginName) {
        List<String> resourceList = getResourceList(env, customConfigFiles, getPathPrefix(moduleName), pluginName);
        resourceList.removeIf((item) -> item.equals("config/application.properties"));
        return loadConfiguration(env, resourceList);
    }

    /**
     * Загружает свойства из ресурсов по списку.
     * Каждый следующий файл перезаписывает свойства предыдущего по совпадающим ключам
     *
     * @param env          имя окружения
     * @param resourceList список относительных путей ресурсов
     * @return коллеция загруженных свойств
     */
    private Properties loadConfiguration(String env, List<String> resourceList) {
        Properties appProperties = new Properties();

        appProperties.setProperty("rosbank.env", env);
        loadPropertiesFromResources(appProperties, resourceList);

        return appProperties;
    }

    /**
     * Формирует список относительных путей файлов ресурсов,
     * загружаемых последовательно в порядке следования в списке
     *
     * @param env               имя окружения
     * @param customConfigFiles список путей произвольных файлов конфигурации
     * @param pathPrefix        префис относительного пути
     * @return список относительных путей
     */
    private List<String> getResourceList(String env, String customConfigFiles, String pathPrefix, String pluginName) {

        List<String> resourceList = new ArrayList<>();
        resourceList.add("config/common.properties");
        if (!pluginName.isEmpty()) {
            resourceList.add(String.format("config/%s.properties", pluginName.toLowerCase()));
        }
        resourceList.add(String.format("%s/application.properties", pathPrefix));
        resourceList.add(String.format("%s/app/application.properties", pathPrefix));
        resourceList.add(String.format("%s/app/%s.properties", pathPrefix, env));
        for (String str : customConfigFiles.split("[,;]")) {
            String fileName = str.trim();
            if (!fileName.isEmpty()) {
                resourceList.add(fileName.replace("config", pathPrefix));
            }
        }
        return resourceList;
    }

    /**
     * Вычисляет префикс относительного пути.
     *
     * @param moduleName имя модуля, для текущего модуля передавать ""
     * @return собранный префикс
     */
    private String getPathPrefix(String moduleName) {
        return moduleName == null || moduleName.isEmpty() ? "config" : String.format("config-%s", moduleName);
    }

    /**
     * Загружает конфигурацию из списка ресурсов и объединяет ее с коллекцией-получателем
     *
     * @param properties получатель
     * @param resources  список имен ресурсов
     */
    private void loadPropertiesFromResources(Properties properties, List<String> resources) {

        for (String resourceName : resources) {
            log.debug("Загружаю настройки из {}", resourceName);

            Properties newProps = FileUtils.loadPropertiesFromResource(resourceName);

            merge(properties, newProps);

            log.debug("Загружены настройки из {}", resourceName);
        }
    }

    /**
     * Записывает все свойства из поставщика в получателя
     *
     * @param consumer получатель свойств
     * @param producer поставщик свойств
     */
    private void merge(Properties consumer, Properties producer) {

        for (Map.Entry<Object, Object> entry : producer.entrySet()) {
            consumer.put(entry.getKey(), entry.getValue());
        }

    }
}
