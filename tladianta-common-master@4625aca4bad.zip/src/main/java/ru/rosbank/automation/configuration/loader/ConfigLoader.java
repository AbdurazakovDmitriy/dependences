package ru.rosbank.automation.configuration.loader;

import java.util.Properties;

public interface ConfigLoader {

    /**
     * Загружает свойтва конфигурации текущего модуля.
     *
     * @param env              имя окружения - значение параметра командной строки {@code -Denv}
     * @param customConfigFiles - список относительных путей к произвольным файлам ресурсов через запятую без пробелов,
     *                         значение параметра командной строки {@code -DCustomConfigFiles}
     * @return коллекция свойств
     */
    Properties loadModuleConfiguration(String env, String customConfigFiles);

    /**
     * Загружает свойства конфигурации "гостевого" модуля,
     * который подключен к текущему проекту как зависимость
     *
     * @param env              имя окружения - значение параметра командной строки {@code -Denv}
     * @param customConfigFiles список относительных путей к произвольным файлам ресурсов через запятую без пробелов,
     *                          значение свойства текущего модуля {@code *.custom.props}, где "*" - это имя гостевого модуля
     * @param moduleName имя гостевого модуля
     * @param pluginName имя плагина гостевого модуля
     * @return коллекция свойств
     */
    Properties loadModuleConfiguration(String env, String customConfigFiles, String moduleName, String pluginName);
}
