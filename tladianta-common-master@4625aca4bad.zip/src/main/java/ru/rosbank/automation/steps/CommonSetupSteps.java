package ru.rosbank.automation.steps;

import cucumber.api.Scenario;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import ru.rosbank.automation.configuration.ApplicationManager;
import ru.rosbank.automation.configuration.CommonConfiguration;
import ru.rosbank.automation.configuration.ConfigurationManager;
import ru.rosbank.automation.tasks.KillProcessesTask;
import ru.rosbank.automation.utils.screen.VideoUtils;
import ru.sbtqa.tag.datajack.Stash;
import ru.sbtqa.tag.pagefactory.environment.Environment;
import ru.sbtqa.tag.pagefactory.tasks.ConnectToLogTask;
import ru.sbtqa.tag.pagefactory.tasks.TaskHandler;

import java.util.List;
import java.util.function.Supplier;

public class CommonSetupSteps {
    private static final CommonConfiguration PROPERTIES = CommonConfiguration.create();

    @Contract(pure = true)
    private CommonSetupSteps() {
    }

    public static void preSetUp() {
        TaskHandler.addTask(new ConnectToLogTask());
        TaskHandler.addTask(new KillProcessesTask(PROPERTIES.getTasksToKill()));

        if (!PROPERTIES.getStashShared()) {
            Stash.clear();
        }

        registerClassForReset();
    }

    public static void handleTasks() {
        TaskHandler.handleTasks();
    }

    public static void initVideoUtils() {
        VideoUtils.create();
        VideoUtils.startRecord();
    }

    public static void tearDown(@NotNull Scenario scenario) {
        VideoUtils.stopRecord();
        VideoUtils.attachRecord(scenario.isFailed());

        if (!Environment.isDriverEmpty() && !PROPERTIES.getShared()) {
            Environment.getDriverService().demountDriver();
        }
    }

    public static void addDefaultResetActions(@NotNull String contextName) {

        List<Runnable> resetActions = ApplicationManager.getResetActions(contextName);
        if (resetActions != null) {
            resetActions.clear();
            // обнулить текущую страницу
            ApplicationManager.addResetAction(contextName, ApplicationManager::resetCurrentPage);
            // пересоздать репозиторий страниц модуля
            ApplicationManager.addResetAction(contextName, ApplicationManager::resetPageRepository);
        }
    }

    private static void registerClassForReset() {
        Supplier<CommonConfiguration> valueSupplier = CommonConfiguration::create;
        ConfigurationManager.registerClassForReset("ru.rosbank.automation.steps.CommonSetupSteps", ConfigurationManager.PROPERTIES, valueSupplier);
        ConfigurationManager.registerClassForReset("ru.rosbank.automation.utils.SshUtils", ConfigurationManager.PROPERTIES, valueSupplier);
        ConfigurationManager.registerClassForReset("ru.rosbank.automation.utils.screen.VideoUtils", ConfigurationManager.PROPERTIES, valueSupplier);
    }
}
