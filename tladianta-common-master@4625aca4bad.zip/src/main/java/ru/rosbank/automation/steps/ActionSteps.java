package ru.rosbank.automation.steps;

public interface ActionSteps<T> {

    /**
     * Выполняет действие(Action) в блоке с параметрами.
     *
     * @param block  имя блока или путь до него
     * @param action заголовок действия {@link ru.sbtqa.tag.pagefactory.annotations.ActionTitle}, которое нужно выполнить
     * @param param  параметры для метода экшена
     * @return текущий объект
     * @throws NoSuchMethodException если метод не найден в указанном блоке
     */
    T actionInBlock(String block, String action, Object... param) throws NoSuchMethodException;

    /**
     * Выполняет действие (Action) на странице
     *
     * @param action заголовок действия {@link ru.sbtqa.tag.pagefactory.annotations.ActionTitle}, которое нужно выполнить
     * @param param  параметры для метода экшена
     * @return текущий объект
     * @throws NoSuchMethodException если метод не найден в указанном блоке
     */
    T action(String action, Object... param) throws NoSuchMethodException;
}
