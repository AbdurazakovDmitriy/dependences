package ru.rosbank.automation.steps;

import cucumber.api.PendingException;
import io.cucumber.datatable.DataTable;
import ru.rosbank.automation.transformer.ClickCondition;
import ru.sbtqa.tag.pagefactory.exceptions.PageException;

import java.util.List;

public interface CommonTableSteps<T> {

    /**
     * Находит строку в таблице по значению в колонке и сохраняет номер строки в контекст сценария (Stash)
     *
     * @param tableName имя элемента типа таблица
     * @param columnName имя колонки отбора
     * @param value значение отбора
     * @param variable имя переменной
     * @return текущий объект
     */
    default T writeInStashRowNum(String tableName, String columnName, String value, String variable) throws PageException{
        throw new PendingException("Метод не реализован: writeInStashRowNum(String tableName, String columnName, String value, String variable)");
    }

    /**
     * Находит строку в таблице по значению N-й колонке и сохраняет номер строки в контекст сценария (Stash)
     *
     * @param tableName имя элемента типа таблица
     * @param cellText искомый текст
     * @param columnNumber порядковый номер колокни (1-я, 2-я, 3-я ...)
     * @param stashKey имя переменной
     * @return текущий объект
     */
    default T writeInStashRowNumberByColumnNumber(String tableName, String cellText, String columnNumber, String stashKey) throws PageException{
        throw new PendingException("Метод не реализован: writeInStashRowNumberByColumnNumber(String tableName, String cellText, String columnNumber, String stashKey)");
    }

    /**
     * Сохраняет в контекст сценария значение ячейки
     *
     * @param elementTitle имя элемента типа таблица
     * @param rowNum номер строки
     * @param columnName имя колонки
     * @param variable имя переменной контекста сценария
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка работы с таблицей
     */
    default T writeInStashCellValue(String elementTitle, String rowNum, String columnName, String variable) throws PageException{
        throw new PendingException("Метод не реализован: writeInStashCellValue(String elementTitle, String rowNum, String columnName, String variable)");
    }

    /**
     * Запоминает в контекст сценария количество строк в таблице
     *
     * @param elementTitle имя элемента типа таблица
     * @param variable имя переменной контекста
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка при работе с таблицей
     */
    default T writeToStashRowCount(String elementTitle, String variable) throws PageException{
        throw new PendingException("Метод не реализован: writeToStashRowCount(String elementTitle, String variable)");
    }

    /**
     * Проверяет, что хотя бы одна ячейка колонки содержит ожидаемый текст
     *
     * @param elementTitle имя элемента (таблицы)
     * @param columnName имя колонки
     * @param regex ожидаемое знаяение ячейки
     * @return текущий объект
     */
    default T findValueInColumn(String elementTitle, String columnName, String regex) throws PageException{
        throw new PendingException("Метод не реализован: findValueInColumn(String elementTitle, String columnName, String regex)");
    }

    /**
     * Проверяет, что колонка не содержит ячеек со значением, подходящим под шаблон
     *
     * @param elementTitle имя элемента (таблицы)
     * @param columnName имя колонки отбора
     * @param regex шаблон поиска значения
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка при работе с таблицей
     */
    default T notFindValueInColumn(String elementTitle, String columnName, String regex) throws PageException{
        throw new PendingException("Метод не реализован: notFindValueInColumn(String elementTitle, String columnName, String regex)");
    }

    /**
     * Проверяет, что в таблице хотя бы одна ячейка содержит указанный текст
     *
     * @param tableName имя элемента (таблицы)
     * @param cellText ожидаемое знаяение ячейки
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка при работе с таблицей
     */
    default T findValueInTable(String tableName, String cellText) throws PageException{
        throw new PendingException("Метод не реализован: findValueInTable(String tableName, String cellText)");
    }

    /**
     * Проверяет, что таблица содержит хотя бы одну ячейку с указанным текстом.
     * <p>Поиск по полному соответствию.</p>
     *
     * @param tableName имя элемента (таблицы)
     * @param cellText ожидаемое знаяение ячейки
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка при работе с таблицей
     */
    default T checkTableHasText(String tableName, String cellText) throws PageException{
        throw new PendingException("Метод не реализован: checkTableHasText(String tableName, String cellText)");
    }

    /**
     * Находит строку по значению в колонке, затем проверяет,
     * что в этой строке указанные ячейки имеют нужные значения {@code data}
     *
     * @param tableName имя элемента (таблицы)
     * @param cellText значение отбора
     * @param columnName имя колонки отбора
     * @param data набор для сравнения "имя колонки - значение ячейки".
     *             Например:
     * <p><code>| Column 1 | cell text |</code></p>
     * <p><code>| Column 2 | cell text |</code></p>
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка при работе с таблицей
     */
    default T checkRowByFilter(String tableName, String cellText, String columnName, DataTable data) throws PageException{
        throw new PendingException("Метод не реализован: checkRowByFilter(String tableName, String cellText, String columnName, DataTable data)");
    }

    /**
     * Находит строку по значению в колонке (по номеру колонки), затем проверяет,
     * что в этой строке указанные ячейки имеют нужные значения {@code data}
     *
     * @param tableName имя элемента (таблицы)
     * @param cellText значение отбора
     * @param columnNumber порядковый номер колонки отбора (1-я, 2-я, 3-я...)
     * @param data набор для сравнения "имя колонки - значение ячейки".
     *             Например:
     * <p><code>| Column 1 | cell text |</code></p>
     * <p><code>| Column 2 | cell text |</code></p>
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка при работе с таблицей
     */
    default T checkRowByFilterAndColumnNumber(String tableName, String cellText, String columnNumber, DataTable data) throws PageException{
        throw new PendingException("Метод не реализован: checkRowByFilterAndColumnNumber(String tableName, String cellText, String columnNumber, DataTable data)");
    }

    /**
     * Выбирает(кликает на) строку в таблице по ее номеру
     *
     * @param elementTitle имя элемента типа таблица
     * @param rowNum номер строки
     * @param clickVariation модификатор клика: двойной клик/одинарный клик
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка при работе с таблицей
     */
    default T selectTableRowByNumber(String elementTitle, String rowNum, ClickCondition clickVariation) throws PageException{
        throw new PendingException("Метод не реализован: selectTableRowByNumber(String elementTitle, String rowNum, ClickCondition clickVariation)");
    }

    /**
     * Выбирает(кликает на) первую по порядку строку в таблице
     *
     * @param elementTitle имя элемента типа таблица
     * @param clickVariation модификатор клика: двойной клик/одинарный клик
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка при работе с таблицей
     */
    default T selectFirstRow(String elementTitle, ClickCondition clickVariation) throws PageException{
        throw new PendingException("Метод не реализован: selectFirstRow(String elementTitle, ClickCondition clickVariation)");
    }

    /**
     * Выбирает(кликает на) последнюю строку в таблице
     *
     * @param elementTitle имя элемента типа таблица
     * @param clickVariation модификатор клика: двойной клик/одинарный клик
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка при работе с таблицей
     */
    default T selectLastRow(String elementTitle, ClickCondition clickVariation) throws PageException{
        throw new PendingException("Метод не реализован: selectLastRow(String elementTitle, ClickCondition clickVariation)");
    }

    /**
     * Выбирает(кликает на) строку таблицы по значению ячейки в колонке
     *
     * @param clickVariation модификатор клика: двойной клик/одинарный клик
     * @param tableName имя элемента типа таблица
     * @param cellText искомый текст ячейки
     * @param columnName имя колонки
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка при работе с таблицей
     */
    default T selectTableRow(ClickCondition clickVariation, String tableName, String cellText, String columnName) throws PageException{
        throw new PendingException("Метод не реализован: selectTableRow(ClickCondition clickVariation, String tableName, String cellText, String columnName)");
    }

    /**
     * Выбирает(кликает на) N-ю строку таблицы по значению ячейки в колонке
     *
     * @param clickVariation модификатор клика: двойной клик/одинарный клик
     * @param tableName имя элемента типа таблица
     * @param cellText искомый текст ячейки
     * @param columnName имя колонки
     * @param serialNumber порядковый номер строки в найденных строках (1-я найденная, 2-я найденная и т.д.)
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка при работе с таблицей
     */
    default T selectTableRow(ClickCondition clickVariation, String tableName, String cellText, String columnName, int serialNumber) throws PageException{
        throw new PendingException("Метод не реализован: selectTableRow(ClickCondition clickVariation, String tableName, String cellText, String columnName)");
    }

    /**
     * Выбирает(кликает на) строку по тексту в колонке с указанным номером
     *
     * @param clickVariation модификатор клика: двойной клик/одинарный клик
     * @param tableName имя элемента (таблицы)
     * @param cellText искомое значение ячейки
     * @param columnNumber порядковый номер колонки (1-я, 2-я, 3-я...)
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка при работе с таблицей
     */
    default T selectTableRowInColumn(ClickCondition clickVariation, String tableName, String cellText, String columnNumber) throws PageException{
        throw new PendingException("Метод не реализован: selectTableRowInColumn(ClickCondition clickVariation, String tableName, String cellText, String columnNumber)");
    }

    /**
     * Выбирает(кликает на) N-ю строку по тексту в колонке с указанным номером
     *
     * @param clickVariation модификатор клика: двойной клик/одинарный клик
     * @param tableName имя элемента (таблицы)
     * @param cellText искомое значение ячейки
     * @param columnNumber порядковый номер колонки (1-я, 2-я, 3-я...)
     * @param serialNumber порядковый номер строки среди найденных (1-я, 2-я, 3-я ...)
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка при работе с таблицей
     */
    default T selectTableRowInColumnByNumber(ClickCondition clickVariation, String tableName, String cellText, String columnNumber, int serialNumber) throws PageException{
        throw new PendingException("Метод не реализован: selectTableRowInColumnByNumber(ClickCondition clickVariation, String tableName, String cellText, String columnNumber, int serialNumber)");
    }

    /**
     * Выбирает(кликает на) строку по тексту в любой колонке.
     * Ищет по полному соответствию, выбирает первую найденную ячейку
     *
     * @param clickVariation модификатор клика: двойной клик/одинарный клик
     * @param cellText искомый текст ячейки
     * @param tableName имя элемента (таблицы)
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка при работе с таблицей
     */
    default T selectTableRowByValue(ClickCondition clickVariation, String cellText, String tableName) throws PageException{
        throw new PendingException("Метод не реализован: selectTableRowByValue(ClickCondition clickVariation, String cellText, String tableName)");
    }

    /**
     * Выбирает(кликает на) строку по тексту в любой колонке.
     * Ищет по полному соответствию, выбирает первую N-ю найденную строку
     *
     * @param clickVariation модификатор клика: двойной клик/одинарный клик
     * @param cellText искомый текст ячейки
     * @param tableName имя элемента (таблицы)
     * @param serialNumber порядковый номер строки среди найденных (1-я, 2-я, 3-я ...)
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка при работе с таблицей
     */
    default T selectTableRowByValue(ClickCondition clickVariation, String cellText, String tableName, int serialNumber) throws PageException{
        throw new PendingException("Метод не реализован: selectTableRowByValue(ClickCondition clickVariation, String cellText, String tableName, int serialNumber)");
    }

    /**
     * Выбирает строку, в которой присутствуют значения из списка.
     * <p>Порядок значений в списке не имеет значения.</p>
     *
     * @param clickVariation модификатор клика: двойной клик/одинарный клик
     * @param tableName имя элемента (таблицы)
     * @param row список ожидаемых значений
     * @return текущий объект
     * @throws PageException страница не инициализирована или ошибка при работе с таблицей
     */
    default T selectTableRowByValues(ClickCondition clickVariation, String tableName, List<String> row) throws PageException{
        throw new PendingException("Метод не реализован: selectTableRowByValues(ClickCondition clickVariation, String tableName, List<String> row)");
    }
}
