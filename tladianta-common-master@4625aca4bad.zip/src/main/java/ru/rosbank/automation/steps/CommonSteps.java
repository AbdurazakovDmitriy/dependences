package ru.rosbank.automation.steps;

import cucumber.api.PendingException;
import io.cucumber.datatable.DataTable;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.junit.Assert;
import ru.rosbank.automation.configuration.ApplicationContext;
import ru.rosbank.automation.configuration.ApplicationManager;
import ru.rosbank.automation.transformer.NegationCondition;
import ru.rosbank.automation.utils.stash.StashSaver;
import ru.sbtqa.tag.datajack.Stash;
import ru.sbtqa.tag.pagefactory.exceptions.FactoryRuntimeException;
import ru.sbtqa.tag.pagefactory.exceptions.PageException;
import ru.sbtqa.tag.pagefactory.exceptions.PageInitializationException;
import ru.sbtqa.tag.qautils.properties.Props;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * <p>Реализация методов дополнительных шагов, общие для всех модулей проекта.</p>
 * <p>Поддерживает FluentAPI, методы можно вызывать через точку последовательно.</p>
 * Например,
 * <p>{@code CommonSteps.getInstance().printProps().sleep().fillFields()}
 * и т.д. аналогично тому, как если бы выполнялись шаги сценария в Gherkin</p>
 * <p>Все {@code public}-методы класса независимы друг от друга.</p>
 */
@Slf4j
public class CommonSteps {

    private static final ThreadLocal<CommonSteps> instance = ThreadLocal.withInitial(CommonSteps::new);

    @Contract(pure = true)
    public static CommonSteps getInstance() {
        return instance.get();
    }

    @Contract("_->this")
    public CommonSteps openPageUrl(@NotNull String namePage) throws PageInitializationException {
        log.info("Переопредели метод openPageUrl(String namePage) в своем модуле.");
        throw new PendingException("Метод не реализован.");
    }

    public CommonSteps selectRandomOption(String listTitle) {
        log.info("Переопредели метод selectRandomOption(String listTitle) в своем модуле.");
        throw new PendingException("Метод не реализован.");
    }

    /**
     * Переключает контекст фреймворка на работу с данными модуля, чьи шаги планируется использовать в сценарии далее
     *
     * @param appName имя модуля. Значение свойства {@code app.name} конфигурации application.properties
     * @return текущий объект
     */
    @Contract("_->this")
    public CommonSteps resetApplicationContext(String appName) {
        Assert.assertTrue(String.format("Контекст модуля %s не найден", appName), ApplicationContext.hasAppProperties(appName));
        try {
            ApplicationManager.resetApplicationContext(appName);
        } catch (Exception e) {
            throw new FactoryRuntimeException(String.format("Переключение на контекст модуля %s завершилось ошибкой", appName));
        }

        return this;
    }

    /**
     * <p>Печатает в консоль все текущие свойства конфигурации</p>
     * Используется для отладки
     *
     * @return текущий объект
     */
    @Contract("->this")
    public CommonSteps printProps() {

        Props.getProps().list(System.out);

        return this;
    }

    /**
     * Заполняет поле с помощью посимвольного ввода
     *
     * <p><span style='color:red;'>Реализация метода должна быть определена в каждом плагине индивидуально</span></p>
     *
     * @param elementTitle имя элемента -
     *                     <p>Поддерживает путь к элементу ({@code ->})</p>
     * @param text         текст для ввода
     * @return текущий объект
     * @throws PageException ошибка чтения значения элемента
     */
    @Contract("_,_->this")
    public CommonSteps slowFill(@NotNull String elementTitle, @NotNull String text) throws PageException {
        log.info("Переопредели метод slowFill(String elementTitle, String text) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }


    /**
     * Останавливает поток выполнения на указанное количество секунд
     *
     * @param timeout количество секунд
     * @return текущий объект
     * @throws InterruptedException ошибка прерывания потока во время ожидания
     */
    @Contract("_->this")
    public CommonSteps sleep(long timeout) throws InterruptedException {
        TimeUnit.SECONDS.timedWait(this, timeout);
        log.debug("Ожидание {} секунд", timeout);
        return this;
    }

    /**
     * Очищает все поля по именам из списка
     *
     * <p><span style='color:red;'>Реализация метода должна быть определена в каждом плагине индивидуально</span></p>
     *
     * @param elementTitles список имен элементов
     *                      <p>Поддерживает путь к элементу ({@code ->})</p>
     * @return текущий объект
     */
    @Contract("_->this")
    public CommonSteps clearFields(@NotNull List<String> elementTitles) throws PageException{
        log.info("Переопредели метод clearFields(List<String> elementTitles) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * Заполняет поля страницы указаными значениями в таблице
     * <p>Поддерживает путь к элементу ({@code ->})</p>
     * <p><span style='color:red;'>Реализация метода должна быть определена в каждом плагине индивидуально</span></p>
     *
     * @param dataTable параметр-таблица вида:
     *                  <pre>|Имя элемента|новое значение элемента|</pre>
     *                  <pre>|Имя элемента|новое значение элемента|</pre>
     * @return текущий объект
     */
    @Contract("_->this")
    public CommonSteps fillFields(@NotNull DataTable dataTable) throws PageException {
        log.info("Переопредели метод fillFields(DataTable dataTable) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * Заполняет посимвольно поля страницы указаными значениями в таблице
     * <p>Поддерживает путь к элементу ({@code ->})</p>
     * <p><span style='color:red;'>Реализация метода должна быть определена в каждом плагине индивидуально</span></p>
     *
     * @param dataTable параметр-таблица вида:
     *                  <pre>|Имя элемента|новое значение элемента|</pre>
     *                  <pre>|Имя элемента|новое значение элемента|</pre>
     * @return текущий объект
     */
    @Contract("_->this")
    public CommonSteps slowFillFields(@NotNull DataTable dataTable) throws PageException {
        log.info("Переопредели метод slowFillFields(DataTable dataTable) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * Проверяет на равенство значения в полях
     * <p>Поддерживает путь к элементу ({@code ->})</p>
     * <p><span style='color:red;'>Реализация метода должна быть определена в каждом плагине индивидуально</span></p>
     *
     * @param dataTable параметр-таблица вида:
     *                  <pre>|Имя элемента|значение элемента|</pre>
     *                  <pre>|Имя элемента|значение элемента|</pre>
     * @return текущий объект
     */
    public CommonSteps checkFields(@NotNull DataTable dataTable) throws PageException{
        log.info("Переопредели метод checkFields(DataTable dataTable) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * Проверяет поля страницы на пустое/не пустое значение
     * <p>Поддерживает путь к элементу ({@code ->})</p>
     * <p><span style='color:red;'>Реализация метода должна быть определена в каждом плагине индивидуально</span></p>
     *
     * @param negation     проверять на пустое/не пустое значение
     * @param elementNames параметр-список имен элементов
     * @return текущий объект
     */
    @Contract("_,_->this")
    public CommonSteps checkFieldsForEmpty(@NotNull NegationCondition negation, @NotNull List<String> elementNames) throws PageException{
        log.info("Переопредели метод checkFields(DataTable dataTable) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * Проверяет, что чекбокс установлен/не установлен
     *
     * <p><span style='color:red;'>Реализация метода должна быть определена в каждом плагине индивидуально</span></p>
     *
     * @param elementName имя элемента - чекбокса
     *                    <p>Поддерживает путь к элементу ({@code ->})</p>
     * @param negation    POSITIVE - Установлен, NEGATIVE - не установлен
     * @return текущий объект
     * @throws PageException ошибка чтения значения элемента
     */
    @Contract("_,_->this")
    public CommonSteps verifyCheckBox(@NotNull String elementName, @NotNull NegationCondition negation) throws PageException {
        log.info("Переопредели метод verifyCheckBox(String elementName, Condition negation) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * Снимает чекбокс
     *
     * <p><span style='color:red;'>Реализация метода должна быть определена в каждом плагине индивидуально</span></p>
     *
     * @param elementTitle имя элемента
     *                     <p>Поддерживает путь к элементу ({@code ->})</p>
     * @return текущий объект
     */
    @Contract("_->this")
    public CommonSteps unsetCheckBox(@NotNull String elementTitle) throws PageException{
        log.info("Переопредели метод unsetCheckBox(String elementTitle) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * <p>Нажимает клавишу клавиатуры указаное количество раз</p>
     *
     * <p><span style='color:red;'>Реализация метода должна быть определена в каждом плагине индивидуально</span></p>
     *
     * @param keyName Имя кнопки
     * @param counts  Количество нажатий
     */
    @Contract("_,_->this")
    public CommonSteps pressKey(@NotNull String keyName, int counts) {
        log.info("Переопредели метод pressKey(String keyName, int counts) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * Проверяет, что элемент доступен/не доступен
     *
     * <p><span style='color:red;'>Реализация метода должна быть определена в каждом плагине индивидуально</span></p>
     *
     * @param elementName имя элемента
     *                    <p>Поддерживает путь к элементу ({@code ->})</p>
     * @param negation    доступен/не доступен
     * @return текущий объект
     * @throws PageException ошибка чтения значения атрибута элемента
     */
    @Contract("_,_->this")
    public CommonSteps checkElementAvailability(@NotNull String elementName, @NotNull NegationCondition negation) throws PageException {
        log.info("Переопредели метод checkElementAvailability(String elementName, Condition negation) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * Проверяет, что элементы из списка доступны/не доступны
     *
     * <p><span style='color:red;'>Реализация метода должна быть определена в каждом плагине индивидуально</span></p>
     *
     * @param elementNames список имен элементов
     *                     <p>Поддерживает путь к элементу ({@code ->})</p>
     * @param negation     доступен/не доступен
     * @return текущий объект
     * @throws PageException ошибка чтения значения атрибута элемента
     */
    public CommonSteps checkElementsAvailability(NegationCondition negation, List<String> elementNames) throws PageException {
        log.info("Переопредели метод checkElementsAvailability(Condition condition, List<String> elementNames) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * Проверка видимости/невидимости элемента
     *
     * <p><span style='color:red;'>Реализация метода должна быть определена в каждом плагине индивидуально</span></p>
     *
     * @param elementName имя элемента - чекбокса
     *                    <p>Поддерживает путь к элементу ({@code ->})</p>
     * @param negation    инвертор проверки - виден/не виден
     * @return текущий объект
     * @throws PageException ошибка чтения значения атрибута элемента
     */
    public CommonSteps checkElementVisibility(String elementName, NegationCondition negation) throws PageException {
        log.info("Переопредели метод checkElementVisibility(String elementName, Condition negation) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * Проверяет, все элементы в списке видимы/невидимы. При этом элемент присутствует в DOM страницы.
     *
     * @param negation     инвертор проверки - видимый/не видимый
     * @param elementNames список имен элементов
     * @return текущий объект
     */
    public CommonSteps checkElementsVisibility(NegationCondition negation, List<String> elementNames) throws PageException {
        log.info("Переопредели метод checkElementsVisibility(Presence present, List<String> elementNames) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * <p>Проверяет наличие файлов на диске</p>
     *
     * @param filePaths список путей к файлам
     * @return текущий объект
     */
    public CommonSteps checkFilesExist(List<String> filePaths) {
        int exist = getNumberOfExistingFiles(filePaths);
        Assert.assertEquals("Не все указанные файлы существуют", filePaths.size(), exist);
        return this;
    }

    /**
     * <p>Проверяет отсутствие всех указанных файлов на диске</p>
     *
     * @param filePaths список путей к файлам
     * @return текущий объект
     */
    public CommonSteps checkFilesNotExist(List<String> filePaths) {
        int exist = getNumberOfExistingFiles(filePaths);
        Assert.assertEquals("Не все указанные файлы отсутствуют", 0, exist);
        return this;
    }

    /**
     * <p>Удаляет файлы с диска</p>
     *
     * @param filePaths Пути к файлам через запятую
     * @return текущий объект
     */
    @Contract("_->this")
    public CommonSteps deleteFiles(@NotNull List<String> filePaths) throws IOException {
        for (String filePath : filePaths) {
            if (Files.deleteIfExists(Paths.get(filePath))) {
                log.info("Файл {} удален", filePath);
            } else {
                log.info("Файл {} не обнаружен");
            }
        }
        return this;
    }

    /**
     * Сохраняет значение элемента в контекст Stash под именем
     * <p><span style='color:red;'>Реализация метода должна быть определена в каждом плагине индивидуально</span></p>
     *
     * @param elementName  имя элемента
     *                     <p>Поддерживает путь к элементу ({@code ->})</p>
     * @param variableName мя переменной
     * @return текущий объект
     * @throws PageException ошибка чтения значения поля
     */
    public CommonSteps saveElementValueInStash(String elementName, String variableName) throws PageException {
        log.info("Переопредели метод saveElementValueInStash(String elementName, String variableName) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * Сохраняет значение в контекст Stash под именем
     *
     * @param value    значение
     * @param variable имя переменной
     * @return текущий объект
     */
    @Contract("_,_->this")
    public CommonSteps writeInStash(String value, String variable) {
        Stash.put(variable, value);
        log.info("Запомнили значение '{}' в переменную '{}'", value, variable);
        return this;
    }


    /**
     * <p>Сохраняет весь контекст (Stash) в БД MS SQL под уазанным именем (variable)</p>
     *
     * @param variable Ключ
     * @return текущий объект
     */
    @Contract("_->this")
    public CommonSteps updateStashInDB(@NotNull String variable) {
        StashSaver.saveToDB(variable);
        return this;
    }

    /**
     * <p>Инициализирует контекст (Stash) значениями из БД MS SQL, которые достает по имени</p>
     *
     * @param variable Ключ
     * @return текущий объект
     */
    @Contract("_->this")
    public CommonSteps restoreStashFromDB(@NotNull String variable) {
        StashSaver.getFromDB(variable).forEach(Stash::put);
        return this;
    }

    /**
     * Ждет, когда элемент станет недоступен. При этом сам элемент остается видимым.
     *
     * @param elementName имя элемента
     * @return текущий объект
     */
    public CommonSteps waitElementDisabled(String elementName) {
        log.info("Переопредели метод saveElementValueInStash(String elementName, String variableName) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * Ждет в течение указанного времени (сек), когда элемент станет недоступен. При этом сам элемент остается видимым.
     *
     * @param elementName имя элемента
     * @param timeout     время ожидания в секундах
     * @return текущий объект
     */
    public CommonSteps waitElementDisabled(String elementName, int timeout) {
        log.info("Переопредели метод saveElementValueInStash(String elementName, String variableName) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * Ждет, когда значение элемента сменится на ожидаемое
     *
     * @param elementName имя элемента
     * @param value       ожидаемое значение
     * @param negation    инвертор ожидания - равно/не равно
     * @return текущий объект
     */
    public CommonSteps waitChangeElementValue(String elementName, String value, NegationCondition negation) {
        log.info("Переопредели метод waitChangeElementValue(String elementName, String value, Condition negation) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * Ждет в течение указанного времени (сек), когда значение элемента сменится на ожидаемое
     *
     * @param elementName имя элемента
     * @param value       ожидаемое значение
     * @param timeout     время ожидания в секундах
     * @param negation    инвертор ожидания - равно/не равно
     * @return текущий объект
     */
    public CommonSteps waitChangeElementValue(String elementName, String value, int timeout, NegationCondition negation) {
        log.info("Переопредели метод waitChangeElementValue(String elementName, String value, int timeout, Condition negation) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * Проверяет, что элемент с указанным текстом существует на странице
     *
     * @param elementName имя элемента
     * @param value       ожидаемое значение
     * @return текущий объект
     */
    public CommonSteps elementWithTextExists(String elementName, String value) {
        log.info("Переопредели метод elementWithTextExists(String elementName, String value) в своем модуле.");
        throw new PendingException("Метод не реализован.");
//        return this;
    }

    /**
     * Возвращаят количество файлов из списка, которые существуют на диске
     *
     * @param filePaths список путей файлов
     * @return количество существующих файлов
     */
    private int getNumberOfExistingFiles(@NotNull List<String> filePaths) {
        int exist = 0;

        for (String filePath : filePaths) {

            if (Files.exists(Paths.get(filePath))) {
                log.info("Файл {} существует", filePath);
                exist++;
            } else {
                log.info("Файл {} не обнаружен", filePath);
            }

        }
        return exist;
    }
}
