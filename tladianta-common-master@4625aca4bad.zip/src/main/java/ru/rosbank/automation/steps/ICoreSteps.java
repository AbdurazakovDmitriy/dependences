package ru.rosbank.automation.steps;

import io.cucumber.datatable.DataTable;
import org.openqa.selenium.Keys;
import ru.rosbank.automation.environment.ISourceProvider;
import ru.rosbank.automation.helpers.PageHelper;
import ru.rosbank.automation.transformer.NegationCondition;
import ru.sbtqa.tag.pagefactory.Page;
import ru.sbtqa.tag.pagefactory.annotations.PageEntry;
import ru.sbtqa.tag.pagefactory.context.PageContext;
import ru.sbtqa.tag.pagefactory.exceptions.FragmentException;
import ru.sbtqa.tag.pagefactory.exceptions.PageException;
import ru.sbtqa.tag.pagefactory.exceptions.PageInitializationException;
import ru.sbtqa.tag.pagefactory.exceptions.WaitException;
import ru.sbtqa.tag.pagefactory.junit.CoreStepsImpl;

public interface ICoreSteps extends ISourceProvider<CoreStepsImpl> {

    /**
     * <p>Инициализирует клас страницы с именем, определенным в аннотации
     * {@link PageEntry}.</p>
     * <p>Передает в конструктор страницы параметры из таблицы {@code dataTable}</p>
     * <p>Принимается таблица-список в которой значения соответствуют порядку аргументов конструктора страницы</p>
     *
     * @param title Имя страницы
     * @param dataTable таблица параметров конструктора
     * @return текущий объект
     * @throws PageInitializationException ошибка инициализации страницы
     */
    default ICoreSteps openPage(String title, DataTable... dataTable) throws PageInitializationException {

        Class<? extends Page> pageClass = PageHelper.getPageClass(title).orElseThrow(() -> new PageInitializationException("Страница '" + title + "' не найдена."));

        Page page;
        if (dataTable.length > 0) {
            page = PageHelper.bootstrapPage(pageClass, dataTable[0].asList(String.class).toArray());
        } else {
            page = PageHelper.bootstrapPage(pageClass);
        }

        PageContext.setCurrentPage(page);

        return this;
    }

    /**
     * Инициализирует страницу конкретного типа
     *
     * @param pageClass тип нужной страницы
     * @return объект страницы
     * @throws PageInitializationException ошибка инициализации страницы
     */
    default  <E extends Page> E openPage(Class<E> pageClass) throws PageInitializationException {
        return pageClass.cast(getSource().openPage(pageClass));
    }

    /**
     * Заполняет элемент страницы текстом
     *
     * @param elementTitle имя элемента, который нужно заполнить
     * @param text текст
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps fill(String elementTitle, String text) throws PageException{
        getSource().fill(elementTitle, text);
        return this;
    }

    /**
     * Кликает по элементу
     *
     * @param elementTitle имя элемента страницы
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps click(String elementTitle) throws PageException {
        getSource().click(elementTitle);
        return this;
    }

    /**
     * Нажимает клавишу клавиатуры
     *
     * @param keyName имя клавиши. Полный список имен тут {@link Keys}
     * @return текущий объект
     */
    default ICoreSteps pressKey(String keyName){
        getSource().pressKey(keyName);
        return this;
    }

    /**
     * Нажимает клавишу клавиатуры на элементе страницы
     *
     * @param keyName имя клавиши. Полный список имен тут {@link Keys}
     * @param elementTitle имя элемента страницы, который принимает ввод с клавиатуры
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps pressKey(String keyName, String elementTitle) throws PageException {
        getSource().pressKey(keyName, elementTitle);
        return this;
    }

    /**
     * Выбирает опцию из выпадающего списка
     *
     * @param elementTitle имя элемента страницы, типа выпадающий список
     * @param option имя опции
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps select(String elementTitle, String option) throws PageException {
        getSource().select(elementTitle, option);
        return this;
    }

    /**
     * Устанавливает флажок в чекбоксе
     *
     * @param elementTitle имя элемента-чекбокса на странице
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps setCheckBox(String elementTitle) throws PageException {
        getSource().setCheckBox(elementTitle);
        return this;
    }

    /**
     * Проверяет что значение элемента строго равно ожидаемому
     *
     * @param elementTitle имя проверяемого элемента страницы
     * @param text ожидаемое значение элемента
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps checkValueIsEqual(String elementTitle, String text) throws PageException {
        getSource().checkValueIsEqual(elementTitle, text);
        return this;
    }

    /**
     * Проверяет, что элемент содержит ожидаемое значение
     *
     * @param elementTitle имя проверяемого элемента страницы
     * @param text ожидаемое значение элемента
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps checkValueContains(String elementTitle, String text) throws PageException {
        getSource().checkValueContains(elementTitle, text);
        return this;
    }

    /**
     * Проверяет, что элемент НЕ содержит ожидаемое значение
     *
     * @param elementTitle имя проверяемого элемента страницы
     * @param text ожидаемое значение элемента
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps checkValueNotContains(String elementTitle, String text) throws PageException {
        getSource().checkValueNotContains(elementTitle, text);
        return this;
    }

    /**
     * Проверяет что значение элемента строго НЕ равно ожидаемому
     *
     * @param elementTitle имя проверяемого элемента страницы
     * @param text ожидаемое значение элемента
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps checkValueIsNotEqual(String elementTitle, String text) throws PageException {
        getSource().checkValueIsNotEqual(elementTitle, text);
        return this;
    }

    /**
     * Проверяет что значение элемента НЕ пустое
     *
     * @param elementTitle имя проверяемого элемента страницы
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps checkNotEmpty(String elementTitle) throws PageException {
        getSource().checkNotEmpty(elementTitle);
        return this;
    }

    /**
     * Проверяет что значение элемента пустое
     *
     * @param elementTitle имя проверяемого элемента страницы
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps checkEmpty(String elementTitle) throws PageException {
        getSource().checkEmpty(elementTitle);
        return this;
    }

    /**
     * Проверяет стоит ли курсор(фокус) на элементе
     *
     * @param elementTitle имя проверяемого элемента страницы
     * @return текущий объект
     */
    default ICoreSteps isElementFocused(String elementTitle) {
        getSource().isElementFocused(elementTitle)   ;
        return this;
    }

    /**
     * Заглушка для спец шага вызова фрагмента.
     * <p>Выполняться никогда не будет, тк шаг вызова фрагмента заменяется на шаги фрагмента препроцессором фичи</p>
     *
     * @param fragmentName имя фрагмента
     * @return текущий объект
     * @throws FragmentException выбрасывается всегда, т.к это заглушка
     */
    default ICoreSteps userInsertsFragment(String fragmentName) throws FragmentException {
        getSource().userInsertsFragment(fragmentName);
        return this;
    }

    /**
     * Ожидает появления элемента на странице.
     * <p>Время ожидания берет из свойства конфигурации <span style='color:green;'>timeout</span></p>
     * По умолчанию, 20 сек
     *
     * @param elementName имя элемента страницы
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps appearElement(String elementName) throws PageException {
        getSource().appearElement(elementName);
        return this;
    }

    /**
     * Ожидает появления элемента на странице.
     *
     * @param timeout время ожидания в секундах
     * @param elementName имя элемента страницы
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps appearElement(int timeout, String elementName) throws PageException {
        getSource().appearElement(timeout, elementName);
        return this;
    }

    /**
     * Ждет когда элемент станет видимым
     * <p>Время ожидания берет из свойства конфигурации <span style='color:green;'>timeout</span></p>
     * По умолчанию, 20 сек
     *
     * @param elementName имя элемента страницы
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps waitInvisibility(String elementName) throws PageException {
        getSource().waitInvisibility(elementName);
        return this;
    }

    /**
     * Ждет когда элемент станет видимым
     *
     * @param timeout время ожидания в секундах
     * @param elementName имя элемента страницы
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps waitInvisibility(int timeout, String elementName) throws PageException {
        getSource().waitInvisibility(timeout, elementName);
        return this;
    }

    /**
     * Ожидает указанное количество секунд когда элемент исчезнет из DOM структуры страницы
     *
     * @param timeout время ожидания в секундах
     * @param elementName имя элемента
     * @return текущий объект
     * @throws PageException если нет страницы или элемента
     */
    default ICoreSteps waitAbsence(int timeout, String elementName) throws PageException {
        getSource().waitAbsence(timeout, elementName);
        return this;
    }

    /**
     * Ожидает когда элемент исчезнет из DOM структуры страницы.
     * Время ожидания в секундах берет из свойства {@code timeout}, по-умолчанию, 20 секунд
     *
     * @param elementName имя элемента
     * @return текущий объект
     * @throws PageException если нет страницы или элемента
     */
    default ICoreSteps waitAbsence(String elementName) throws PageException {
        getSource().waitAbsence(elementName);
        return this;
    }

    /**
     * Ждет когда значение аттрибута элемента страницы станет равно ожидаемому
     * <p>Время ожидания берет из свойства конфигурации <span style='color:green;'>timeout</span></p>
     * По умолчанию, 20 сек
     *
     * @param attribute имя атрибута элемента
     * @param elementName имя элемента страницы
     * @param attributeValue ожидаемое значение аттрибута
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps waitChangeAttribute(String attribute, String elementName, String attributeValue) throws PageException {
        getSource().waitChangeAttribute(attribute, elementName, attributeValue);
        return this;
    }

    /**
     * Ждет когда значение аттрибута элемента страницы станет равно ожидаемому
     *
     * @param timeout время ожидания в секундах
     * @param attribute имя атрибута элемента
     * @param elementName имя элемента страницы
     * @param attributeValue ожидаемое значение аттрибута
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps waitChangeAttribute(int timeout, String attribute, String elementName, String attributeValue) throws PageException {
        getSource().waitChangeAttribute(timeout, attribute, elementName, attributeValue);
        return this;
    }

    /**
     * Ждет когда значение аттрибута элемента страницы станет содержать ожидаемомое значение
     * <p>Время ожидания берет из свойства конфигурации <span style='color:green;'>timeout</span></p>
     * По умолчанию, 20 сек
     *
     * @param attribute имя аттрибута элемента
     * @param elementName имя элемента страницы
     * @param condition маркер содержит/не содержит
     * @param partAttributeValue ожидаемое значение
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps waitAttributeContains(String attribute, String elementName, NegationCondition condition, String partAttributeValue) throws PageException {
        getSource().waitAttributeContains(attribute, elementName, condition.toContainCondition(), partAttributeValue);
        return this;
    }

    /**
     * Ждет когда значение аттрибута элемента страницы станет содержать ожидаемомое значение
     *
     * @param timeout время ожидания в секундах
     * @param attribute имя аттрибута элемента
     * @param elementName имя элемента страницы
     * @param condition маркер содержит/не содержит
     * @param partAttributeValue ожидаемое значение
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps waitAttributeContains(int timeout, String attribute, String elementName, NegationCondition condition, String partAttributeValue) throws PageException {
        getSource().waitAttributeContains(timeout, attribute, elementName, condition.toContainCondition(), partAttributeValue);
        return this;
    }

    /**
     * Ждет когда значение элемента будет содержать ожидаемое значение
     * <p>Время ожидания берет из свойства конфигурации <span style='color:green;'>timeout</span></p>
     * По умолчанию, 20 сек
     *
     * @param elementName имя элемента
     * @param condition маркер содержит/не содержит
     * @param text ожидаемое значение
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps waitElementContainsText(String elementName, NegationCondition condition, String text) throws PageException {
        getSource().waitElementContainsText(elementName, condition.toContainCondition(), text);
        return this;
    }

    /**
     * Ждет когда значение элемента будет содержать ожидаемое значение
     *
     * @param timeout время ожидания в секундах
     * @param elementName имя элемента
     * @param condition маркер содержит/не содержит
     * @param text ожидаемое значение
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps waitElementContainsText(int timeout, String elementName, NegationCondition condition, String text) throws PageException {
        getSource().waitElementContainsText(timeout, elementName, condition.toContainCondition(), text);
        return this;
    }

    /**
     * Ждет когда элемент станет кликабельным/доступным
     * <p>Время ожидания берет из свойства конфигурации <span style='color:green;'>timeout</span></p>
     * По умолчанию, 20 сек
     *
     * @param elementName имя элемента
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps waitClickability(String elementName) throws PageException {
        getSource().waitClickability(elementName);
        return this;
    }

    /**
     * Ждет когда элемент станет кликабельным/доступным
     *
     * @param timeout время ожидания в секундах
     * @param elementName имя элемента
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps waitClickability(int timeout, String elementName) throws PageException {
        getSource().waitClickability(timeout, elementName);
        return this;
    }

    /**
     * Проверяет текст алерта и затме принимает его
     * <p>Время ожидания берет из свойства конфигурации <span style='color:green;'>timeout</span></p>
     * По умолчанию, 20 сек
     *
     * @param text ожидаемое значение алерта
     * @return текущий объект
     * @throws WaitException если алерт не появился
     */
    default ICoreSteps acceptAlert(String text) throws WaitException {
        getSource().acceptAlert(text);
        return this;
    }

    /**
     * Проверяет текст алерта и затем отклоняет его
     * <p>Время ожидания берет из свойства конфигурации <span style='color:green;'>timeout</span></p>
     * По умолчанию, 20 сек
     *
     * @param text ожидаемое значение алерта
     * @return текущий объект
     * @throws WaitException если алерт не появился
     */
    default ICoreSteps dismissAlert(String text) throws WaitException {
        getSource().dismissAlert(text);
        return this;
    }

    /**
     * Очищает значение элемента
     *
     * @param elementTitle имя элемента
     * @return текущий объект
     * @throws PageException если страница не инициализирована или элемента в ней нет
     */
    default ICoreSteps clearField(String elementTitle) throws PageException {
        getSource().clearField(elementTitle);
        return this;
    }

}
