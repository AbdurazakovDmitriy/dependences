package ru.rosbank.automation.tasks;

import ru.rosbank.automation.helpers.CommonHelper;
import ru.rosbank.automation.helpers.SystemHelperImpl;
import ru.sbtqa.tag.pagefactory.tasks.Task;

public class KillProcessesTask implements Task {

    private String processes;

    public KillProcessesTask(String processes) {
        this.processes = processes;
    }

    @Override
    public void handle() {
        stopTasksToKill();
    }

    private void stopTasksToKill() {
        if (!processes.isEmpty()) {
            for (String process : CommonHelper.stringToList(processes)) {
                stopTask(process);
            }
        }
    }

    private void stopTask(String process) {
        SystemHelperImpl.getInstance().killProcess(process);
    }
}
