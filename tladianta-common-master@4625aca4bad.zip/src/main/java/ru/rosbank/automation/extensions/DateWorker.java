package ru.rosbank.automation.extensions;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * <p>Класс по работе с датами.</p>
 * <p>Смещения, парсинг и конвертация.</p>
 */
public class DateWorker {

    public static final Pattern bisDatePattern = Pattern.compile("1([0-2][0-9]|(3)[0-1])(((0)[0-9])|((1)[0-2]))\\d{2}");

    private DateWorker() {
        throw new Error("this is a 'static' class");
    }

    /**
     * Смещает переданную дату на указанное количество дней
     *
     * @param date   дата, которую нужно изменить
     * @param offset смещение в днях (например: +4, -100)
     * @return дата со смещением
     */
    public static LocalDateTime offset(LocalDateTime date, int offset) {
        return offset(date, offset, ChronoUnit.DAYS);
    }

    /**
     * Смещает переданную дату на указанное число указанных частей даты
     *
     * @param date   дата, которую нужно изменить
     * @param offset смещение в единицах (units) (например: +4, -100)
     * @param units  единица смещения даты: год/месяц/день/час/минута/секунда
     * @return дата со смещением
     */
    public static LocalDateTime offset(LocalDateTime date, int offset, TemporalUnit units) {
        return date.plus(offset, units);
    }

    /**
     * Преобразует входную дату в дату по маске
     *
     * @param date    Дата в виде Integer или String
     * @param pattern маска входной даты или имя маски (бис, bis, ру, ru)
     * @return Преобразованная дата, null - если {@code date} другого формата
     */
    public static LocalDateTime parse(Object date, String pattern) {
        String inputPattern = getPatternByName(pattern);
        if (date instanceof LocalDateTime) {
            return (LocalDateTime) date;
        } else if (date instanceof Integer || date instanceof String) {
            return parseStringDate(String.valueOf(date), inputPattern);
        }
        throw new AssertionError(String.format("Тип входной даты '%s' не поддерживается", date.getClass().getCanonicalName()));
    }

    /**
     * Переводит переданную дату в строку по маске.
     *
     * @param date       исходная дата
     * @param outputType тип, в котором нужно вернуть отформатированную дату (Integer, String. Если LocalDateTime, форматирование не происходит)
     * @param pattern маска даты или имя маски
     * @param <T> параметр типа возвращаемого значения
     * @return представление даты
     */
    public static <T> T format(LocalDateTime date, Class<T> outputType, String pattern) {

        String outputPattern = getPatternByName(pattern);

        if (outputType.equals(LocalDateTime.class)) {
            return outputType.cast(date);
        } else if (outputType.equals(Integer.class)) {
            return outputType.cast(Integer.valueOf(getStringByPattern(date, outputPattern)));
        } else if (outputType.equals(String.class)) {
            return outputType.cast(getStringByPattern(date, outputPattern));
        }

        throw new AssertionError(String.format("Тип выходной даты '%s' не поддерживается", outputType.getCanonicalName()));
    }

    /**
     * Преобразует входную дату в дату по маске со смещением в днях
     *
     * @param date    Дата в виде Integer или String
     * @param pattern маска входной/выходной даты
     * @param offset  смещение в днях. (например: +3 -500)
     * @return Преобразованная дата того же типа, что и переданный параметр {@code date}
     */
    public static Object parseOffsetFormat(Object date, String pattern, int offset) {
        return parseOffsetFormat(date, pattern, offset, ChronoUnit.DAYS);
    }

    /**
     * Преобразует входную дату в дату по маске со смещением в указанных единицах
     *
     * @param date    Дата в виде Integer или String
     * @param pattern маска входной/выходной даты или имя маски
     * @param offset  смещение в указанных единицах. (например: +3 -500)
     * @param units   единица смещения даты: год/месяц/день/час/минута/секунда
     * @return Преобразованная дата
     */
    public static Object parseOffsetFormat(Object date, String pattern, int offset, TemporalUnit units) {
        LocalDateTime localDateTime = parse(date, pattern);
        localDateTime = offset(localDateTime, offset, units);
        return format(localDateTime, date.getClass(), pattern);
    }

    /**
     * Перегрузка: Аналогично следующему методу, но без смещения.
     *
     * @param date          Дата в виде Integer или String
     * @param inputPattern  Маска входной даты
     * @param outputType    Класс возвращаемой даты, Date, String, Integer
     * @param outputPattern Маска выодной даты
     * @param <T>           Тип возвращаемой даты
     * @return Преобразованная дата указанного типа
     */
    public static <T> T parseFormat(Object date, String inputPattern, Class<T> outputType, String outputPattern) {
        LocalDateTime localDateTime = parse(date, inputPattern);
        return format(localDateTime, outputType, outputPattern);
    }

    /**
     * Преобразует дату из формата в формат или со сохранением формата, с возможностью смещения в указанных единицах
     *
     * @param date                       дата типа Date, String, Integer (int)
     * @param inputPattern  маска входной даты. можно указать bis или ru
     * @param outputType                 тип возвращаемой даты, Date, String, Integer
     * @param outputPattern маска выходной даты. можно указать bis или ru
     * @param offset                     смещение в указанных единицах (например: +3 , -700)
     * @param units                      единица смещения даты: год/месяц/день/час/минута/секунда
     * @param <T>                        тип возвращаемой даты
     * @return Преобразованная дата указанного типа
     * @throws AssertionError Если неверна маска или тип выходной даты не поддерживается методом
     */
    public static <T> T dateWorker(Object date, String inputPattern, Class<T> outputType, String outputPattern, int offset, TemporalUnit units) {
        LocalDateTime victimDate = parse(date, inputPattern);
        victimDate = offset(victimDate, offset, units);
        return format(victimDate, outputType, outputPattern);
    }

    /**
     * Преобразует даты к строке по указанному шаблону (маске)
     *
     * @param date      входная дата
     * @param myPattern маска
     * @return Строковое представление входной даты
     */
    public static String getStringByPattern(LocalDateTime date, final String myPattern) {
        return date.format(DateTimeFormatter.ofPattern(myPattern));
    }

    /**
     * Парсит дату из строки по маске
     *
     * @param date      строковое представление даты
     * @param myPattern маска входной даты
     * @return дата
     */
    public static LocalDateTime parseStringDate(String date, String myPattern) {
        return LocalDateTime.parse(date, DateTimeFormatter.ofPattern(myPattern));
    }

    /**
     * Метод получает дату в БИС формате (1180901) из строки
     *
     * @param text Текст из которого нужно вытащить дату
     * @return String дата в БИС формате
     */
    public static String getBISDateFromText(String text) {

        Matcher matcher = bisDatePattern.matcher(text);

        if (matcher.find()) {
            return matcher.group(0);
        }

        throw new AssertionError("Дата БИС не получена. Проверьте источник.");
    }

    /**
     * <p>Получает разницу между датами в днях</p>
     *
     * @param date1 формат Date Дата №1
     * @param date2 формат Date Дата №2
     * @return long кол-во дней между датами
     */
    public static long getDiffBetweenDates(LocalDate date1, LocalDate date2) {
        LocalDate start = date1.isBefore(date2) ? date1 : date2;
        LocalDate end = date1.isBefore(date2) ? date2 : date1;
        return Duration.between(start.atStartOfDay(), end.atStartOfDay()).toDays();
    }

    /**
     * <p>Получает маску даты по названию</p>
     * <ul>
     * <li><span style='color:green;'>бис, bis</span> соответствуют маске <span style='color:green;'>"1yyMMdd"</span></li>
     * <li><span style='color:green;'>ру,ru</span> соответствуют маске "<span style='color:green;'>dd.MM.yyyy"</span></li>
     * </ul>
     *
     * @param pattern название маски
     * @return маска
     */
    private static String getPatternByName(String pattern) {
        switch (pattern.trim().toLowerCase()) {
            case "бис":
            case "bis":
                return "1yyMMdd";
            case "ru":
            case "ру":
                return "dd.MM.yyyy";
            default:
                return pattern;
        }
    }

}
