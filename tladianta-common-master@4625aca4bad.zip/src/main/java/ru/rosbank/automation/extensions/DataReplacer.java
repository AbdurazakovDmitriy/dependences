package ru.rosbank.automation.extensions;

import com.google.common.reflect.ClassPath;
import cucumber.api.PickleStepTestStep;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.reflect.FieldUtils;
import ru.rosbank.automation.annotations.Generator;
import ru.rosbank.automation.annotations.GeneratorTitle;
import ru.rosbank.automation.exceptions.DataGeneratorException;
import ru.rosbank.automation.exceptions.DataGeneratorKeyNotFoundException;
import ru.sbtqa.tag.pagefactory.optional.PickleStepTag;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public final class DataReplacer {

    private static final HashMap<String, Method> generators = new HashMap<>();

    private final static Pattern STEP_DATA_PATTERN = Pattern.compile("(?:~\\{([^}]+):([^}]+)})");
    private final static Pattern STASH_PARSER = Pattern.compile("(?:\\#\\{([^\\}]+)\\})");


    /**
     * Инициализация списка функций генерации на основе классов расположенных в пакете.
     * Клас должен быть помечен аттрибутом @Generator, включать статические методы String->String с аттрибутом @GeneratorTitle
     *
     * @param path
     */
    public static void addGenerators(String path) {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();

        try {
            for (ClassPath.ClassInfo info : ClassPath.from(loader).getTopLevelClassesRecursive(path)) {
                Class clazz = info.load();

                Generator generator = (Generator) clazz.getAnnotation(Generator.class);
                if (generator != null) {
                    Method[] array = clazz.getMethods();
                    for (Method method : array) {
                        GeneratorTitle generatorTitle = method.getAnnotation(GeneratorTitle.class);
                        if (generatorTitle != null && Modifier.isStatic(method.getModifiers())) {
                            generators.put(generatorTitle.value(), method);
                        }
                    }
                }
            }
        } catch (IOException ex) {
            log.warn("Ошибка сбора генераторов данных", ex);
        }
    }

    /**
     * Замена текста степа с учетом генерации данных.
     *
     * @param testStep - Степ
     */
    public void replace(PickleStepTestStep testStep) {
        PickleStepTag step = (PickleStepTag) testStep.getPickleStep();
        String newText = replaceData(step, step.getText());
        step.setText(newText);
    }

    public void replaceStepArguments(PickleStepTestStep testStep, boolean isStash) throws IllegalAccessException {
        PickleStepTag step = (PickleStepTag) testStep.getPickleStep();
        String stepText = step.getText();

        Pattern stepDataPattern = isStash ? STASH_PARSER : STEP_DATA_PATTERN;
        Matcher stepDataMatcher = stepDataPattern.matcher(stepText);

        int offset = 0;
        for (cucumber.api.Argument argument : testStep.getDefinitionArgument()) {
            String argVal = argument.getValue();

            if (argVal != null) {
                String data = replaceData(step, argVal);
                boolean isReplaceNeededParameter = stepDataPattern.matcher(argVal).find() && stepDataMatcher.find();
                Object group = FieldUtils.readField(argument, "group", true);
                if (isReplaceNeededParameter && offset == 0) {
                    // this is first replace-needed parameter
                    offset = data.length() - argVal.length();
                    FieldUtils.writeField(group, "value", data, true);
                    FieldUtils.writeField(group, "end", argument.getEnd() + offset, true);
                } else if (isReplaceNeededParameter) {
                    // this is not first replace-needed parameter
                    FieldUtils.writeField(group, "value", data, true);
                    FieldUtils.writeField(group, "start", argument.getStart() + offset, true);
                    int thisOffset = data.length() - argVal.length();
                    FieldUtils.writeField(group, "end", argument.getEnd() + offset + thisOffset, true);
                    offset += thisOffset;
                } else if (offset != 0) {
                    // this is ordinary parameter
                    FieldUtils.writeField(group, "start", argument.getStart() + offset, true);
                    FieldUtils.writeField(group, "end", argument.getEnd() + offset, true);
                }
            }
        }
    }

    /**
     * Генерация значения на основе ключа и параметра, по ключу выбирается соответствующий метод.
     *
     * @param name   - Имя подстановки
     * @param params - Параметров подстановки
     * @return - Результат генерации для подстановки
     */
    private String getValue(String name, String params) {
        if (generators.containsKey(name)) {
            try {
                return generators.get(name).invoke(null, params).toString();
            } catch (IllegalAccessException | InvocationTargetException e) {
                throw new DataGeneratorException("Ошибка генерации значения", e);
            }
        } else {
            throw new DataGeneratorKeyNotFoundException(String.format("Key %s for data generation not found", name));
        }
    }


    /**
     * Обработка и логирование искючений при генерации
     *
     * @param currentStep - Степ
     * @param raw         - Текст для подстановки
     * @return - Текст после подстановки
     */
    private String replaceData(PickleStepTag currentStep, String raw) {
        String replacedText = raw;
        try {
            replacedText = replaceGeneratorPlaceholders(raw);
        } catch (Throwable ex) {
            saveMessage(currentStep, ex);
        }
        return replacedText;
    }

    /**
     * Поиск всех подстановок и вызов функций генерации.
     *
     * @param replaceableValue - Текст для подстановок
     * @return - Текст с проведенными подстановками
     */
    private String replaceGeneratorPlaceholders(String replaceableValue) {

        Matcher stepDataMatcher = STEP_DATA_PATTERN.matcher(replaceableValue);
        StringBuilder replacedValue = new StringBuilder(replaceableValue);

        while (stepDataMatcher.find()) {
            String key = stepDataMatcher.group(1);
            String value = stepDataMatcher.group(2);

            String dataValue = getValue(key, value);
            replacedValue.replace(stepDataMatcher.start(), stepDataMatcher.end(), dataValue);
            stepDataMatcher = STEP_DATA_PATTERN.matcher(replacedValue);
        }
        return replacedValue.toString();
    }

    /**
     * Логирование и вывод ошибок.
     *
     * @param currentStep - Степ
     * @param message     - Исключение
     */
    private void saveMessage(PickleStepTag currentStep, Throwable message) {
        if (currentStep.isSkipped()) {
            currentStep.setLog(message.getMessage());
        } else {
            currentStep.setError(message);
        }
    }
}