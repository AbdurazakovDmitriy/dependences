package ru.rosbank.automation.environment;

public interface IContext {
}
