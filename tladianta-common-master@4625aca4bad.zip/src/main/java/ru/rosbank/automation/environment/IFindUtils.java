package ru.rosbank.automation.environment;

import ru.sbtqa.tag.pagefactory.Page;
import ru.sbtqa.tag.pagefactory.exceptions.ElementDescriptionException;
import ru.sbtqa.tag.pagefactory.exceptions.PageException;
import ru.sbtqa.tag.pagefactory.find.Find;

import java.util.List;
import java.util.Map;

public interface IFindUtils<TypeElement, ContextType> extends Find, ISourceProvider<Find> {

    /**
     * Находит на странице элемент по имени
     *
     * @param page объект страницы / контекст поиска элемента
     * @param elementTitle имя элемента на странице /контексте
     * @return значение поля страницы
     * @throws PageException страница не инициализирована или элемент на ней не найден
     */
    @Override
    default <T> T getElementByTitle(Page page, String elementTitle) throws PageException{
        return getSource().getElementByTitle(page, elementTitle);
    }

    /**
     * Находит на текущей странице элемент по его имени или пути.
     * <p>
     * В качестве пути используется цепочка элементов вложенных друг в друга, раделенная символом "{@code ->}"
     * Например,
     * <ul>
     *  <li> элемент в блоке: <span style='color:green;'>Имя блока{@code ->}Имя элемента</span>
     *  <li> элемент в списке элементов с порядковым номером 3: <span style='color:green;'>Счета{@code ->}3</span>
     * </ul>
     * <p>
     *     Если элемент не найден сразу, тогда ожидает его появления
     *
     * @param name имя или путь искомого элемента
     * @return найденный элемент страницы
     */
    default <T extends TypeElement> T find(String name) {
        return find(name, true);
    }

    /**
     * Находит на текущей странице элемент по его имени или пути.
     * Можно указать, ожидать ли появления элемента, в случае его отсутствия.
     * <p>
     * В качестве пути используется цепочка элементов вложенных друг в друга, раделенная символом "{@code ->}"
     * Например,
     * <ul>
     *  <li> элемент в блоке: <span style='color:green;'>Имя блока{@code ->}Имя элемента</span>
     *  <li> элемент в списке элементов с порядковым номером 3: <span style='color:green;'>Счета{@code ->}3</span>
     * </ul>
     * <p>
     *
     * @param name имя или путь искомого элемента
     * @param wait флаг, ожидать ли появления элемента
     * @return найденный элемент страницы
     */
    default <T extends TypeElement> T find(String name, boolean wait) {
        return find(null, name, wait);
    }

    /**
     * Находит элемент по его имени или пути на указанной транице или блоке.
     * <p>
     * В качестве пути используется цепочка элементов вложенных друг в друга, раделенная символом "{@code ->}"
     * Например,
     * <ul>
     *  <li> элемент в блоке: <span style='color:green;'>Имя блока{@code ->}Имя элемента</span>
     *  <li> элемент в списке элементов с порядковым номером 3: <span style='color:green;'>Счета{@code ->}3</span>
     * </ul>
     * <p>
     *
     * @param context контекст поиска элемента current context - where to start searching for an element.
     * {@code null} - если нужно искать на текущей странице или передать объект страницы или блока
     * @param name имя или путь искомого элемента
     * @param wait флаг, ожидать ли появления элемента
     * @return найденный элемент страницы
     */
    <T extends TypeElement, E extends ContextType> T find(E context, String name, boolean wait);

    /**
     * Находит на текущей странице элемент-список по имени или пути, если на странице несколько одинаковых элементов,
     * которые объединены на странице в один элемент-коллекцию типа {@link List}
     * <p>
     * В качестве пути используется цепочка элементов вложенных друг в друга, раделенная символом "{@code ->}"
     * Например,
     * <ul>
     *  <li> элемент в блоке: <span style='color:green;'>Имя блока{@code ->}Имя элемента</span>
     *  <li> элемент в списке элементов с порядковым номером 3: <span style='color:green;'>Счета{@code ->}3</span>
     * </ul>
     * <p>
     *
     * @param name имя элемента-списка или путь к нему
     * @return найденный элемент-список
     * @throws ru.sbtqa.tag.pagefactory.exceptions.ElementDescriptionException ошибка описания элемента(ов)
     */
    <T extends TypeElement> List<T> findList(String name) throws ElementDescriptionException;

    /**
     * Находит элемент-список по имени или пути, если на странице несколько одинаковых элементов,
     * которые объединены на странице в один элемент-коллекцию типа {@link List}.
     * <p>Контекст поиска нужно указать - страница или блок.</p>
     *
     * <p>
     * В качестве пути используется цепочка элементов вложенных друг в друга, раделенная символом "{@code ->}"
     * Например,
     * <ul>
     *  <li> элемент в блоке: <span style='color:green;'>Имя блока{@code ->}Имя элемента</span>
     *  <li> элемент в списке элементов с порядковым номером 3: <span style='color:green;'>Счета{@code ->}3</span>
     * </ul>
     * <p>
     *
     * @param context контекст поиска элемента current context - where to start searching for an element.
     * {@code null} - если нужно искать на текущей странице или передать объект страницы или блока
     * @param name имя элемента-списка или путь к нему
     * @return найденный элемент-список
     * @throws ru.sbtqa.tag.pagefactory.exceptions.ElementDescriptionException ошибка поиска элемента по имени
     */
    <T extends TypeElement, E extends ContextType> List<T> findList(E context, String name) throws ElementDescriptionException;

    /**
     * Находит на текущей странице элемент по имени или пути
     * <p>
     * В качестве пути используется цепочка элементов вложенных друг в друга, раделенная символом "{@code ->}"
     * Например,
     * <ul>
     *  <li> элемент в блоке: <span style='color:green;'>Имя блока{@code ->}Имя элемента</span>
     *  <li> элемент в списке элементов с порядковым номером 3: <span style='color:green;'>Счета{@code ->}3</span>
     * </ul>
     *     Если на странице элемент имеет тип {@code WebElement},
     *     тогда будет предпринята попытка конвертировать его в переданный тип, если это возможно
     * <p>
     * По-умоланию, ждет появления элемента на странице
     *
     * @param name имя элемента-списка или путь к нему
     * @param type нужный тип искомого элемента
     * @return найденный элемент страницы
     */
    default  <T extends TypeElement> T find(String name, Class<T> type) {
        return find(name, type, true);
    }

    /**
     * Находит на текущей странице элемент по имени или пути
     * <p>
     * В качестве пути используется цепочка элементов вложенных друг в друга, раделенная символом "{@code ->}"
     * Например,
     * <ul>
     *  <li> элемент в блоке: <span style='color:green;'>Имя блока{@code ->}Имя элемента</span>
     *  <li> элемент в списке элементов с порядковым номером 3: <span style='color:green;'>Счета{@code ->}3</span>
     * </ul>
     *     Если на странице элемент имеет тип {@code WebElement},
     *     тогда будет предпринята попытка конвертировать его в переданный тип, если это возможно
     * <p>
     *
     * @param name имя элемента-списка или путь к нему
     * @param type нужный тип искомого элемента
     * @param wait флаг, ожидать ли появления элемента
     * @return найденный элемент страницы
     */
    <T extends TypeElement> T find(String name, Class<T> type, boolean wait);

    /**
     * Находит на текущей странице элемент по имени или пути
     * <p>
     * В качестве пути используется цепочка элементов вложенных друг в друга, раделенная символом "{@code ->}"
     * Например,
     * <ul>
     *  <li> элемент в блоке: <span style='color:green;'>Имя блока{@code ->}Имя элемента</span>
     *  <li> элемент в списке элементов с порядковым номером 3: <span style='color:green;'>Счета{@code ->}3</span>
     * </ul>
     *     Если на странице элемент имеет тип {@code WebElement},
     *     тогда будет предпринята попытка конвертировать его в переданный тип, если это возможно
     * <p>
     * По-умоланию, ждет появления элемента на странице
     *
     * @param name имя элемента-списка или путь к нему
     * @param clazz список возможных типов элемента. Если найденный элемент не оответствует ни одному типу из списка,
     *              тогда будет выброшено исключение.
     * @return найденный элемент страницы
     */
    default  <T extends TypeElement> T find(String name, List<Class> clazz) {
        return find(name, clazz, true);
    }

    /**
     * Находит на текущей странице элемент по имени или пути
     * <p>
     * В качестве пути используется цепочка элементов вложенных друг в друга, раделенная символом "{@code ->}"
     * Например,
     * <ul>
     *  <li> элемент в блоке: <span style='color:green;'>Имя блока{@code ->}Имя элемента</span>
     *  <li> элемент в списке элементов с порядковым номером 3: <span style='color:green;'>Счета{@code ->}3</span>
     * </ul>
     *     Если на странице элемент имеет тип {@code WebElement},
     *     тогда будет предпринята попытка конвертировать его в переданный тип, если это возможно
     * <p>
     *
     * @param <T> параметр типа возвращаемого элемента
     * @param name имя элемента-списка или путь к нему
     * @param clazz список возможных типов элемента. Если найденный элемент не оответствует ни одному типу из списка,
     *              тогда будет выброшено исключение.
     * @param wait флаг, ожидать ли появления элемента
     * @return найденный элемент страницы
     */
    <T extends TypeElement> T find(String name, List<Class> clazz, boolean wait);

    /**
     * Возвращает карту типов: тип аттрибута - тип.
     * <p>Данные берет из json-файла, указанного в свойстве конфигурации '<span style='color:green;'>ui.types</span>'</p>
     *
     * @return Returns a type map
     */
    Map<String, Class> getElementTypesMap();

}
