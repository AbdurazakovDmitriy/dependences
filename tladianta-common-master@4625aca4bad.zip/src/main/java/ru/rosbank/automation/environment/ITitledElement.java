package ru.rosbank.automation.environment;

import org.apache.commons.lang3.reflect.FieldUtils;
import ru.sbtqa.tag.pagefactory.exceptions.PageException;

/**
 * Интерфейс для элементов страниц, имеющих имена, в дефолтной реализации просто считывающий значение поля title
 */
public interface ITitledElement {
    default String getTitle() throws PageException {
        try {
            return (String) FieldUtils.getAllFieldsList(this.getClass()).stream()
                    .filter(o -> o.getName().equals("title"))
                    .peek(o -> o.setAccessible(true))
                    .findFirst()
                    .orElseThrow(() -> new PageException("Переопредели этот метод или создай поле title в своем классе"))
                    .get(this);
        } catch (IllegalAccessException e){
            throw new PageException(e);
        }
    }
}