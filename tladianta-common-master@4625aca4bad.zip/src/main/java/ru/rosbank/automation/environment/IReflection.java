package ru.rosbank.automation.environment;

import gherkin.ast.ScenarioDefinition;
import gherkin.ast.Tag;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import ru.sbtqa.tag.pagefactory.Page;
import ru.sbtqa.tag.pagefactory.annotations.ActionTitle;
import ru.sbtqa.tag.pagefactory.annotations.ActionTitles;
import ru.sbtqa.tag.pagefactory.annotations.ElementTitle;
import ru.sbtqa.tag.pagefactory.annotations.ValidationRule;
import ru.sbtqa.tag.pagefactory.exceptions.ElementDescriptionException;
import ru.sbtqa.tag.pagefactory.exceptions.FactoryRuntimeException;
import ru.sbtqa.tag.pagefactory.exceptions.PageException;
import ru.sbtqa.tag.pagefactory.reflection.Reflection;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import static org.apache.commons.lang3.reflect.MethodUtils.invokeMethod;

public interface IReflection extends Reflection, ISourceProvider<Reflection> {

    default String getAnnotationField(@NotNull Class<?> targetType, Class<? extends Annotation> annotationType, String fieldName) {
        return getAnnotationField(targetType, annotationType, fieldName, false);
    }

    /**
     * Ищет значение поля у аннотации класса
     *
     * @param targetType     Класс
     * @param annotationType тип аннотации
     * @param fieldName      поле, которое нужно получить
     * @param soft           возвращать при ошибки исключение или пустую строку
     * @return значение поле
     */
    default String getAnnotationField(@NotNull Class<?> targetType, Class<? extends Annotation> annotationType, String fieldName, boolean soft) {

        StringBuilder message = new StringBuilder();

        if (targetType.isAnnotationPresent(annotationType)) {
            Annotation annotation = targetType.getAnnotation(annotationType);
            try {
                return (String) invokeMethod(annotation, fieldName);
            } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                message.append("У аннотации нет свойства '").append(fieldName).append("'\n");
            }
        } else {
            message.append("У класса нет аннотации '").append(annotationType.getName()).append("'\n");
        }

        if (message.length() > 0 && !soft) {
            throw new FactoryRuntimeException(message.toString());
        }

        return StringUtils.EMPTY;
    }

    /**
     * Ищет переданный элемент страницы в репозитории страниц, который создается перед началом исполнения сценариев.
     * Если элемент найден, тогда возвращается его имя из аннотации {@link ElementTitle}
     * Если ничего не найдено, возвращает результат метода {@code toString()} элемента
     *
     * @param element объект элемента, который нужно найти
     * @param page    страница на которой нужно искать элемент
     * @return имя элемента, значение аннотации {@link ElementTitle}
     */
    default String getElementTitle(Page page, Object element) {
        return getSource().getElementTitle(page, element);
    }

    /**
     * Находит метод(Action) у объекта и выполняет его с параметрами или без
     *
     * @param context объект, в котором будет выполняться поиск метода: страница или блок
     * @param title   имя метода, который нужно выполнить
     * @param param   параметры вызываемого метода
     * @throws java.lang.NoSuchMethodException метод не найден
     */
    default void executeMethodByTitle(Object context, String title, Object... param) throws NoSuchMethodException {
        getSource().executeMethodByTitle(context, title, param);
    }

    /**
     * Исполняет метод(Action) с параметрами или без внутри переданного блока.
     * Блок может буть указан как имя или как путь к блоку с использованием разделителя-стрелки {@code "->"}.
     *
     * @param blockPath   имя блока или путь к нему через стрелку {@code "->"}
     * @param actionTitle имя действия (action) чей метод нужно выполнить
     * @param parameters  параметры метода-действия
     */
    void executeMethodByTitleInBlock(String blockPath, String actionTitle, Object... parameters);

    /**
     * Возвращает список методов, объявленных в классе и его родителе
     *
     * @param clazz класс
     * @return список методов класса или путой писок
     */
    default List<Method> getDeclaredMethods(Class clazz) {
        return getSource().getDeclaredMethods(clazz);
    }

    /**
     * Проверяет, что переданный метод имеет аннотацию {@link ActionTitle} или
     * {@link ActionTitles} с указанным именем действия
     *
     * @param method проверяемый метод
     * @param title  искомое имя действия
     * @return true|false
     */
    default Boolean isRequiredAction(Method method, final String title) {
        return getSource().isRequiredAction(method, title);
    }

    /**
     * Проверяет что значение аннотации {@link ElementTitle} поля соответствует переданному.
     *
     * @param field проверяемое поле класса
     * @param title ожидаемое значение ElementTitle
     * @return true|false
     */
    default boolean isRequiredElement(Field field, String title) {
        return getSource().isRequiredElement(field, title);
    }

    /**
     * Возвращает значение аннотации {@link ElementTitle} переданного поля.
     * <p>Если не найдено, тогда возвращает пустую строку.</p>
     *
     * @param field проверяемое поле класса
     * @return имя элемента или пустая строка
     */
    default String getFieldTitle(Field field) {
        return getSource().getFieldTitle(field);
    }

    /**
     * Получает значение из поля указанного класса-родителя
     *
     * @param parentObject объект, который содержит указанное поле
     * @param field        поле класса-родителя
     * @param <T>          параметр типа поля. Если значение поля нельзя привести к этому типу, выбросит исключение.
     * @return значение поля класса
     * @throws ElementDescriptionException если поле не принадлежит объекту или элемент нельзя привести к типу
     */
    default <T> T getElementByField(Object parentObject, Field field) throws ElementDescriptionException {
        return getSource().getElementByField(parentObject, field);
    }

    /**
     * Находит на странице метод с аннотацией {@link ValidationRule} и вызывает его
     *
     * @param page   объект страницы, на которой находится искомый метод
     * @param title  значение аннотации ValidationRule
     * @param params параметры вызываемого метода
     * @throws ru.sbtqa.tag.pagefactory.exceptions.PageException метод не найден на странице
     */
    default void fireValidationRule(Page page, String title, Object... params) throws PageException {
        getSource().fireValidationRule(page, title, params);
    }

    /**
     * Возвращает теги сценария
     *
     * @param scenarioDefinition описание сценария
     * @return список тегов
     */
    default List<Tag> getScenarioTags(ScenarioDefinition scenarioDefinition) {
        return getSource().getScenarioTags(scenarioDefinition);
    }
}
