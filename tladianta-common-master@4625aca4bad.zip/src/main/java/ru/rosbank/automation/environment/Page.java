package ru.rosbank.automation.environment;

public abstract class Page implements ru.sbtqa.tag.pagefactory.Page, IContext {
    /**
     * конструктор страницы
     */
    protected Page() {
        initContext();
        initPage();
        initSteps();
        initEnvironment();
    }

    protected abstract void initEnvironment();

    protected abstract void initSteps();

    /**
     * инциализируй контекст платформы здесь
     */
    protected abstract void initContext();

    /**
     * инициадизация контекста страниц
     */
    protected abstract void initPage();
}
