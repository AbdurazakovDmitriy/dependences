package ru.rosbank.automation.environment;

import ru.sbtqa.tag.pagefactory.checks.PageChecks;
import ru.sbtqa.tag.qautils.strategies.MatchStrategy;

public interface IPageChecks extends PageChecks, ISourceProvider<PageChecks> {

    /**
     * Проверяет равенство значения элемента переданному тексту.
     *
     * @param element элемент страницы
     * @param text ожидаемый текст
     * @return true-равно, false - не равно
     */
    @Override
    default boolean checkEquality(Object element, String text){
        return getSource().checkEquality(element, text);
    }

    /**
     * Проверяет, что значение элемента пусто
     *
     * @param element элемент страницы
     * @return true/false
     */
    @Override
    default boolean checkEmptiness(Object element){
        return getSource().checkEmptiness(element);
    }

    /**
     * Сравнивает значение элемента с ожидаемым, используя стратегию сравнения EXACT/CONTAINS
     * @param element элемент страницы
     * @param text ожидаемый текст
     * @param matchStrategy стратегия сравнения
     * @return true/false
     */
    boolean checkEquality(Object element, String text, MatchStrategy matchStrategy);
}
