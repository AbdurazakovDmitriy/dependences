package ru.rosbank.automation.environment;

import ru.sbtqa.tag.pagefactory.environment.Environment;

@SuppressWarnings("ALL")
public interface IEnvironmentProvider<Find, Actions, Checks, Reflection> {

    default Actions actions(){
        return (Actions) Environment.getPageActions();
    }

    default Checks pageChecks() {
        return (Checks) Environment.getPageChecks();
    }

    default Find findUtils(){
        return (Find) Environment.getFindUtils();
    }

    default Reflection reflection(){
        return (Reflection) Environment.getReflection();
    }
}
