package ru.rosbank.automation.environment;

import ru.sbtqa.tag.pagefactory.actions.PageActions;

public interface IPageActions extends PageActions, ISourceProvider<PageActions> {

    @Override
    default void fill(Object element, String value){
        getSource().fill(element, value);
    }

    @Override
    default void click(Object element){
        getSource().click(element);
    }

    @Override
    default void press(Object element, String key){
        getSource().press(element, key);
    }

    @Override
    default void select(Object element, String option){
        getSource().select(element, option);
    }

    @Override
    default void setCheckbox(Object element, boolean state){
        getSource().setCheckbox(element, state);
    }
}
