package ru.rosbank.automation.environment;

public interface ISourceProvider<T> {
    T getSource();
}
