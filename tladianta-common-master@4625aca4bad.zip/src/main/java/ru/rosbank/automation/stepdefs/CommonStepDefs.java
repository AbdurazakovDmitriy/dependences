package ru.rosbank.automation.stepdefs;

import cucumber.api.java.ru.*;
import io.cucumber.datatable.DataTable;
import ru.rosbank.automation.configuration.ApplicationContext;
import ru.rosbank.automation.steps.CommonSteps;
import ru.rosbank.automation.transformer.NegationCondition;
import ru.sbtqa.tag.pagefactory.exceptions.PageException;
import ru.sbtqa.tag.pagefactory.exceptions.PageInitializationException;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

/**
 * Шаги Gherkin, расширяющие список шагов ядра.
 */
public class CommonStepDefs {

    private CommonSteps steps() {
        return (CommonSteps) ApplicationContext.getStepsImpl("CommonSteps");
    }

    @И("^(?:пользователь |он )?переходит на URL страницы \"([^\"]*)\"$")
    @Когда("^(?:я )?перехожу на URL страницы \"([^\"]*)\"$")
    public void goToUrlPage(String namePage) throws PageInitializationException {
        steps().openPageUrl(namePage);
    }

    @И("^(?:пользователь |он )?в выпадающем списке \"([^\"]*)\" выбирает произвольную опцию$")
    public void selectRandomOption(String listTitle) {
        steps().selectRandomOption(listTitle);
    }

    @И("^(?:пользователь |он )?запоминает значение (?:поля|элемента) \"([^\"]*)\" (?:в переменную|под именем) \"([^\"]*)\"$")
    @Когда("^(?:я )?запоминаю значение (?:поля|элемента) \"([^\"]*)\" (?:в переменную|под именем) \"([^\"]*)\"$")
    public void saveElementValueInStash(String elementName, String variableName) throws PageException {
        steps().saveElementValueInStash(elementName, variableName);
    }

    @И("^(?:пользователь |он )?запоминает значение \"([^\"]*)\" (?:в переменную|под именем) \"([^\"]*)\"$")
    @Когда("^(?:я )?запоминаю значение \"([^\"]*)\" (?:в переменную|под именем) \"([^\"]*)\"$")
    public void saveTextInStash(String text, String variableName) throws PageException {
        steps().writeInStash(text, variableName);
    }

    @Когда("^(?:пользователь |он )?проверяет(?:,|) что (?:флаг|чекбокс) \"([^\"]*)\" (не |)установлен$")
    @Тогда("^(?:я )?проверяю, что (?:флаг|чекбокс) \"([^\"]*)\" (не |)установлен$")
    @И("^признак \"([^\"]*)\" (не )?отмечен$")
    public void verifyCheckBox(String elementName, NegationCondition negation) throws PageException {
        steps().verifyCheckBox(elementName, negation);
    }

    @И("^(?:пользователь |он )?снимает ?(?:чекбокс|флаг) \"([^\"]*)\"$")
    @Когда("^(?:я )?снимаю ?(?:чекбокс|флаг) \"([^\"]*)\"$")
    public void unsetCheckBox(String elementTitle) throws PageException {
        steps().unsetCheckBox(elementTitle);
    }

    @И("^(?:пользователь |он )?заполняет поле посимвольно \"([^\"]*)\" (?:значением )?\"([^\"]*)\"$")
    @Когда("^(?:я )?заполняю поле посимвольно \"([^\"]*)\" (?:значением )?\"([^\"]*)\"$")
    public void slowFill(String elementTitle, String text) throws PageException {
        steps().slowFill(elementTitle, text);
    }

    @И("^(?:пользователь |он )?(?:переходит в приложение|активизирует приложение|переключается на контекст приложения) \"([^\"]*)\"$")
    @Когда("^(?:я )?(?:перехожу в приложение|активизирую приложение|переключаюсь на контекст приложения) \"([^\"]*)\"$")
    public void resetApplicationContext(String appName) {
        steps().resetApplicationContext(appName);
    }

    @И("^он печатает свойства текущего модуля$")
    @Когда("^я печатаю свойства текущего модуля$")
    public void printPropsStepDef() {
        steps().printProps();
    }

    @И("^(?:пользователь |он )?очищает поля:$")
    @Когда("^(?:я )?очищаю поля:$")
    public void clearFields(List<String> elementTitles) throws PageException {
        steps().clearFields(elementTitles);
    }

    @Когда("^(?:пользователь |он )?заполняет (?:форму|поля значениями)?:$")
    @Тогда("^(?:я )?заполняю (?:форму|поля значениями)?:$")
    @И("^(?:пользователь |он )?отмечает признаки:$")
    @То("^(?:я )?отмечаю признаки:$")
    public void fillFields(DataTable dataTable) throws PageException {
        steps().fillFields(dataTable);
    }

    @И("^(?:пользователь |он )?посимвольно заполняет (?:форму|поля значениями)?:$")
    @Когда("^(?:я )?посимвольно заполняю (?:форму|поля значениями)?:$")
    public void slowFillFields(DataTable dataTable) throws PageException {
        steps().slowFillFields(dataTable);
    }

    @Когда("^(?:пользователь |он )?проверяет (?:форму|значение полей):$")
    @И("^(?:я )?проверяю (?:форму|значения полей):$")
    public void checkFields(DataTable dataTable) throws PageException {
        steps().checkFields(dataTable);
    }

    @Когда("^(?:пользователь |он )?проверяет(?:,|) что поля (не |)пустые:$")
    @И("^поля (не |)пустые:$")
    public void checkFieldsForEmpty(NegationCondition negation, List<String> elementNames) throws PageException {
        steps().checkFieldsForEmpty(negation, elementNames);
    }

    @Когда("^(?:пользователь |он )?нажимает клавишу \"([^\"]*)\" (\\d+) раз$")
    @И("^(?:я )?нажимаю клавишу \"([^\"]*)\" (\\d+) раз$")
    public void pressKeyNTimes(String keyName, int counts) {
        steps().pressKey(keyName, counts);
    }

    @Когда("^(?:пользователь |он )?проверяет(?:,|) что (?:элемент|поле) \"([^\"]*)\" (не |)(?:активен|активно|доступен|доступно)$")
    @Дано("^элемент \"([^\"]*)\" (не)?доступен для редактирования$")
    @И("^элемент \"([^\"]*)\" (не)?активен$")
    public void checkElementAvailability(String elementTitle, NegationCondition negation) throws PageException {
        steps().checkElementAvailability(elementTitle, negation);
    }

    @Когда("^элементы (не|)доступны для редактирования:$")
    @И("^присутствуют (не|)активные элементы:$")
    public void checkElementsAvailability(NegationCondition condition, List<String> elementNames) throws PageException {
        steps().checkElementsAvailability(condition, elementNames);
    }

    @Когда("^(?:пользователь |он )?ожидает (\\d+) секунд(?:|ду|ы)$")
    @И("^пауза (\\d+) секунд(?:|а|ы)$")
    public void sleep(int timeout) throws InterruptedException {
        steps().sleep(timeout);
    }

    @Когда("^(?:пользователь |он )?проверяет(?:,|) что (?:элемент|поле) \"([^\"]*)\" (не |)отображается$")
    @Дано("^элемент \"([^\"]*)\" обязательно (при|от)сутствует на странице$")
    @И("^элемент \"([^\"]*)\" (присутствует|не отображается)$")
    public void elementAlwaysPresent(String elementName, NegationCondition negation) throws PageException {
        steps().checkElementVisibility(elementName, negation);
    }

    @Когда("^(?:пользователь |он )?находит (?:элемент|поле) \"([^\"]*)\"$")
    @И("^(?:я )?нахожу (?:элемент|поле) \"([^\"]*)\"$")
    public void checkElementVisibility(String elementTitle) throws PageException {
        steps().checkElementVisibility(elementTitle, new NegationCondition(""));
    }

    @Когда("^элементы обязательно (при|от)сутствуют на странице:$")
    @И("^(присутствуют|не отображаются) элементы:$")
    public void elementsAlwaysPresent(NegationCondition present, List<String> elementNames) throws PageException {
        steps().checkElementsVisibility(present, elementNames);
    }

    @Когда("^(?:пользователь |он )?проверяет(?:,|) что файл \"([^\"]*)\" (не |)существует$")
    @И("^файл \"([^\"]*)\" (не |)существует$")
    public void checkFileExist(String filePath, NegationCondition negation) {
        List<String> list = Collections.singletonList(filePath);
        if (negation.isPositive()) {
            steps().checkFilesExist(list);
        } else {
            steps().checkFilesNotExist(list);
        }
    }

    @Когда("^(?:пользователь |он )?проверяет(?:,|) что файлы (при|от)сутствуют на диске:$")
    @И("^файлы (при|от)сутствуют на диске:$")
    public void checkFilesExists(NegationCondition presence, List<String> filePaths) {
        if (presence.isPositive()) {
            steps().checkFilesExist(filePaths);
        } else {
            steps().checkFilesNotExist(filePaths);
        }
    }

    @И("^(?:пользователь |он )?удаляет файлы из списка:$")
    @Когда("^(?:я )?удаляю файлы из списка:$")
    public void deleteFiles(List<String> filePaths) throws IOException {
        steps().deleteFiles(filePaths);
    }

    @И("^(?:пользователь |он )?удаляет файл \"([^\"]*)\"$")
    @Когда("^(?:я )?удаляю файл \"([^\"]*)\"$")
    public void deleteFile(String filePath) throws IOException {
        steps().deleteFiles(Collections.singletonList(filePath));
    }

    @И("^(?:пользователь |он )?сохраняет в базу данных контекст текущего сценария под именем \"([^\"]*)\"$")
    @Когда("^(?:я )?сохраняю в базу данных контекст текущего сценария под именем \"([^\"]*)\"$")
    public void updateStashInDB(String variable) throws IOException {
        steps().updateStashInDB(variable);
    }

    @И("^(?:пользователь |он )?восстанавливает из базы данных контекст текущего сценария по имени \"([^\"]*)\"$")
    @Когда("^(?:я )?восстанавливаю из базы данных контекст текущего сценария по имени \"([^\"]*)\"$")
    public void restoreStashFromDB(String variable) throws IOException {
        steps().restoreStashFromDB(variable);
    }

    @И("^(?:пользователь |он )?ожидает(?:,|) что элемент \"([^\"]*)\" станет недоступен$")
    @Тогда("^(?:я )?ожидаю, что элемент \"([^\"]*)\" станет недоступен$")
    public void waitElementDisabled(String elementName) throws PageException {
        steps().waitElementDisabled(elementName);
    }

    @И("^(?:пользователь |он )?ожидает (\\d+) секунд[уы]?(?:,|) что элемент \"([^\"]*)\" станет недоступен$")
    @Тогда("^(?:я )?ожидаю (\\d+) секунд[уы]?, что элемент \"([^\"]*)\" станет недоступен$")
    public void waitElementDisabled(int timeout, String elementName) throws PageException {
        steps().waitElementDisabled(elementName, timeout);
    }

    @И("^(?:пользователь |он )?ожидает(?:,|) что значение элемента \"([^\"]*)\" станет (не |)равно \"([^\"]*)\"$")
    @Тогда("^(?:я )?ожидаю, что значение элемента \"([^\"]*)\" станет (не |)равно \"([^\"]*)\"$")
    public void waitChangeElementValue(String elementName, NegationCondition negation, String value) throws PageException {
        steps().waitChangeElementValue(elementName, value, negation);
    }

    @И("^(?:пользователь |он )?ожидает (\\d+) секунд[уы]?(?:,|) что значение элемента \"([^\"]*)\" станет (не |)равно \"([^\"]*)\"$")
    @Тогда("^(?:я )?ожидаю (\\d+) секунд[уы]?, что значение элемента \"([^\"]*)\" станет (не |)равно \"([^\"]*)\"$")
    public void waitChangeElementValue(int timeout, String elementName, NegationCondition negation, String value) throws PageException {
        steps().waitChangeElementValue(elementName, value, timeout, negation);
    }

    @И("^(?:пользователь |он )?проверяет(?:,|) что элемент \"([^\"]*)\" с текстом \"([^\"]*)\" (?:существует|отображается)$")
    @Тогда("^элемент \"([^\"]*)\" с текстом \"([^\"]*)\" (?:существует|отображается)$")
    public void waitChangeElementValue(String elementName, String value) {
        steps().elementWithTextExists(elementName, value);
    }

}
