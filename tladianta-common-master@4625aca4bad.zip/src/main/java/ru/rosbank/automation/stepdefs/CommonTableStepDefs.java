package ru.rosbank.automation.stepdefs;

import cucumber.api.java.ru.И;
import cucumber.api.java.ru.Когда;
import cucumber.api.java.ru.Тогда;
import io.cucumber.datatable.DataTable;
import ru.rosbank.automation.configuration.ApplicationContext;
import ru.rosbank.automation.steps.CommonTableSteps;
import ru.rosbank.automation.transformer.ClickCondition;
import ru.rosbank.automation.transformer.NegationCondition;
import ru.sbtqa.tag.pagefactory.exceptions.PageException;

import java.util.List;

public class CommonTableStepDefs {
    private CommonTableSteps tableSteps() {
        return (CommonTableSteps) ApplicationContext.getStepsImpl("CommonTableSteps");
    }

    @И("^(?:пользователь |он )?запоминает номер строки таблицы \"([^\"]*)\", в которой значение в \"([^\"]*)\" равно \"([^\"]*)\"$")
    @Когда("^(?:я )?запоминаю номер строки таблицы \"([^\"]*)\", в которой значение в \"([^\"]*)\" равно \"([^\"]*)\"$")
    public void writeInStashRowDefault(String elementTitle, String columnName, String value) throws PageException {
        tableSteps().writeInStashRowNum(elementTitle, columnName, value, "Номер строки");
    }

    @И("^(?:пользователь |он )?запоминает (?:под именем|в переменную) \"([^\"]*)\" номер строки таблицы \"([^\"]*)\", в которой значение \"([^\"]*)\" равно \"([^\"]*)\"$")
    @Когда("^(?:я )?запоминаю (?:под именем|в переменную) \"([^\"]*)\" номер строки таблицы \"([^\"]*)\", в которой значение \"([^\"]*)\" равно \"([^\"]*)\"$")
    public void writeInStashRowNum(String variable, String elementTitle, String columnName, String value) throws PageException {
        tableSteps().writeInStashRowNum(elementTitle, columnName, value, variable);
    }

    @И("^(?:пользователь |он )?запоминает номер строки в таблице \"([^\"]*)\" для значения \"([^\"]*)\" столбца \"([^\"]*)\" в переменную \"([^\"]*)\"$")
    @Когда("^(?:я )?запоминаю номер строки в таблице \"([^\"]*)\" для значения \"([^\"]*)\" столбца \"([^\"]*)\" в переменную \"([^\"]*)\"$")
    public void writeInStashRowNumDefault(String elementTitle, String value, String columnName, String variable) throws PageException {
        tableSteps().writeInStashRowNum(elementTitle, columnName, value, variable);
    }

    @И("^(?:пользователь |он )?запоминает номер строки в таблице \"([^\"]*)\" для значения \"([^\"]*)\" столбца с номером \"([^\"]*)\" в переменную \"([^\"]*)\"$")
    @Когда("^(?:я )?запоминаю номер строки в таблице \"([^\"]*)\" для значения \"([^\"]*)\" столбца с номером \"([^\"]*)\" в переменную \"([^\"]*)\"$")
    public void writeInStashRowNumberByColumnNumber(String tableName, String cellText, String columnNumber, String stashKey) throws PageException {
        tableSteps().writeInStashRowNumberByColumnNumber(tableName, cellText, columnNumber, stashKey);
    }

    @И("^(?:пользователь |он )?запоминает значение ячейки \"([^\"]*):([^\"]*)\" в таблице \"([^\"]*)\" (?:как |под именем |в переменную )\"([^\"]*)\"$")
    @Когда("^(?:я )?запоминаю значение ячейки \"([^\"]*):([^\"]*)\" в таблице \"([^\"]*)\" (?:как |под именем |в переменную )\"([^\"]*)\"$")
    public void writeInStashCellValue(String rowNum, String columnName, String elementTitle, String variable) throws PageException {
        tableSteps().writeInStashCellValue(elementTitle, rowNum, columnName, variable);
    }

    @И("^(?:пользователь |он )?запоминает как \"([^\"]*)\" значение ячейки \"([^\"]*):([^\"]*)\" в таблице \"([^\"]*)\"$")
    @Когда("^(?:я )?запоминаю как \"([^\"]*)\" значение ячейки \"([^\"]*):([^\"]*)\" в таблице \"([^\"]*)\"$")
    public void writeInStashCellValueInVariable(String variable, String rowNum, String columnName, String elementTitle) throws PageException {
        tableSteps().writeInStashCellValue(elementTitle, rowNum, columnName, variable);
    }

    @И("^(?:пользователь |он )?запоминает (?:под именем|в переменную) \"([^\"]*)\" количество строк в таблице \"([^\"]*)\"$")
    @Когда("^(?:я )?запоминаю (?:под именем|в переменную) \"([^\"]*)\" количество строк в таблице \"([^\"]*)\"$")
    public void writeToStashRowCount(String variable, String elementTitle) throws PageException {
        tableSteps().writeToStashRowCount(elementTitle, variable);
    }

    @И("^(?:пользователь |он )?проверяет(?:,|) что колонка \"([^\"]*)\" таблицы \"([^\"]*)\" (не |)содержит значение \"([^\"]*)\"$")
    @Тогда("^колонка \"([^\"]*)\" таблицы \"([^\"]*)\" (не |)содержит значение \"([^\"]*)\"$")
    public void checkColumnContainsValue(String columnName, String elementTitle, NegationCondition negation, String regex) throws PageException {
        if (negation.isPositive()) {
            tableSteps().findValueInColumn(elementTitle, columnName, regex);
        } else {
            tableSteps().notFindValueInColumn(elementTitle, columnName, regex);
        }
    }

    @Когда("^(?:пользователь |он )?проверяет, что в таблице \"([^\"]*)\" в любой строке столбца \"([^\"]*)\" содержится текст \"([^\"]*)\"$")
    @Тогда("^в таблице \"([^\"]*)\" в любой строке столбца \"([^\"]*)\" содержится текст \"([^\"]*)\"$")
    public void containsText(String tableName, String columnName, String cellText) throws PageException {
        tableSteps().findValueInColumn(tableName, columnName, cellText);
    }

    @Когда("^(?:пользователь |он )?проверяет, что в таблице \"([^\"]*)\" в любой ячейке содержится текст \"([^\"]*)\"$")
    @Тогда("^в таблице \"([^\"]*)\" в любой ячейке содержится текст \"([^\"]*)\"$")
    public void containsText(String tableName, String cellText) throws PageException {
        tableSteps().findValueInTable(tableName, cellText);
    }

    @Когда("^(?:пользователь |он )?проверяет, что в таблице \"([^\"]*)\" в любой ячейке есть текст строго равный \"([^\"]*)\"$")
    @Тогда("^в таблице \"([^\"]*)\" в любой ячейке есть текст строго равный \"([^\"]*)\"$")
    public void hasText(String tableName, String cellText) throws PageException {
        tableSteps().checkTableHasText(tableName, cellText);
    }

    @И("^(?:пользователь |он )?проверяет ячейки строки таблицы \"([^\"]*)\" для значения \"([^\"]*)\" столбца \"([^\"]*)\":$")
    @Когда("^(?:я )?проверяю ячейки строки таблицы \"([^\"]*)\" для значения \"([^\"]*)\" столбца \"([^\"]*)\":$")
    public void checkRow(String tableName, String cellText, String columnName, DataTable data) throws PageException {
        tableSteps().checkRowByFilter(tableName, cellText, columnName, data);
    }

    @И("^(?:пользователь |он )?проверяет ячейки строки таблицы \"([^\"]*)\" для значения \"([^\"]*)\" столбца с номером \"([^\"]*)\":$")
    @Когда("^(?:я )?проверяю ячейки строки таблицы \"([^\"]*)\" для значения \"([^\"]*)\" столбца с номером \"([^\"]*)\":$")
    public void checkRowByFilterAndColumnNumber(String tableName, String cellText, String columnNumber, DataTable data) throws PageException {
        tableSteps().checkRowByFilterAndColumnNumber(tableName, cellText, columnNumber, data);
    }

    @И("^(?:пользователь |он )?выбирает (двойным кликом |)первую (?:по-порядку )?строку таблицы \"([^\"]*)\"$")
    @Когда("^(?:я )?выбираю (двойным кликом |)первую (?:по-порядку )?строку таблицы \"([^\"]*)\"$")
    public void selectFirstRow(ClickCondition clickVariation, String elementTitle) throws PageException {
        tableSteps().selectFirstRow(elementTitle, clickVariation);
    }

    @И("^(?:пользователь |он )?выбирает (двойным кликом |)последнюю строку таблицы \"([^\"]*)\"$")
    @Когда("^(?:я )?выбираю (двойным кликом |)последнюю строку таблицы \"([^\"]*)\"$")
    public void selectLastRow(ClickCondition clickVariation, String elementTitle) throws PageException {
        tableSteps().selectLastRow(elementTitle, clickVariation);
    }

    @И("^(?:пользователь |он )?выбирает (двойным кликом |)строку (?:номер |с номером |)\"([\\d]*)\" в таблице \"([^\"]*)\"$")
    @Когда("^(?:я )?выбираю (двойным кликом |)строку (?:номер |с номером |)\"([\\d]*)\" в таблице \"([^\"]*)\"$")

    public void selectTableRowByNumber(ClickCondition clickVariation, String rowNum, String elementTitle) throws PageException {
        tableSteps().selectTableRowByNumber(elementTitle, rowNum, clickVariation);
    }

    @И("^(?:пользователь |он )?выбирает (двойным кликом |)в таблице \"([^\"]*)\" строку со значением \"([^\"]*)\" в столбце \"([^\"]*)\"$")
    @Когда("^(?:я )?выбираю (двойным кликом |)в таблице \"([^\"]*)\" строку со значением \"([^\"]*)\" в столбце \"([^\"]*)\"$")
    public void selectTableRow(ClickCondition clickVariation,
                          String tableName, String cellText, String columnName) throws PageException {
        tableSteps().selectTableRow(clickVariation, tableName, cellText, columnName);
    }

    @И("^(?:пользователь |он )?выбирает (двойным кликом |)в таблице \"([^\"]*)\" (\\d+)-ю по-порядку строку со значением \"([^\"]*)\" в столбце \"([^\"]*)\"$")
    @Когда("^(?:я )?выбираю (двойным кликом |)в таблице \"([^\"]*)\" (\\d+)-ю по-порядку строку со значением \"([^\"]*)\" в столбце \"([^\"]*)\"$")
    public void selectTableRow(ClickCondition clickVariation,
                          String tableName, int serialNumber, String cellText, String columnName) throws PageException {
        tableSteps().selectTableRow(clickVariation, tableName, cellText, columnName, serialNumber);
    }

    @И("^(?:пользователь |он )?выбирает (двойным кликом |)в таблице \"([^\"]*)\" строку со значением \"([^\"]*)\" в столбце с номером \"([^\"]*)\"$")
    @Когда("^(?:я )?выбираю (двойным кликом |)в таблице \"([^\"]*)\" строку со значением \"([^\"]*)\" в столбце с номером \"([^\"]*)\"$")
    public void selectTableRowInColumn(ClickCondition clickVariation,
                                  String tableName, String cellText, String columnNumber) throws PageException {
        tableSteps().selectTableRowInColumn(clickVariation, tableName, cellText, columnNumber);
    }

    @И("^(?:пользователь |он )?выбирает (двойным кликом |)в таблице \"([^\"]*)\" (\\d+)-ю по-порядку строку " +
            "со значением \"([^\"]*)\" в столбце с номером \"([^\"]*)\"$")
    @Когда("^(?:я )?выбираю (двойным кликом |)в таблице \"([^\"]*)\" (\\d+)-ю по-порядку строку " +
            "со значением \"([^\"]*)\" в столбце с номером \"([^\"]*)\"$")
    public void selectTableRowInColumnByNumber(ClickCondition clickVariation,
                                          String tableName, int serialNumber, String cellText, String columnNumber) throws PageException {
        tableSteps().selectTableRowInColumnByNumber(clickVariation, tableName, cellText, columnNumber, serialNumber);
    }

    @И("^(?:пользователь |он )?выбирает (двойным кликом |)строку с текстом \"([^\"]*)\" в любой ячейке в таблице \"([^\"]*)\"$")
    @Когда("^(?:я )?выбираю (двойным кликом |)строку с текстом \"([^\"]*)\" в любой ячейке в таблице \"([^\"]*)\"$")
    public void selectTableRowByValue(ClickCondition clickVariation, String cellText, String tableName) throws PageException {
        tableSteps().selectTableRowByValue(clickVariation, cellText, tableName);
    }

    @И("^(?:пользователь |он )?выбирает (двойным кликом |)(\\d+)-ю по-порядку строку с текстом \"([^\"]*)\" в любой ячейке в таблице \"([^\"]*)\"$")
    @Когда("^(?:я )?выбираю (двойным кликом |)(\\d+)-ю по-порядку строку с текстом \"([^\"]*)\" в любой ячейке в таблице \"([^\"]*)\"$")
    public void selectTableRowByValue(ClickCondition clickVariation,
                          int serialNumber, String cellText, String tableName) throws PageException {
        tableSteps().selectTableRowByValue(clickVariation, cellText, tableName, serialNumber);
    }

    @И("^(?:пользователь |он )?выбирает (двойным кликом |)в таблице \"([^\"]*)\" строку со значениями:$")
    @Когда("^(?:я )?выбираю (двойным кликом |)в таблице \"([^\"]*)\" строку со значениями:$")
    public void selectTableRowByValues(ClickCondition clickVariation, String tableName, List<String> row) throws PageException {
        tableSteps().selectTableRowByValues(clickVariation, tableName, row);
    }



}
