package ru.rosbank.automation.stepdefs;

import cucumber.api.java.ru.И;
import cucumber.api.java.ru.Когда;
import io.cucumber.datatable.DataTable;
import ru.rosbank.automation.configuration.ApplicationContext;
import ru.rosbank.automation.steps.ActionSteps;

import java.util.List;

/**
 * Шаги Gherkin, расширяющие список шагов ядра.
 */
public class ActionStepDefs {

    private ActionSteps actionSteps() {
        return (ActionSteps) ApplicationContext.getStepsImpl("CoreStepsImpl");
    }

    //region БАЗОВЫЕ ШАГИ ДЛЯ ВЫПОЛНЕНИЯ ДЕЙСТВИЯ НА СТРАНИЦЕ

    @И("^(?:пользователь |он )?\\(([^)]*)\\)$")
    @Когда("^(?:я )?\\(([^)]*)\\)$")
    public void action(String action) throws NoSuchMethodException {
        actionSteps().action(action);
    }

    @И("^(?:пользователь |он )?\\(([^)]*)\\) (?:[^\"]*)\"([^\"]*)\"$")
    @Когда("^(?:я )?\\(([^)]*)\\) (?:[^\"]*)\"([^\"]*)\"$")
    public void action(String action, String param) throws NoSuchMethodException {
        actionSteps().action(action, param);
    }

    @И("^(?:пользователь |он |)\\(([^)]*)\\) (?:[^\"]*)\"([^\"]*)\"(?:[^\"]*)\"([^\"]*)\"$")
    @Когда("^(?:я |)\\(([^)]*)\\) (?:[^\"]*)\"([^\"]*)\"(?:[^\"]*)\"([^\"]*)\"$")
    public void actionTwoParam(String action, String param1, String param2) throws NoSuchMethodException {
        actionSteps().action(action, param1, param2);
    }

    @И("^(?:пользователь |он |)\\(([^)]*)\\) (?:[^\"]*)\"([^\"]*)\"(?:[^\"]*)\"([^\"]*)\"(?:[^\"]*)\"([^\"]*)\"$")
    @Когда("^(?:я |)\\(([^)]*)\\) (?:[^\"]*)\"([^\"]*)\"(?:[^\"]*)\"([^\"]*)\"(?:[^\"]*)\"([^\"]*)\"$")
    public void action(String action, String param1, String param2, String param3) throws NoSuchMethodException {
        actionSteps().action(action, param1, param2, param3);
    }

    @И("^(?:пользователь |он )?\\(([^)]*)\\)(?:[^\"]*)(?:данными|таблицы|):$")
    @Когда("^(?:я )?\\(([^)]*)\\)(?:[^\"]*)(?:данными|таблицы|):$")
    public void action(String action, DataTable dataTable) throws NoSuchMethodException {
        actionSteps().action(action, dataTable);
    }

    @И("^(?:пользователь |он )?\\(([^)]*)\\) (?:[^\"]*)\"([^\"]*)\"(?:[^\"]*)(?:данными|таблицы):$")
    @Когда("^(?:я )?\\(([^)]*)\\) (?:[^\"]*)\"([^\"]*)\"(?:[^\"]*)(?:данными|таблицы):$")
    public void action(String action, String param, DataTable dataTable) throws NoSuchMethodException {
        actionSteps().action(action, param, dataTable);
    }

    @И("^(?:пользователь |он )?\\(([^)]*)\\)(?:[^\"]*) (?:в списке|из списка):$")
    @Когда("^(?:я )?\\(([^)]*)\\)(?:[^\"]*) (?:в списке|из списка):$")
    public void action(String action, List<String> list) throws NoSuchMethodException {
        actionSteps().action(action, list);
    }

    @И("^(?:пользователь |он )?\\(([^)]*)\\) (?:[^\"]*)\"([^\"]*)\"(?: в списке| из списка):$")
    @Когда("^(?:я )?\\(([^)]*)\\) (?:[^\"]*)\"([^\"]*)\"(?: в списке| из списка):$")
    public void action(String action, String param, List<String> list) throws NoSuchMethodException {
        actionSteps().action(action, param, list);
    }

    //endregion

    //region БАЗОВЫЕ ШАГИ ДЛЯ ВЫПОЛНЕНИЯ ДЕЙСТВИЯ В БЛОКЕ

    @И("^(?:пользователь |он )(?:на вкладке|в блоке) \"([^\"]*)\" \\(([^)]*)\\)$")
    @Когда("^(?:я )(?:на вкладке|в блоке) \"([^\"]*)\" \\(([^)]*)\\)$")
    public void actionInBlock(String block, String action) throws NoSuchMethodException {
        actionSteps().actionInBlock(block, action);
    }

    @И("^(?:пользователь |он |)(?:на вкладке|в блоке) \"([^\"]*)\" \\(([^)]*)\\) (?:[^\"]*)\"([^\"]*)\"$")
    @Когда("^(?:я |)(?:на вкладке|в блоке) \"([^\"]*)\" \\(([^)]*)\\) (?:[^\"]*)\"([^\"]*)\"$")
    public void actionInBlock(String block, String action, String param) throws NoSuchMethodException {
        actionSteps().actionInBlock(block, action, param);
    }

    @И("^(?:пользователь |он |)(?:на вкладке|в блоке) \"([^\"]*)\" \\(([^)]*)\\) (?:[^\"]*)\"([^\"]*)\"(?:[^\"]*)\"([^\"]*)\"$")
    @Когда("^(?:я |)(?:на вкладке|в блоке) \"([^\"]*)\" \\(([^)]*)\\) (?:[^\"]*)\"([^\"]*)\"(?:[^\"]*)\"([^\"]*)\"$")
    public void actionInBlock(String block, String action, String param1, String param2) throws NoSuchMethodException {
        actionSteps().actionInBlock(block, action, param1, param2);
    }

    @И("^(?:пользователь |он |)(?:на вкладке|в блоке) \"([^\"]*)\" \\(([^)]*)\\)(?:[^\"]*)(?:данными|таблицы|):$")
    @Когда("^(?:я |)(?:на вкладке|в блоке) \"([^\"]*)\" \\(([^)]*)\\)(?:[^\"]*)(?:данными|таблицы|):$")
    public void actionInBlock(String block, String action, DataTable dataTable) throws NoSuchMethodException {
        actionSteps().actionInBlock(block, action, dataTable);
    }

    @И("^(?:пользователь |он |)(?:на вкладке|в блоке) \"([^\"]*)\" \\(([^)]*)\\)(?:[^\"]*)\"([^\"]*)\"(?:[^\"]*)(?: данными| из таблицы):$")
    @Когда("^(?:я |)(?:на вкладке|в блоке) \"([^\"]*)\" \\(([^)]*)\\)(?:[^\"]*)\"([^\"]*)\"(?:[^\"]*)(?: данными| из таблицы):$")
    public void actionInBlock(String block, String action, String param, DataTable dataTable) throws NoSuchMethodException {
        actionSteps().actionInBlock(block, action, param, dataTable);
    }

    @И("^(?:пользователь |он |)(?:на вкладке|в блоке) \"([^\"]*)\" \\(([^)]*)\\) (?:[^\"]*)(?:в списке|из списка):$")
    @Когда("^(?:я |)(?:на вкладке|в блоке) \"([^\"]*)\" \\(([^)]*)\\) (?:[^\"]*)(?:в списке|из списка):$")
    public void actionInBlock(String block, String action, List<String> stringList) throws NoSuchMethodException {
        actionSteps().actionInBlock(block, action, stringList);
    }

    @И("^(?:пользователь |он |)(?:на вкладке|в блоке) \"([^\"]*)\" \\(([^)]*)\\) (?:[^\"]*)\"([^\"]*)\"(?:[^\"]*)(?:в списке|из списка):$")
    @Когда("^(?:я |)(?:на вкладке|в блоке) \"([^\"]*)\" \\(([^)]*)\\) (?:[^\"]*)\"([^\"]*)\"(?:[^\"]*)(?:в списке|из списка):$")
    public void actionInBlock(String block, String action, String param, List<String> stringList) throws NoSuchMethodException {
        actionSteps().actionInBlock(block, action, param, stringList);
    }

    //endregion
}
