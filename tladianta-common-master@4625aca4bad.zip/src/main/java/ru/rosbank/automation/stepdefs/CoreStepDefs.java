package ru.rosbank.automation.stepdefs;

import cucumber.api.java.ru.И;
import cucumber.api.java.ru.Когда;
import cucumber.api.java.ru.Тогда;
import ru.rosbank.automation.configuration.ApplicationContext;
import ru.rosbank.automation.steps.ICoreSteps;
import ru.rosbank.automation.transformer.NegationCondition;
import ru.sbtqa.tag.pagefactory.exceptions.FragmentException;
import ru.sbtqa.tag.pagefactory.exceptions.PageException;
import ru.sbtqa.tag.pagefactory.exceptions.PageInitializationException;
import ru.sbtqa.tag.pagefactory.exceptions.WaitException;

/**
 * <p>Шаги, повторяющие шаги Gherkin ядра.</p>
 * <p>Формулировки шагов расширены</p>
 * <p>Все формулировки шагов должны заканчиваться на символ точки "."</p>
 * <p>Шаги будут использовать реализацию методов, переопределенных в модуле проекта</p>
 */
public class CoreStepDefs {

    private ICoreSteps steps() {
        return (ICoreSteps) ApplicationContext.getStepsImpl("CoreStepsImpl");
    }

    //region ШАГИ ИЗ ЯДРА

    @И("^(?:пользователь |он )?находится на странице \"([^\"]*)\"$")
    @Когда("^(?:открывается страница|открывается вкладка мастера) \"([^\"]*)\"$")
    public void openPage(String title) throws PageInitializationException {
        steps().openPage(title);
    }

    @И("^(?:пользователь |он )?заполняет поле \"([^\"]*)\" (?:значением )?\"([^\"]*)\"$")
    @Когда("^(?:я )?заполняю поле \"([^\"]*)\" (?:значением )?\"([^\"]*)\"$")
    public void fill(String elementTitle, String text) throws PageException {
        steps().fill(elementTitle, text);
    }

    @И("^(?:пользователь |он )?(?:кликает по ссылке|нажимает кнопку) \"([^\"]*)\"$")
    @Когда("^(?:я )?(?:кликаю по ссылке|нажимаю кнопку) \"([^\"]*)\"$")
    public void click(String elementTitle) throws PageException {
        steps().click(elementTitle);
    }

    @И("^(?:пользователь |он )?нажимает клавишу \"([^\"]*)\"$")
    @Когда("^(?:я )?нажимаю клавишу \"([^\"]*)\"$")
    public void pressKey(String keyName) {
        steps().pressKey(keyName);
    }

    @И("^(?:пользователь |он )?нажимает клавишу \"([^\"]*)\" на элементе \"([^\"]*)\"$")
    @Когда("^(?:я )?нажимаю клавишу \"([^\"]*)\" на элементе \"([^\"]*)\"$")
    public void pressKey(String keyName, String elementTitle) throws PageException {
        steps().pressKey(keyName, elementTitle);
    }

    @И("^(?:пользователь |он )?выбирает в \"([^\"]*)\" значение \"([^\"]*)\"$")
    @Когда("^(?:я )?выбираю в \"([^\"]*)\" значение \"([^\"]*)\"$")
    public void select(String elementTitle, String option) throws PageException {
        steps().select(elementTitle, option);
    }

    @И("^(?:пользователь |он )?(?:отмечает признак|отмечает чекбокс|устанавливает флаг) \"([^\"]*)\"$")
    @Когда("^(?:я )?(?:отмечаю признак|отмечаю чекбокс|устанавливаю флаг) \"([^\"]*)\"$")
    public void setCheckBox(String elementTitle) throws PageException {
        steps().setCheckBox(elementTitle);
    }

    @И("^(?:пользователь |он )?проверяет(?:,|) что в поле \"([^\"]*)\" значение (не |)равно \"([^\"]*)\"$")
    @Когда("^в поле \"([^\"]*)\" значение (не |)равно \"([^\"]*)\"$")
    public void checkValueIsEqual(String elementTitle, NegationCondition negation, String text) throws PageException {
        if (negation.isPositive()) {
            steps().checkValueIsEqual(elementTitle, text);
        }else {
            steps().checkValueIsNotEqual(elementTitle, text);
        }
    }

    @И("^(?:пользователь |он )?проверяет(?:,|) что поле \"([^\"]*)\" (не |)содержит значение \"([^\"]*)\"$")
    @Когда("^поле \"([^\"]*)\" (не |)содержит значение \"([^\"]*)\"$")
    public void checkValueContains(String elementTitle, NegationCondition negation, String text) throws PageException {
        if (negation.isPositive()) {
            steps().checkValueContains(elementTitle, text);
        }else {
            steps().checkValueNotContains(elementTitle, text);
        }
    }

    @И("^(?:пользователь |он )?проверяет(?:,|) что поле \"([^\"]*)\" (не|)пустое$")
    @Когда("^поле \"([^\"]*)\" (не|)пустое$")
    public void checkNotEmpty(String elementTitle, NegationCondition negation) throws PageException {
        if (negation.isPositive()) {
            steps().checkEmpty(elementTitle);
        }else {
            steps().checkNotEmpty(elementTitle);
        }
    }

    @И("^элемент \"([^\"]*)\" в фокусе$")
    public void isElementFocused(String element) {
        steps().isElementFocused(element);
    }

    @И("^(?:пользователь |он )?вставляет фрагмент \"([^\"]*)\"$")
    @Когда("^(?:пользователь |он |)выполняет сценарий \"([^\"]*)\"$")
    @Тогда("^(?:пользователь |он |)выполняет \"([^\"]*)\"$")
    public void userInsertsFragment(String fragmentName) throws FragmentException {
        steps().userInsertsFragment(fragmentName);
    }

    @И("^(?:пользователь |он )?ожидает появления элемента \"([^\"]*)\"$")
    @Когда("^(?:я )?ожидаю появления элемента \"([^\"]*)\"$")
    public void appearElement(String elementName) throws PageException {
        steps().appearElement(elementName);
    }

    @И("^(?:пользователь |он )?ожидает (\\d+) секунд[уы]? появления элемента \"([^\"]*)\"$")
    @Когда("^(?:я )?ожидаю (\\d+) секунд[уы]? появления элемента \"([^\"]*)\"$")
    public void appearElement(int timeout, String elementName) throws PageException {
        steps().appearElement(timeout, elementName);
    }

    @И("^(?:пользователь |он )?ожидает исчезновения элемента \"([^\"]*)\"$")
    @Когда("^(?:я )?ожидаю исчезновения элемента \"([^\"]*)\"$")
    public void waitInvisibility(String elementName) throws PageException {
        steps().waitInvisibility(elementName);
    }

    @И("^(?:пользователь |он )?ожидает (\\d+) секунд[уы]? исчезновения элемента \"([^\"]*)\"$")
    @Когда("^(?:я )?ожидаю (\\d+) секунд[уы]? исчезновения элемента \"([^\"]*)\"$")
    public void waitInvisibility(int timeout, String elementName) throws PageException {
        steps().waitInvisibility(timeout, elementName);
    }

    @И("^(?:пользователь |он )?ожидает(?:,|) что элемент \"([^\"]*)\" исчезнет со страницы$")
    @Когда("^(?:я )?ожидаю, что элемент \"([^\"]*)\" исчезнет со страницы$")
    public void waitAbsence(String elementName) throws PageException {
        steps().waitAbsence(elementName);
    }

    @И("^(?:пользователь |он )?ожидает (\\d+) секунд(?:у|ы|)?(?:,|) что элемент \"([^\"]*)\" исчезнет$")
    @Когда("^(?:я )?ожидаю (\\d+) секунд(?:у|ы|)?, что элемент \"([^\"]*)\" исчезнет$")
    public void waitAbsence(int timeout, String elementName) throws PageException {
        steps().waitAbsence(timeout, elementName);
    }

    @И("^(?:пользователь |он )?ожидает(?:,|) что значение атрибута \"([^\"]*)\" в элементе \"([^\"]*)\" станет равно \"([^\"]*)\"$")
    @Когда("^(?:я )?ожидаю, что значение атрибута \"([^\"]*)\" в элементе \"([^\"]*)\" станет равно \"([^\"]*)\"$")
    public void waitChangeAttribute(String attribute, String elementName, String attributeValue) throws PageException {
        steps().waitChangeAttribute(attribute, elementName, attributeValue);
    }

    @И("^(?:пользователь |он )?ожидает (\\d+) секунд[уы]?(?:,|) что значение атрибута \"([^\"]*)\" в элементе \"([^\"]*)\" станет равно \"([^\"]*)\"$")
    @Когда("^(?:я )?ожидаю (\\d+) секунд[уы]?, что значение атрибута \"([^\"]*)\" в элементе \"([^\"]*)\" станет равно \"([^\"]*)\"$")
    public void waitChangeAttribute(int timeout, String attribute, String elementName, String attributeValue) throws PageException {
        steps().waitChangeAttribute(timeout, attribute, elementName, attributeValue);
    }

    @И("^(?:пользователь |он )?ожидает(?:,|) что значение атрибута \"([^\"]*)\" в элементе \"([^\"]*)\" (не |)должно содержать \"([^\"]*)\"$")
    @Когда("^(?:я )?ожидаю, что значение атрибута \"([^\"]*)\" в элементе \"([^\"]*)\" (не |)должно содержать \"([^\"]*)\"$")
    public void waitAttributeContains(String attribute, String elementName,
                                      NegationCondition negation, String partAttributeValue) throws PageException {
        steps().waitAttributeContains(attribute, elementName, negation, partAttributeValue);
    }

    @И("^(?:пользователь |он )?ожидает (\\d+) секунд[уы]?(?:,|) что значение атрибута \"([^\"]*)\" в элементе \"([^\"]*)\" (не |)должно содержать \"([^\"]*)\"$")
    @Когда("^(?:я )?ожидаю (\\d+) секунд[уы]?, что значение атрибута \"([^\"]*)\" в элементе \"([^\"]*)\" (не |)должно содержать \"([^\"]*)\"$")
    public void waitAttributeContains(int timeout, String attribute, String elementName,
                                      NegationCondition negation, String partAttributeValue) throws PageException {
        steps().waitAttributeContains(timeout, attribute, elementName, negation, partAttributeValue);
    }

    @И("^(?:пользователь |он )?ожидает(?:,|) что элемент \"([^\"]*)\" (не |)должен содержать текст \"([^\"]*)\"$")
    @Когда("^(?:я )?ожидаю, что элемент \"([^\"]*)\" (не |)должен содержать текст \"([^\"]*)\"$")
    public void waitElementContainsText(String elementName, NegationCondition negation, String text) throws PageException {
        steps().waitElementContainsText(elementName, negation, text);
    }

    @И("^(?:пользователь |он )?ожидает (\\d+) секунд[уы]?(?:,|) что элемент \"([^\"]*)\" (не |)должен содержать текст \"([^\"]*)\"$")
    @Когда("^(?:я )?ожидаю (\\d+) секунд[уы]?, что элемент \"([^\"]*)\" (не |)должен содержать текст \"([^\"]*)\"$")
    public void waitElementContainsText(int timeout, String elementName, NegationCondition negation, String text) throws PageException {
        steps().waitElementContainsText(timeout, elementName, negation, text);
    }

    @И("^(?:пользователь |он )?ожидает(?:,|) что элемент \"([^\"]*)\" станет (?:кликабельным|доступен)$")
    @Когда("^(?:я )?ожидаю, что элемент \"([^\"]*)\" станет (?:кликабельным|доступен)$")
    public void waitClickability(String elementName) throws PageException {
        steps().waitClickability(elementName);
    }

    @И("^(?:пользователь |он )?ожидает (\\d+) секунд[уы]?(?:,|) что элемент \"([^\"]*)\" станет (?:кликабельным|доступен)$")
    @Когда("^(?:я )?ожидаю (\\d+) секунд[уы]?, что элемент \"([^\"]*)\" станет (?:кликабельным|доступен)$")
    public void waitClickability(int timeout, String elementName) throws PageException {
        steps().waitClickability(timeout, elementName);
    }

    @И("^(?:пользователь |он )?принимает уведомление с текстом \"([^\"]*)\"$")
    @Когда("^(?:я )?принимаю уведомление с текстом \"([^\"]*)\"$")
    public void acceptAlert(String text) throws WaitException {
        steps().acceptAlert(text);
    }

    @И("^(?:пользователь |он )?отклоняет уведомление с текстом \"([^\"]*)\"$")
    @Когда("^(?:я )?отклоняю уведомление с текстом \"([^\"]*)\"$")
    public void dismissAlert(String text) throws WaitException {
        steps().dismissAlert(text);
    }

    @И("^(?:пользователь |он )?очищает поле \"([^\"]*)\"$")
    @Когда("^(?:я )?очищаю поле \"([^\"]*)\"$")
    public void clearField(String elementTitle) throws PageException {
        steps().clearField(elementTitle);
    }

    //endregion
}
