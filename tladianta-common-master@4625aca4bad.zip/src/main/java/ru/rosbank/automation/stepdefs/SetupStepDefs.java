package ru.rosbank.automation.stepdefs;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import ru.rosbank.automation.configuration.ApplicationContext;
import ru.rosbank.automation.configuration.ApplicationManager;
import ru.rosbank.automation.extensions.DataReplacer;
import ru.rosbank.automation.steps.CommonSetupSteps;
import ru.rosbank.automation.steps.CommonSteps;
import ru.sbtqa.tag.pagefactory.environment.Environment;

public class SetupStepDefs {

    @Before(order = 0)
    public void preSetUp() {
        ApplicationManager.initApplicationsProperties();

        ApplicationContext.setStepsImpl("CommonSteps", CommonSteps.getInstance());

        DataReplacer.addGenerators("ru.rosbank.automation.generator");

        CommonSetupSteps.preSetUp();
    }

    @Before(order = 9999)
    public void initDefaultContext() {
        ApplicationManager.initDefaultContext();
    }

    @Before(order = 10100)
    public void setUp() {
        CommonSetupSteps.handleTasks();
    }

    @Before(order = 10101)
    public void setUpVideo() {
        CommonSetupSteps.initVideoUtils();
    }

    @Before(order = 99999)
    public void setUp(Scenario scenario) {
        Environment.setScenario(scenario);
    }

    @After(order = 0)
    public void tearDown(Scenario scenario) {
        CommonSetupSteps.tearDown(scenario);
    }

    @After(order = 10100)
    public void tearDownTasks() {
        CommonSetupSteps.handleTasks();
    }
}