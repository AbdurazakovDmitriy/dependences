package ru.rosbank.automation.generator;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import ru.rosbank.automation.annotations.Generator;
import ru.rosbank.automation.annotations.GeneratorTitle;
import ru.rosbank.automation.extensions.DateWorker;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalUnit;
import java.util.Random;

/**
 * Класс, поставщик статических методов для генерирования данных по шаблонам значений параметров.
 * В .feature-файлах параметры могут быть указаны в виде шаблонов определенной структуры: "~{ключ:шаблон}".
 * Примеры: "~{метка:дата-время-миллисекунды}", "~{дата и время:завтра;+10;лет}".
 */

@Generator
public class DataGenerator {
    private static final Random RND = new Random();

    /**
     * Символы кириллицы
     */
    private static final String STRING_CYRILLIC_SYMBOLS = "абвгдеёжзиклмнопрстуфхцчшщэюя";

    /**
     * Символы латиницы
     */
    private static final String STRING_LATIN_SYMBOLS = "abcdefghijklmnopqrstuvwxyz";

    /**
     * Символы чисел
     */
    private static final String STRING_DIGITS = "0123456789";

    /**
     * Генерирует строку из указанного количества кириллических символов
     *
     * @param args Длина итоговой строки
     * @return Сгенерированная строка
     */
    @GeneratorTitle("строка кириллицей")
    public static String getRusString(String args) {
        return getRandomString(Integer.parseInt(args), STRING_CYRILLIC_SYMBOLS);
    }

    /**
     * Генерирует строку из указанного коливества латинских символов
     *
     * @param args Длина итоговой строки
     * @return Сгенерированная строка
     */
    @GeneratorTitle("строка латиницей")
    public static String getLatinString(String args) {
        return getRandomString(Integer.parseInt(args), STRING_LATIN_SYMBOLS);
    }

    /**
     * <p>Генерирует случайное число в диаппазоне между двух значений разделенных дефисом.</p>
     *
     * @param args Длина числа
     * @return Строковое представление сгенерированого числа
     */
    @GeneratorTitle("число в диапазоне")
    public static String getRandomNumIn(String args) {
        String[] during = args.split("-");
        if (during.length == 1) {
            return randomNumber(0, Integer.parseInt(during[0].trim()));
        } else {
            return randomNumber(Integer.parseInt(during[0].trim()), Integer.parseInt(during[1].trim()));
        }
    }

    /**
     * <p>Генерирует случайное число укзаной длины.</p>
     * <p>Число собирается из символов {@link #STRING_DIGITS}</p>
     *
     * @param args Длина числа
     * @return Строковое представление сгенерированого числа
     */
    @GeneratorTitle("число длинной")
    public static String number(String args) {
        return getRandomString(Integer.parseInt(args), STRING_DIGITS.substring(1));
    }

    /**
     * <p>Генерирует метку даты/времени из текущей даты по шаблону</p>
     * <p>Возможны варианты:</p>
     * <ul>
     *     <li>дата-время-миллисекунды - соответствует шаблону yyyyMMddHHmmssSSS</li>
     *     <li>дата-время-секунды - соответствует шаблону yyyyMMddHHmmssSSS</li>
     *     <li>дата - соответствует шаблону yyyyMMdd</li>
     *     <li>стандартная маска даты/времени</li>
     * </ul>
     *
     * @param args Шаблон маски даты
     * @return Сгенерированная метка
     */
    @GeneratorTitle("метка")
    public static String getTimeStamp(String args) {
        String pattern;
        switch (args.toLowerCase().trim()) {
            case "дата-время-миллисекунды":
                pattern = "yyyyMMddHHmmssSSS";
                break;
            case "дата-время-секунды":
                pattern = "yyyyMMddHHmmss";
                break;
            case "дата":
                pattern = "yyyyMMdd";
                break;
            default:
                pattern = args;
        }
        return DateWorker.getStringByPattern(LocalDateTime.now(), pattern);
    }

    /**
     * <p>Генерирует даты/время по указанным в args правилам.</p>
     * <p>Параметры передаются через разделитель ";" и выполняются последовательно слева направо.</p>
     * <p>Возможные варианты правил:</p>
     * <ul>
     *     <li><span style='color:green;'>сегодня, сейчас</span> - получает текущую дату</li>
     *     <li><span style='color:green;'>завтра</span> - прибавляет 1 день к  текущей дате</li>
     *     <li><span style='color:green;'>вчера</span> - отнимает 1 день от текущей даты</li>
     *     <li><span style='color:green;'>+/-число (+5 или -5)</span> - аргумент операции над датой, всегда применяется вместе с квалицикаторами единиц операции. Например, <span style='color:green;'>+5;лет, -2;дня</span> и т.д.</li>
     *     <li><span style='color:green;'>дней, дня, день</span> - квалифицирует единицу предыдущей операции как день. Например, <span style='color:green;'>-5:дней</span></li>
     *     <li><span style='color:green;'>лет, год, года</span> - квалифицирует единицу предыдущей операции как год. Например, <span style='color:green;'>+10:лет</span></li>
     *     <li><span style='color:green;'>месяц, месяцев, месяца</span> - квалифицирует единицу предыдущей операции как месяц. Например, <span style='color:green;'>-2:месяца</span></li>
     *     <li><span style='color:green;'>час, часа, часов</span> - квалифицирует единицу предыдущей операции как час, Например, <span style='color:green;'>-2:часа</span></li>
     *     <li><span style='color:green;'>минута, минуты, минут, мин</span> - квалифицирует единицу предыдущей операции как минута, Например, <span style='color:green;'>-2:минуты</span></li>
     *     <li><span style='color:green;'>секунда, секунды. секунд, сек</span> - квалифицирует единицу предыдущей операции как секунда, Например, <span style='color:green;'>-10:секунд</span></li>
     *     <li><span style='color:green;'>маска|</span> - после символе '|' указывается маска, по которой нужно представить дату. Например, <span style='color:green;'>маска|bis, маска|ddMMyy</span>
     *     По-умолчанию дата возвращается в фомате "dd.MM.yyyy"</li>
     * </ul>
     * <p>Примеры использования:</p>
     * <ul>
     *     <li><span style='color:green;'>[завтра;+10;лет]</span> - прибавит к текущей дате 1 день и 10 лет</li>
     *     <li><span style='color:green;'>[вчера;-100;лет;маска|bis]</span> - от текущей даты отнимет 1 день и 100 лет, дату вернет в формате bis;</li>
     *     <li><span style='color:green;'>[сегодня;-5;дней;маска|ddMMyy]</span> - от текущей даты отнимет 5 дней и представит результат в виде '01 января 2019'</li>
     * </ul>
     *
     * @param args Формат
     * @return Сгенерированная строка
     */
    @GeneratorTitle("дата и время")
    public static String getDate(String args) {
        String[] dateParams = args.split(";");
        LocalDateTime currentDate = LocalDateTime.now();
        int unitCount = 0;
        TemporalUnit units = ChronoUnit.DAYS;
        String mask = "";

        for (String dateParam : dateParams) {
            String param = dateParam.trim();
            switch (param) {
                case "сегодня":
                case "сейчас":
                    break;
                case "завтра":
                    currentDate = DateWorker.offset(LocalDateTime.now(), +1);
                    break;
                case "вчера":
                    currentDate = DateWorker.offset(LocalDateTime.now(), -1);
                    break;
                case "дней":
                case "дня":
                case "день":
                    units = ChronoUnit.DAYS;
                    break;
                case "лет":
                case "год":
                case "года":
                    units = ChronoUnit.YEARS;
                    break;
                case "месяц":
                case "месяцев":
                case "месяца":
                    units = ChronoUnit.MONTHS;
                    break;
                case "час":
                case "часа":
                case "часов":
                    units = ChronoUnit.HOURS;
                    break;
                case "минута":
                case "минуты":
                case "минут":
                case "мин":
                    units = ChronoUnit.MINUTES;
                    break;
                case "секунды":
                case "секунд":
                case "секунда":
                case "сек":
                    units = ChronoUnit.SECONDS;
                    break;
                default:
                    if (param.matches("[0-9+#-]+")) {
                        unitCount = Integer.parseInt(param);
                    } else if (param.startsWith("маска")) {
                        mask = param.split("\\|")[1].trim();
                    } else if (param.startsWith("входная маска")) {
                        mask = param.split("\\|")[1].trim();
                    }
                    break;
            }
        }

        if (mask.length() >= 1) {
            return DateWorker.dateWorker(currentDate, mask, String.class, mask, unitCount, units);
        } else {
            return DateWorker.dateWorker(currentDate, mask, String.class, "dd.MM.yyyy HH:mm:ss", unitCount, units);
        }
    }

    /**
     * Собирает строку нужной длины из набора символов
     *
     * @param length       длина строки
     * @param symbolSource строка с символами
     * @return собранная строка
     */
    private static String getRandomString(int length, String symbolSource) {
        StringBuilder randString = new StringBuilder();
        for (int i = 0; i < length; i++) {
            randString.append(getRandomSymbolFromInputString(symbolSource));
        }
        return randString.toString();
    }

    /**
     * Генерирует число в укзаанном диапазоне
     *
     * @param start Начало диапазона
     * @param end   Конец диапазона
     * @return Строковое представление сгенерированного числа
     */
    @NotNull
    @Contract(pure = true)
    private static String randomNumber(int start, int end) {
        if (start == end)
            return String.valueOf(start);
        int min = Math.min(start, end);
        int max = Math.max(start, end);
        int i = min + RND.nextInt(max + 1 - min);
        return String.valueOf(i);
    }

    /**
     * Получает случайный символ из переданной строки
     *
     * @param inputString Строка, из которой нужно выбрать один символ
     * @return Символ
     */
    @Contract(pure = true)
    private static char getRandomSymbolFromInputString(@NotNull String inputString) {
        return inputString.charAt((int) (Math.random() * inputString.length()));
    }
}
