package ru.rosbank.automation.aspects;

import cucumber.api.PickleStepTestStep;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import ru.rosbank.automation.extensions.DataReplacer;

@Aspect
public class GeneratorAspect {
    @Contract
    @Pointcut("execution(* ru.sbtqa.tag.pagefactory.data.DataReplacer.replace(..)) && args(testStep,..)")
    public static void sendStepStart(@NotNull PickleStepTestStep testStep) {
    }

    @Around("sendStepStart(testStep)")
    public void sendStepStart(ProceedingJoinPoint joinPoint, PickleStepTestStep testStep) throws Throwable {
        DataReplacer dataGenerator = new DataReplacer();
        dataGenerator.replaceStepArguments(testStep, false);
//        dataGenerator.replace(testStep);
        joinPoint.proceed(new Object[]{testStep});
    }

    public static GeneratorAspect aspectOf() {
        return new GeneratorAspect();
    }
}

