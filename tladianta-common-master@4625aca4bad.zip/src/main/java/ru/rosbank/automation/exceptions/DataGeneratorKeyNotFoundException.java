package ru.rosbank.automation.exceptions;

public class DataGeneratorKeyNotFoundException extends RuntimeException {
    public DataGeneratorKeyNotFoundException(String message) {
        super(message);
    }

    public DataGeneratorKeyNotFoundException(String string, Throwable ex) {
        super(string, ex);
    }
}
