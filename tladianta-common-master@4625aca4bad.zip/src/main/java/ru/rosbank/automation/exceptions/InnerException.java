package ru.rosbank.automation.exceptions;

/**
 * Внутреннее исключение для всех плагинов.
 * Применяется, когда необходимо описать внутренние ошибки.
 * Например : ошибка при чтении, записи xml
 */
public class InnerException extends RuntimeException {

    public InnerException() {
    }

    public InnerException(String message) {
        super(message);
    }

    public InnerException(String message, Throwable cause) {
        super(message, cause);
    }

    public InnerException(Throwable cause) {
        super(cause);
    }

    public InnerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
