package ru.rosbank.automation.exceptions;

public class DataGeneratorException extends RuntimeException {
    public DataGeneratorException(String message) {
        super(message);
    }

    public DataGeneratorException(String string, Throwable ex) {
        super(string, ex);
    }
}
