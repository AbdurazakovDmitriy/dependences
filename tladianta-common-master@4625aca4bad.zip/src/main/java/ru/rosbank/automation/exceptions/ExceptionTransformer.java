package ru.rosbank.automation.exceptions;

import org.apache.commons.lang3.exception.ExceptionUtils;
import ru.sbtqa.tag.pagefactory.exceptions.FactoryRuntimeException;
import ru.sbtqa.tag.qautils.properties.Props;

import java.util.function.Function;

/**
 * <p>Функциональный интерфейс с обязательным методом apply()</p>
 * <p>Предназначен для создания классов-исключений для трансформации одних исключений в другие.</p>
 */
public interface ExceptionTransformer extends Function<Throwable, Throwable> {

    /**
     * <p>Возвращает экземпляр интерфейса {@link ExceptionTransformer}, проинициализированный функцией по-умолчанию, которая получает корневое исключение</p>
     * <h3>Пример использования в коде:</h3>
     * <p>код <code>ExceptionTransformer transformer = ExceptionTransformer.getDefaultInstance();</code></p>
     * <p>Аналогичен коду <code>ExceptionTransformer transformer = ExceptionUtils::getRootCause;</code></p>
     * <p>затем <code>Throwable exception2 = transformer.apply(exception1);</code></p>
     * @return экземпляр интерфейса {@link ExceptionTransformer}
     */
    static ExceptionTransformer getDefaultInstance() {
        return ExceptionUtils::getRootCause;
    }

    /**
     * <p>Определяет класс-исключения, реализующего интерфейс {@link ExceptionTransformer} из свойства <span style='color:green;'>action.exception.transformer</span> в конфигурационном файле <span style='color:blue;'>application.properties</span>
     * и создает его екземпляр.</p>
     * <p>Если свойство не задано, возвращает функцию по-умолчанию {@link #getDefaultInstance()}</p>
     * @return экземпляр интерфейса {@link ExceptionTransformer}
     */
    static ExceptionTransformer getInstanceFromProps() {
        ExceptionTransformer transformer = ExceptionUtils::getRootCause;

        String className = Props.get("action.exception.transformer", null);
        try {
            return (className == null ? getDefaultInstance() : (ExceptionTransformer) Class.forName(className).getConstructor().newInstance());
        } catch (ReflectiveOperationException | ClassCastException e) {
            throw new FactoryRuntimeException("Failed to create exception transformer of class " + className, e);
        }
    }
}
