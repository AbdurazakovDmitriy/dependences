package ru.rosbank.automation.helpers;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.reflect.ConstructorUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import ru.sbtqa.tag.pagefactory.Page;
import ru.sbtqa.tag.pagefactory.PageManager;
import ru.sbtqa.tag.pagefactory.annotations.PageEntry;
import ru.sbtqa.tag.pagefactory.context.PageContext;
import ru.sbtqa.tag.pagefactory.exceptions.PageInitializationException;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

@Slf4j
public class PageHelper {

    /**
     * Проверяет, есть ли в репозитории страниц класс страницы с указанным title
     *
     * @param title имя страницы
     * @return true/false
     */
    public static boolean pageWithTitleExist(String title) {
        return getPageClass(title).isPresent();
    }

    /**
     * Находит всех родителей переданного класса
     *
     * @param clazz сласс страницы
     * @return список имен классов-родителей
     */
    public static Set<String> getPageSuperclasses(Class<? extends Page> clazz) {

        Set<String> classNames = new HashSet<>();

        Class current = clazz;
        while (Page.class.isAssignableFrom(current)) {
            classNames.add(current.getName());
            current = (current.getSuperclass() == null)? Object.class: current.getSuperclass();
        }
        return classNames;
    }

    /**
     * Из класса страницы в Page
     * {@link PageContext#getCurrentPage()} variable
     *
     * @param page a page class
     * @return the initialized page object
     * @throws PageInitializationException if failed to execute corresponding
     * page constructor
     */
    public static <T extends Page> T bootstrapPage(Class<T> page, Object... parameters) throws PageInitializationException {
        if (page != null) {
            try {
                return ConstructorUtils.invokeConstructor(page, parameters);
            } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                throw new PageInitializationException("Failed to initialize page '" + page + "'", e);
            }
        }
        return null;
    }

    /**
     * Находит в репозитории страниц класс страницы по имени
     *
     * @param title имя страницы
     * @return класс страницы
     */
    public static Optional<Class<? extends Page>> getPageClass(String title) {
        for (Map.Entry<Class<? extends Page>, Map<Field, String>> entry : PageManager.getPageRepository().entrySet()) {
            Class<? extends Page> page = entry.getKey();
            String pageTitle = null;
            PageEntry pageAnnotation = page.getAnnotation(PageEntry.class);
            if (null != pageAnnotation) {
                pageTitle = pageAnnotation.title();
            } else {
                try {
                    pageTitle = (String) FieldUtils.readStaticField(page, "title", true);
                } catch (IllegalArgumentException | IllegalAccessException ex) {
                    log.debug("Failed to read {} because it is not page object", title, ex);
                }
            }
            if (pageTitle != null && pageTitle.equals(title)) {
                return Optional.of(page);
            }
        }

        return Optional.empty();
    }

}
