package ru.rosbank.automation.helpers;

import java.util.Arrays;
import java.util.List;

public class CommonHelper {

    public static List<String> stringToList(String str) {
        return Arrays.asList(str.split("\\s*,\\s*"));
    }

    public static List<String> stringToList(String str, String separator) {
        return Arrays.asList(str.split(separator));
    }
}
