package ru.rosbank.automation.helpers;

import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jutils.jprocesses.JProcesses;
import org.jutils.jprocesses.model.ProcessInfo;
import ru.sbtqa.tag.pagefactory.exceptions.FactoryRuntimeException;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public final class SystemHelperImpl implements SystemHelper {
    @NotNull
    private static final SystemHelper instance = new SystemHelperImpl();

    @Contract(pure = true)
    private SystemHelperImpl() {
    }

    @NotNull
    @Contract(pure = true)
    public static SystemHelper getInstance() {
        return instance;
    }

    @Override
    @NotNull
    public List<ProcessInfo> getProcesses() {
        return JProcesses.get().fastMode(true).listProcesses();
    }

    @Override
    @NotNull
    public List<ProcessInfo> getProcesses(@NotNull String process) {
        String processName = process;

        String[] parts = process.split("[\\/\\\\]");
        if (parts.length > 1) {
            processName = parts[parts.length - 1];
        }

        return JProcesses.get().fastMode(true).listProcesses(processName).stream()
                .filter((c) -> c.getCommand().contains(process))
                .collect(Collectors.toList());
    }

    @Override
    public boolean isProcessActive(@NotNull String process) {
        List<ProcessInfo> processes = getProcesses(process);
        return processes.size() > 0;
    }

    @Override
    public void runCommand(@NotNull String command) {
        try {
            Runtime.getRuntime().exec(command);
        } catch (IOException e) {
            throw new FactoryRuntimeException(e);
        }
    }

    @Override
    public void killProcess(@NotNull String process) {
        List<ProcessInfo> processList = getProcesses(process);
        processList.forEach(p->{
            int pid = Integer.parseInt(p.getPid());
            if (JProcesses.killProcess(pid).isSuccess()) {
                log.info("Процесс '{} [{}]' остановлен", process, pid);
            } else {
                log.info("Процесс '{} [{}]' не остановлен", process, pid);
            }
        });
    }
}
