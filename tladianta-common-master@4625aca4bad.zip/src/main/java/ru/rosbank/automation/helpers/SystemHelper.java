package ru.rosbank.automation.helpers;

import org.jutils.jprocesses.model.ProcessInfo;

import java.io.IOException;
import java.util.List;

public interface SystemHelper {

    /**
     * Собирает все активные процессы OS в список имен
     * @return  Список имен активных процессов OS
     * @throws IOException Если возникла ошибка в процессе сбора информации о процессах
     */
    List<ProcessInfo> getProcesses();

    /**
     * Собирает все процессы по имени или полному пути
     *
     * @param process имя процесса или полный путь к исполняемому файлу
     * @return список процессов
     */
    List<ProcessInfo> getProcesses(String process);

    /**
     * Проверяет, запущен ли процесс в OS
     *
     * @param processName имя процесса в списке процессов
     * @return true/false
     */
    boolean isProcessActive(String processName);

    /**
     * Выполняет команду в командной строке/терминале
     *
     * @param command текст команды
     */
    void runCommand(String command);

    /**
     * Завершает процесс по полному пути или имени.
     * Будут завершены все найденные процессы
     *
     * @param processName имя или полный путь процесса
     */
    void killProcess(String processName);
}
