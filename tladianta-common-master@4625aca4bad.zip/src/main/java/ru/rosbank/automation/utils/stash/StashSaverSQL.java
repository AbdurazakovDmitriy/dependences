package ru.rosbank.automation.utils.stash;

import ru.rosbank.automation.utils.db.DbClient;
import ru.rosbank.automation.utils.db.DbConfig;

/** Класс для записи/чтения в/из SQL json-представление контекста ({@link ru.sbtqa.tag.datajack.Stash})*/
public class StashSaverSQL {

    private String SELECT = "SELECT [testName], [json] FROM [qtp_temp].[dbo].[bdd_stash2] WHERE [testName] = '%s'";
    private String INSERT = "INSERT INTO [qtp_temp].[dbo].[bdd_stash2]([testName],[json]) VALUES('%s', '%s')";
    private String UPDATE = "UPDATE [qtp_temp].[dbo].[bdd_stash2] SET [json] = '%s' WHERE [testName] = '%s'";

    private DbClient dbClient;

    {
        //TODO - указать строку подключения или брать из properties
        dbClient = new DbClient(new DbConfig("", "mssql", "mssql", ()->{}));
    }

    /**
     * Запись json-представление контекста ({@link ru.sbtqa.tag.datajack.Stash}) в БД
     *
     * @param testName   название теста (ключ в БД), под которым сохраняем в БД
     * @param json       сохраняемый json
     */
    public void updateStashInDB(String testName, String json) {
        String querySelect = String.format(SELECT, testName);
        String queryInsert = String.format(INSERT, testName, json);
        String queryUpdate = String.format(UPDATE, json, testName);

        if(dbClient.request(querySelect).size() == 0) {
            dbClient.executeUpdateQuery(queryInsert);
        }
        else {
            dbClient.executeUpdateQuery(queryUpdate);
        }
    }

    /**
     * Чтение json-представление контекста ({@link ru.sbtqa.tag.datajack.Stash}) из БД
     *
     * @param testName  название теста (ключ в БД), по которому выбираем значения
     * @return          возвращаем весь текст, который содержит json
     */
    public String selectStashFromDB(String testName) {
        String queryText = String.format(SELECT, testName);
        return dbClient.requestValue(queryText, "JSON");
    }
}