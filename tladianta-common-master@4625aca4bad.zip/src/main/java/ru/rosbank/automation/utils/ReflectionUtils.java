package ru.rosbank.automation.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.reflect.FieldUtils;
import ru.sbtqa.tag.pagefactory.exceptions.FactoryRuntimeException;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

@Slf4j
public class ReflectionUtils {

    /**
     * Устанавливает static final полю класса новое значение
     *
     * @param <T>       параметр типа нового значения
     * @param fieldName имя поля класса
     * @param newValue  новое значение поля
     * @param classes   класс(ы), в котором нужно изменить значение поля
     */
    public static <T> void resetStaticField(String fieldName, T newValue, Class<?>... classes) {
        resetStaticField(fieldName, newValue, false, classes);
    }

    /**
     * Устанавливает static final полю класса новое значение
     *
     * @param fieldName имя поля класса
     * @param newValue  новое значение поля
     * @param strict    Поведение в случае ошибки: true - выкинет исключение, false - залогирует ошибку без падения
     * @param classes   класс(ы), в котором нужно изменить значение поля
     * @param <T>       параметр типа нового значения
     */
    public static <T> void resetStaticField(String fieldName, T newValue, boolean strict, Class<?>... classes) {
        for (Class<?> clazz : classes) {
            try {
                Field field = FieldUtils.getField(clazz, fieldName, true);

                turnOffFinalModifier(field);

                field.set(null, newValue);

                log.info("В поле {}.{} установлено новое значение ", clazz.getName(), fieldName);
            } catch (IllegalAccessException e) {
                String message = String.format("Не удалось изменить значение поля %s.%s", clazz.getName(), fieldName);
                reportError(strict, e, message);
            }
        }
    }

    /**
     * Устанавливает final полю объекта новое значение
     *
     * @param <T>       параметр типа нового значения
     * @param fieldName имя поля
     * @param newValue  новое значение
     * @param objects       объект(ы), в котором нужно установить новое значение поля
     */
    public static <T> void resetField(String fieldName, T newValue, Object... objects) {
        resetField(fieldName, newValue, false, objects);
    }

    /**
     * Устанавливает final полю объекта новое значение
     *
     * @param <T>       параметр типа нового значения
     * @param fieldName имя поля
     * @param newValue  новое значение
     * @param objects       объект(ы), в котором нужно установить новое значение поля
     */
    public static <T> void resetField(String fieldName, T newValue, boolean strict, Object... objects) {
        for (Object obj : objects) {
            Class<?> clazz = obj.getClass();
            try {
                Field field = FieldUtils.getField(clazz, fieldName, true);

                turnOffFinalModifier(field);

                field.set(obj, newValue);

                log.info("В поле {}.{} установлено новое значение ", clazz.getName(), fieldName);
            } catch (IllegalAccessException e) {
                String message = String.format("Не удалось изменить значение поля %s.%s", clazz.getName(), fieldName);
                reportError(strict, e, message);
            }
        }
    }

    private static void reportError(boolean strict, IllegalAccessException e, String message) {
        if (strict) {
            throw new FactoryRuntimeException(message, e);
        } else {
            log.debug(message);
        }
    }


    /**
     * Проверяет, что класс содержит статическое поле нужного типа
     *
     * @param clazz класс, в котором проверяется наличие поля
     * @param fieldName имя поля
     * @param type тип поля
     * @return true/false
     */
    public static boolean fieldExists(Class<?> clazz, String fieldName, Class<?> type) {
        Field field = FieldUtils.getField(clazz, fieldName, true);
        return field != null
                && Modifier.isStatic(field.getModifiers())
                && field.getType().isAssignableFrom(type);
    }

    /**
     * Снимает у поля модификатор final
     *
     * @param field поле класса/объекта
     */
    public static void turnOffFinalModifier(Field field) {
        try {
            Field modifiers = Field.class.getDeclaredField("modifiers");
            modifiers.setAccessible(true);
            int fieldModifiers = field.getModifiers();

            modifiers.setInt(field, fieldModifiers & ~Modifier.FINAL);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new FactoryRuntimeException(String.format("Ошибка при попытке снять модификатор final у поля %s", field.getName()), e);
        }
    }
}
