package ru.rosbank.automation.utils;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import ru.sbtqa.tag.qautils.errors.AutotestError;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;

public class FileUtils {

    /**
     * Записывает в файл ресурсов переданную коллекцию
     * в виде пар "ключ = значение"
     *
     * @param resourcePath относительный путь к файлу ресурса
     * @param sourceProperties исходная коллекция свойств
     */
    public static void writePropertiesToResource(String resourcePath, Map<Object, Object> sourceProperties ) {

        String path = Objects.requireNonNull(FileUtils.class.getClassLoader().getResource(resourcePath),
                String.format("Не найден путь к файлу ресурса %s", resourcePath)).getPath()
                .replaceAll("%20", " ");

        try (PrintWriter writer = new PrintWriter(new FileOutputStream(path, false))) {
            for (Map.Entry<Object, Object> entry : sourceProperties.entrySet()) {
                writer.println(String.format("%s = %s", String.valueOf(entry.getKey()), String.valueOf(entry.getValue())));
            }
        } catch (FileNotFoundException e) {
            throw new AutotestError(String.format("Не найден файл '%s'. Замена свойств не удалась.", resourcePath));
        }

    }

    /**
     * Загружает из файла ресурсов пары значений в коллекцию свойств
     *
     * @param resourceName путь к файлу ресурсов
     * @return коллекция загруженных свойств
     */
    @NotNull
    @Contract("_->new")
    public static Properties loadPropertiesFromResource(String resourceName) {
        Properties newProps = new Properties();
        try (InputStream stream = FileUtils.class.getClassLoader().getResourceAsStream(resourceName);
             InputStreamReader isr = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
            newProps.load(isr);
        } catch (Exception e) {
            throw new AutotestError(String.format("Ошибка загрузки файла настроек '%s'", resourceName), e);
        }

        return newProps;
    }


}
