package ru.rosbank.automation.utils.db;

import lombok.extern.slf4j.Slf4j;
import ru.rosbank.automation.exceptions.DbConnectionException;
import ru.rosbank.automation.utils.function.UFunction;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * <p>Класс предоставляет набор методов для работы с БД </p>
 * <ul>
 *     <li>Выполнить запрос на запись</li>
 *     <li>Получить все строки</li>
 *     <li>Получить первую строку</li>
 *     <li>Получить все значения из конкретной колонки</li>
 *     <li>Получить значение из первой ячейки первой колонки</li>
 *     <li>Получить значение из первой ячейки конкретной колонки</li>
 * </ul>
 * <p>Использует LoggerFactory для создания логов.</p>
 */
@Slf4j
public class DbClient {

    /**
     * Конфигурация соединения с базой данных
     */
    private final DbConfig config;

    /**
     * Поставщик методов-конвертеров результата запроса
     */
    private final DbResultConverter resultConverter;

    /**
     * Конструктор
     * @param config - объект конфигурации соединения с базой данных
     */
    public DbClient(DbConfig config) {
        this(config, new DbResultConverter());
    }

    public DbClient(DbConfig config, DbResultConverter resultConverter) {
        this.config = config;
        this.resultConverter = resultConverter;
    }

    /**
     * <p>Метод-обертка для получения результата запроса в виде списка коллекций 'имя колонки'-'значение'</p>
     * <p>Будут обработаны все строки.</p>
     *
     * @param sql строка запроса в базу данных
     * @return список коллекций 'имя колонки'-'значение'
     */
    public List<Map<String, String>> request(String sql) {
        return executeQuery(sql, resultConverter::getAllRows);
    }

    /**
     * <p>Метод-обертка для получения результата запроса в виде коллекции 'имя колонки'-'значение'</p>
     * <p>Будет выбрана первая строка результата запроса</p>
     *
     * @param sql строка запроса в базу данных
     * @return коллекция 'имя колонки'-'значение'
     */
    public Map<String, String> requestRow(String sql) {
        return executeQuery(sql, resultConverter::getFirstRow);
    }

    /**
     * <p>Метод-обертка для получения результата запроса в виде текстового значения из первой колонки</p>
     * <p>Будет обработана первая строка результата запроса.</p>
     *
     * @param sql строка запроса в базу данных
     * @return текстового значения из первой колонки
     */
    public String requestValue(String sql) {
        return executeQuery(sql, resultConverter::getFirstValue);
    }

    /**
     * <p>Метод-обертка для получения результата запроса в виде текстового значения из указанной колонки</p>
     * <p>Будет обработана первая строка результата запроса</p>
     *
     * @param sql   строка запроса в базу данных
     * @param field имя колонки в выдаче
     * @return текстовое значение ячейки
     */
    public String requestValue(String sql, String field) {
        return executeQuery(sql, resultConverter::getFirstRow).get(field);
    }

    /**
     * <p>Метод-обертка для получения результата запроса в виде списка значений из первой колонки</p>
     * <p>Будут обработаны все строки результата запроса</p>
     *
     * @param sql строка запроса в базу данных
     * @return список значений
     */
    public List<String> requestColumn(String sql) {
        return executeQuery(sql, resultConverter::getFirstColumn);
    }

    /**
     * <p>Метод-обертка для получения результата запроса в виде списка значений из указанной колонки</p>
     * <p>Будут обработаны все строки результата запроса.</p>
     *
     * @param sql   строка запроса в базу данных
     * @param field имя поля, из которого нужно получить значение
     * @return список значений
     */
    public List<String> requestColumn(String sql, String field) {
        List<String> result = new ArrayList<>();
        List<Map<String, String>> array = executeQuery(sql, resultConverter::getAllRows);

        for (Map<String, String> e : array) {
            result.add(e.get(field));
        }

        return result;
    }

    /**
     * Закрытие закешированного соединения с базой данных
     */
    public void closeConnection() {
        config.closeConnection();
    }

    /**
     * Выполнение SELECT запроса к базе данных и возвращение результата с конвертацией полученного ResultSet в любой набор данных
     *
     * @param sql       строка запроса в базу данных
     * @param converter функция-конвертер, принимающая на вход ResultSet и возвращающая необходимый набор данных
     * @param <R>       тип возвращвемого набора данных
     * @return результат конвертации ResultSet или null
     */
    public <R> R executeQuery(String sql, UFunction<ResultSet, R> converter) {
        log.info("Запрос к базе данных: " + sql);
        Connection connection = config.getConnection();
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

                return converter.apply(resultSet);
        } catch (Throwable e) {
            throw new DbConnectionException("Ошибка выполнения запроса в базу данных", e);
        }
    }

    /**
     * Выполнение INSERT или UPDATE запроса к базе данных.
     *
     * @param sql строка запроса в базу данных
     * @return колличество обработанных записей
     */
    public int executeUpdateQuery(String sql) {
        log.info("Запрос к базе данных: " + sql);
        Connection connection = config.getConnection();
        try (Statement statement = connection.createStatement()) {
            int updatedRows = statement.executeUpdate(sql);
            log.info("Обновлено строк: " + updatedRows);
            return updatedRows;
        } catch (SQLException e) {
            throw new DbConnectionException("Ошибка выполнения запроса в базу данных", e);
        }
    }

}
