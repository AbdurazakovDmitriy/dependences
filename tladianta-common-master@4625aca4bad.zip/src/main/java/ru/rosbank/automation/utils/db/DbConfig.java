package ru.rosbank.automation.utils.db;

import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import ru.rosbank.automation.exceptions.DbConnectionException;

import java.sql.Connection;
import java.sql.SQLException;

@Slf4j
public final class DbConfig {
    @NotNull
    private String dbConnection;
    private final String dbUser;
    private final String dbPassword;
    @Nullable
    private Connection connection = null;

    /**
     * Подготовка драйверов баз данных по умолчанию.
     *
     */
    @NotNull
    private Runnable prepareScript = () -> {
        try {
            if (dbConnection.contains("jdbc:oracle")) {
                Class.forName("oracle.jdbc.driver.OracleDriver");
            }
            if (dbConnection.contains("jdbc:as400")) {
                Class.forName("com.ibm.as400.access.AS400JDBCDriver");
            }
            if (dbConnection.contains("jdbc:jtds:sqlserver")) {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            }
        } catch (ClassNotFoundException e) {
            throw new DbConnectionException("Ошибка подготовки драйвера базы данных", e);
        }
    };

    /**
     * Конструктор класса конфигурации соединения с базой
     *
     * @param dbConnection - Строка подключения к базе данных
     * @param dbUser - Имя пользователя
     * @param dbPassword - Пароль
     */
    @Contract(pure = true)
    public DbConfig(@NotNull String dbConnection, String dbUser, String dbPassword) {
        this.dbConnection = dbConnection;
        this.dbUser = dbUser;
        this.dbPassword = dbPassword;
    }
    /**
     * Конструктор класса конфигурации соединения с базой
     *
     * @param dbConnection - Строка подключения к базе данных
     * @param dbUser - Имя пользователя
     * @param dbPassword - Пароль
     * @param prepareScript - Процедура подготовки драйвера базы данных
     */
    @Contract(pure = true)
    public DbConfig(@NotNull String dbConnection, @NotNull String dbUser, @NotNull String dbPassword, @NotNull Runnable prepareScript) {
        this(dbConnection, dbUser, dbPassword);
        this.prepareScript = prepareScript;
    }


    /**
     * Получение соединения в БД, в случае если запрашивалось - возвращается существующее
     * @return
     */
    public Connection getConnection() {
        if (connection == null) {
            prepareScript.run();
            try {
                connection = java.sql.DriverManager.getConnection(dbConnection, dbUser, dbPassword);
            } catch (SQLException e) {
                throw new DbConnectionException("Ошибка соединения с базой данных", e);
            }
        }

        return connection;
    }

    /**
     * Закрытие соединения с БД
     */
    public void closeConnection() {
        if(connection != null) {
            try {
                connection.close();
                if(!connection.isClosed()) {
                    log.warn("Ошибка закрытия соединения с базой данных: соединение не закрыто");
                }
            } catch (SQLException e) {
                throw new DbConnectionException("Ошибка закрытия соединения с базой данных", e);
            }
            connection = null;
        }
    }
}
