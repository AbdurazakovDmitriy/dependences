package ru.rosbank.automation.utils.db;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DbResultConverter {

    /**
     * <p>Конветер из ResultSet в список коллекций: ключ - 'имя колонкаи', значение - 'значение ячейки'.</p>
     * <p>Выбираются все данные.</p>
     *
     * @param resultSet результат запроса
     * @return Список коллекции преобразованных строк, может быть пустым
     * @throws SQLException при работе с результатом запроса
     */
    public List<Map<String, String>> getAllRows(ResultSet resultSet) throws SQLException {
        List<Map<String, String>> rows = new ArrayList<>();

        while (true) {
            Map<String, String> map = getFirstRowFromResultSet(resultSet);
            if (map == null) {
                break;
            }
            rows.add(map);
        }

        return rows;
    }

    /**
     * <p>Конвертер строки данных из ResultSet в коллекцию: ключ - 'имя колонки', значение - 'значение в ячейке'.</p>*
     * <p>Выбирается первая строка</p>
     *
     * @param resultSet результат запроса
     * @return преобразованная в коллекцию строка данных или null
     * @throws SQLException при работе с результатом запроса
     */
    public Map<String, String> getFirstRow(ResultSet resultSet) throws SQLException {

        return getFirstRowFromResultSet(resultSet);
    }

    /**
     * <p>Конвертер из ResultSet в единичное значение типа String.</p>
     * <p>Выбирается значение из первой колонки и первой строки</p>
     *
     * @param resultSet результат запроса
     * @return выходное значение или null
     * @throws SQLException при работе с результатом запроса
     */
    public String getFirstValue(ResultSet resultSet) throws SQLException {
        if (!resultSet.next()) {
            return null;
        }
        return resultSet.getString(1);
    }

    /**
     * <p>Конвертер из ResultSet в список значений типа String.</p>
     * <p>Выбираются все данные из первой колонки по всем строкам</p>
     *
     * @param resultSet результат запроса
     * @return Список значений, может быть пустыым
     * @throws SQLException при работе с результатом запроса
     */
    public List<String> getFirstColumn(ResultSet resultSet) throws SQLException {
        List<String> values = new ArrayList<>();

        while (resultSet.next()) {
            values.add(resultSet.getString(1));
        }

        return values;
    }


    /**
     * <p>Выбирается первая строка из ResultSet в коллекцию: ключ - 'имя колонки', значение - 'значение в ячейке'.</p>
     *
     * @param resultSet результат запроса
     * @return преобразованная в коллекцию строка данных или null
     * @throws SQLException при работе с результатом запроса
     */
    private Map<String, String> getFirstRowFromResultSet(ResultSet resultSet) throws SQLException {
        if (!resultSet.next()) {
            return null;
        }

        Map<String, String> row = new HashMap<>();
        ResultSetMetaData rsMetaData = resultSet.getMetaData();

        for (int i = 1; i <= rsMetaData.getColumnCount(); i++) {
            row.put(rsMetaData.getColumnName(i), resultSet.getString(i));
        }

        return row;
    }
}

