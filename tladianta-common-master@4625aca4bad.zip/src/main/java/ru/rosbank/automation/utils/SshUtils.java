package ru.rosbank.automation.utils;

import lombok.extern.slf4j.Slf4j;
import net.schmizz.sshj.SSHClient;
import net.schmizz.sshj.common.IOUtils;
import net.schmizz.sshj.connection.channel.direct.Session;
import ru.rosbank.automation.configuration.CommonConfiguration;

import java.io.IOException;

@Slf4j
public class SshUtils {
    private static final CommonConfiguration PROPERTIES = CommonConfiguration.create();

    /**
     * Выполнение команды по SSH на хосте с параметрами из application.properties
     *
     * @param hostName    - Имя хоста, с 3я значениями из application.properties: [имя].ssh.host, [имя].ssh.user, [имя].ssh.pass
     * @param commandLine - Команда для выполнения на хосте
     * @return - результат выполнения команды
     * @throws IOException - искючение ввода-вывода
     */
    public static String executeCommand(String hostName, String commandLine) throws IOException {
        PROPERTIES.setProperty("hostName", hostName);
        String host = PROPERTIES.getSshHostName();
        String user = PROPERTIES.getSshHostUser();
        String pass = PROPERTIES.getSshHostPass();

        try(SSHClient ssh = new SSHClient()) {
            ssh.addHostKeyVerifier((s, i, publicKey) -> true);
            ssh.connect(host);
            ssh.authPassword(user, pass.toCharArray());

            Session session = ssh.startSession();
            Session.Command command = session.exec(commandLine);
            String returnValue = (IOUtils.readFully(command.getInputStream()).toString());
            if(command.getExitStatus() != 0 && log.isDebugEnabled()) {
                log.debug(IOUtils.readFully(command.getErrorStream()).toString());
            }
            session.close();
            ssh.disconnect();

            return returnValue;
        }
    }
}