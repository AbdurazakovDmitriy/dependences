package ru.rosbank.automation.utils;

import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import lombok.extern.slf4j.Slf4j;

import java.util.Objects;
import java.util.function.Supplier;

/**
 * Вспомогательный класс, для обединения группы свойств для переключения контекста в классе
 */
@Slf4j
public final class FieldValueResetter<T> {

    /**
     * Клас, в котором нужно переустановить значение поля
     */
    @NotNull
    private final Class<?> victimClass;

    /**
     * Имя поля класса, в которое нужно установить новое значение
     */
    @NotNull
    private final String fieldName;

    /**
     * Метод, который вернет новое значение для поля
     */
    @NotNull
    private final Supplier<T> valueSupplier;

    @Contract(pure = true)
    public FieldValueResetter(@NotNull Class<?> victimClass, @NotNull String fieldName, @NotNull Supplier<T> valueSupplier) {
        this.victimClass = victimClass;
        this.fieldName = fieldName;
        this.valueSupplier = valueSupplier;
    }

    @Contract(pure = true)
    @NotNull
    public Class<?> getVictimClass() {
        return victimClass;
    }

    @Contract(pure = true)
    @NotNull
    public String getFieldName() {
        return fieldName;
    }

    @Contract(pure = true)
    @NotNull
    public Supplier<T> getValueSupplier() {
        return valueSupplier;
    }

    public void reset() {
        try {
            T newValue = valueSupplier.get();
            ReflectionUtils.resetStaticField(fieldName, newValue, victimClass);
        } catch (Exception e) {
            log.warn(String.format("Ошибка создания объекта конфигурации для класса '%s'", victimClass.getCanonicalName()), e);
        }
    }

    @Contract(value = "null -> false", pure = true)
    @Override
    public boolean equals(@Nullable Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FieldValueResetter fieldValueResetter = (FieldValueResetter) o;
        return victimClass.equals(fieldValueResetter.victimClass) &&
                fieldName.equals(fieldValueResetter.fieldName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(victimClass, fieldName);
    }
}
