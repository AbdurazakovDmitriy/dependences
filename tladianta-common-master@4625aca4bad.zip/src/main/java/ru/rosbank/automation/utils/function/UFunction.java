package ru.rosbank.automation.utils.function;

public interface UFunction<T, R> {
    R apply(T t) throws Throwable;
}
