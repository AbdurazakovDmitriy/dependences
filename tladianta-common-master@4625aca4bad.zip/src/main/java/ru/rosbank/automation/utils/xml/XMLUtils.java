package ru.rosbank.automation.utils.xml;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import ru.rosbank.automation.configuration.CommonConfiguration;
import ru.rosbank.automation.exceptions.InnerException;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class XMLUtils {

    /**
     * Метод открытия, чтения xml по заданному пути. Возвращает Document.
     * @param title - название xml файла
     */
    public static Document readFile(@NotNull String title){
        String xmlPath = getConversionXmlPath(title);
        SAXReader reader = new SAXReader();
        Document document;
        try {
            document = reader.read(xmlPath);
        } catch (DocumentException e) {
            throw new InnerException(String.format("Ошибка при чтении текущей '%s' xml. Путь до xml '%s'", title, getDefaultPathOfXmlFiles()), e);
        }
        return document;
    }

    /**
     * Запись объекта XML документа в файл на диске.
     * Путь к файлу по умолчанию задается в самом плагине, в файле: config/app/application.properties
     * Например: xml.path = src/test/resources/data/
     * @param document - документ, из которого читается значение тега
     * @param title - название xml файла с расширением
     */
    public static void writeFile(@NotNull Document document, @NotNull String title) {
        String xmlPath = getConversionXmlPath(title);
        try {
            XMLWriter writer = new XMLWriter(
                    new FileWriter(new File(xmlPath)));
            writer.write(document);
            writer.close();
        } catch (IOException e) {
            throw new InnerException(String.format("Ошибка при записи текущей '%s' xml. Путь до xml '%s'", title, getDefaultPathOfXmlFiles()), e);
        }
    }

    /**
     * Получение внутреннего текста по тэгу
     * @param document - документ, из которого читается значение тега
     * @param pathOfTag - путь до xml тэга. Пример: Application->Applicant->Document->Doc_Type
     */
    @Contract(pure = true)
    @NotNull
    public  static String getTagText(@NotNull Document document, @NotNull String pathOfTag){
        String title = getConversionXpathText(pathOfTag);
        return document.selectSingleNode(title).getText();
    }

    /**
     * Получение тэга документа
     * @param document - документ, из которого читается значение тега
     * @param pathOfTag - путь до xml тэга
     */
    @Contract(pure = true)
    @NotNull
    public static Node getNode(@NotNull Document document, @NotNull String pathOfTag){
        String title = getConversionXpathText(pathOfTag);
        return document.selectSingleNode(title);
    }

    /**
     * Получение элемента по пути тэга
     * @param document - документ, из которого читается значение тега
     * @param pathOfTag - путь до xml тэга
     */
    @Contract(pure = true)
    @NotNull
    public static Element getElementByPathOfTag(@NotNull Document document, @NotNull String pathOfTag){
        String title = getConversionXpathText(pathOfTag);
        Node node = document.selectSingleNode(title);
        return (Element) node;
    }

    /**
     * Получение пути до файла.
     * @param pathOfXML - путь до xml файла
     */
    @Contract(pure = true)
    @NotNull
    public static String getPath(@NotNull String pathOfXML){
        String path = String.format("%s%s", getDefaultPathOfXmlFiles(), pathOfXML);
        File file = new File(path);
        return file.getPath();
    }

    /**
     * Получение текста атрибута по заданному тэгу.
     * @param element - элемент
     * @param attributeTitle - название атрибута
     * @param tagTitle - название тэга
     */
    @Contract(pure = true)
    @NotNull
    public static String getAttributeText(@NotNull Element element, @NotNull String attributeTitle, @NotNull String tagTitle){
        String text = element.attributeValue(attributeTitle);
        if(text == null) {
            throw new AssertionError(String.format("В тэге '%s' нет атрибута '%s'", tagTitle, attributeTitle));
        }
        return text;
    }

    @Contract(pure = true)
    @NotNull
    private static String getConversionXmlPath(@NotNull String xmlTitle){
        return String.format("%s%s", getDefaultPathOfXmlFiles(), xmlTitle);
    }

    @Contract(pure = true)
    @NotNull
    private static String getConversionXpathText(@NotNull String text){
        return String.format("//%s", text.replace("->", "/"));
    }

    private static String getDefaultPathOfXmlFiles(){
        CommonConfiguration configuration = CommonConfiguration.create();
        return configuration.getXmlPath();
    }
}
