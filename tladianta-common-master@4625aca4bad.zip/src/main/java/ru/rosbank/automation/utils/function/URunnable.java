package ru.rosbank.automation.utils.function;

public interface URunnable {
    boolean run() throws Exception;
}
