package ru.rosbank.automation.utils.function;

public interface UBiFunction<T, U, R> {
    R apply(T t, U u) throws Throwable;
}
