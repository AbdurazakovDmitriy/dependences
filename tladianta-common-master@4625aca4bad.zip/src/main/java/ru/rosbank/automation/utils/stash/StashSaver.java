package ru.rosbank.automation.utils.stash;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import ru.sbtqa.tag.datajack.Stash;

import java.util.Base64;
import java.util.Map;

/** Класс для выполнения запросов к БД - сохранение и чтение контекста ({@link Stash})*/
public class StashSaver {
    @NotNull
    private static final StashSaverSQL stashSaverSQL;

    static {
        stashSaverSQL=new StashSaverSQL();
    }

    @Contract(pure = true)
    private StashSaver() {
    }

    /**
     * Сохранение контекста ({@link Stash}) в БД по названию теста, который играет роль ключа
     *
     * @param testName     ключ в БД, по которому сохраняем и затем достаем данные контекста
    */
    public static synchronized void saveToDB(String testName) {
        Gson gson = new GsonBuilder().create();
        String json = gson.toJson(Stash.asMap());
        String data = Base64.getEncoder().encodeToString(json.getBytes());
        stashSaverSQL.updateStashInDB(testName, data);
    }

    /**
     * Получение контекста ({@link Stash}) из БД по ключу (название теста)
     *
    * @param testName -   ключ в БД, по которому выбираем
    * @return   -   возвращаем карту ({@link Map}) значений стэша*/
    public static synchronized Map<String, String> getFromDB(String testName) {
        String stashInDB = stashSaverSQL.selectStashFromDB(testName);
        String json = new String(Base64.getDecoder().decode(stashInDB));
        return new Gson().fromJson(json, new TypeToken<Map<String, String>>() {}.getType());
    }
}