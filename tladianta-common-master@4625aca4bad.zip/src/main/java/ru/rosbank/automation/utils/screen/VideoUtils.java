package ru.rosbank.automation.utils.screen;

import lombok.extern.slf4j.Slf4j;
import ru.rosbank.automation.allure.AllureHelper;
import ru.rosbank.automation.allure.Type;
import ru.rosbank.automation.configuration.CommonConfiguration;
import ru.sbtqa.tag.videorecorder.VideoRecorder;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

/**
 * Класс реализации записи и прикрепления видео
 * Поддерживает возможность создавать дополнительные реализации наследованием
 */
@Slf4j
public class VideoUtils {
    protected static final CommonConfiguration PROPERTIES = CommonConfiguration.create();
    protected static final HashMap<String, VideoUtils> instances = new HashMap<>();
    protected byte[] bytes = new byte[]{};

    private static final String name = "Default";

    /**
     * Синглтон - создает экземпляр данного класса
     */
    public static void create() {
        if (!instances.containsKey(name)) {
            instances.put(name, new VideoUtils());
        }
    }

    /**
     * Старт записи всех экземпляров
     */
    public static void startRecord() {
        for (Map.Entry<String, VideoUtils> entry : instances.entrySet()) {
            log.info(String.format("Попытка стартовать видеорекордер: %s", entry.getKey()));
            entry.getValue().start();
        }
    }

    /**
     * Стоп записи всех экземпляров
     */
    public static void stopRecord() {
        for (Map.Entry<String, VideoUtils> entry : instances.entrySet()) {
            log.info(String.format("Попытка остановки видеорекордера: %s", entry.getKey()));
            entry.getValue().stop();
        }
    }

    /**
     * Прикрепление записанных видео всеми экземплярами
     */
    public static void attachRecord(boolean isFailed) {
        String videoFlag = PROPERTIES.getVideoAttachFlag();
        if ("ALWAYS".equals(videoFlag) || ("FAIL".equals(videoFlag) && isFailed)) {
            for (VideoUtils utils : instances.values()) {
                utils.attach();
            }
        }
    }

    /**
     * Реализация старта видео
     */
    protected void start() {
        try {
            if (PROPERTIES.isVideoEnabled()) {
                if (!VideoRecorder.isVideoRecording()) {
                    File videoPath = new File(System.getProperty("user.dir") + File.separator
                            + PROPERTIES.getVideoPath());

                    if (!videoPath.exists()) {
                        if (videoPath.mkdir()) {
                            VideoRecorder.setVideoFolder(PROPERTIES.getVideoPath());
                        } else {
                            throw new IOException(String.format("Ошибка при создании каталога '%s'", videoPath));
                        }
                    }
                    VideoRecorder.startRecording();
                    log.info("Видеорекордер запущен.");
                } else {
                    log.info("Видеорекордер уже запущен.");
                }
            } else {
                log.info("Запись видео отключена в настройках. Видеорекордер не запущен.");
            }
        } catch (Exception e) {
            log.error("Ошибка при запуске видео ", e);
        }
    }

    /**
     * Реализация остановки видео
     */
    protected void stop() {
        if (PROPERTIES.isVideoEnabled() && VideoRecorder.isVideoRecording()) {
            String videoName = new VideoRecorder().getVideoName();
            VideoRecorder.stopRecording();

            log.info("Видеорекордер остановлен.");

            File file = new File(System.getProperty("user.dir") + File.separator
                    + VideoRecorder.getVideoFolder() + File.separator + videoName);

            try {
                bytes = Files.readAllBytes(file.toPath());
            } catch (IOException e) {
                AllureHelper.logFieldInfo("Ошибка прикрепления видео файла", String.format("Не могу прикрепить файл : %s", file.getPath()));
                e.printStackTrace();
            }
        } else {
            log.info("Запись видео отключена в настройках. Видеорекордер не был запущен.");
        }
    }

    /**
     * Реализация прикрепления видео
     */
    protected void attach() {
        if (PROPERTIES.isVideoEnabled()) {
            AllureHelper.addAttachment("video", Type.VIDEO, bytes);
        }
    }
}
